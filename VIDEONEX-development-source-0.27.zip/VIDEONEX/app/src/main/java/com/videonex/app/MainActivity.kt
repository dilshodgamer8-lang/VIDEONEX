package com.videonex.app

import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.OpenableColumns
import android.media.MediaMetadataRetriever
import android.widget.ImageView
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import com.videonex.app.ai.AiClient
import com.videonex.app.ai.ResearchClient
import com.videonex.app.ai.SecureKeyStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.videonex.app.data.ProjectDao
import com.videonex.app.data.MediaAsset
import com.videonex.app.data.MediaAssetDao
import com.videonex.app.data.TimelineDao
import com.videonex.app.data.TimelineClip
import com.videonex.app.media.VideoExportManager
import com.videonex.app.media.ExportJob
import com.videonex.app.media.ExportSettings
import com.videonex.app.data.VideoProject
import com.videonex.app.data.VideonexDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD6AD55)
private val Muted = Color(0xFFAAAAAA)
private val Red = Color(0xFFFF7777)

private data class StoryScene(
    val number: Int, val title: String, val durationSeconds: Int,
    val narration: String, val imagePrompt: String,
    val cameraMotion: String, val visualStyle: String, val imageUri: String = ""
)

private fun storyboardFile(context: android.content.Context, projectId: Long): File {
    val folder = File(context.filesDir, "videonex/storyboards")
    if (!folder.exists()) folder.mkdirs()
    return File(folder, "project-$projectId.json")
}

private fun readStoryboard(context: android.content.Context, projectId: Long): List<StoryScene> {
    val file = storyboardFile(context, projectId)
    if (!file.exists()) return emptyList()
    return try {
        val array = JSONArray(file.readText())
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            StoryScene(o.optInt("number", i + 1), o.optString("title"), o.optInt("durationSeconds", 8),
                o.optString("narration"), o.optString("imagePrompt"), o.optString("cameraMotion"), o.optString("visualStyle"), o.optString("imageUri"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveStoryboard(context: android.content.Context, projectId: Long, scenes: List<StoryScene>) {
    val array = JSONArray()
    scenes.forEach { scene ->
        array.put(JSONObject().put("number", scene.number).put("title", scene.title)
            .put("durationSeconds", scene.durationSeconds).put("narration", scene.narration)
            .put("imagePrompt", scene.imagePrompt).put("cameraMotion", scene.cameraMotion)
            .put("visualStyle", scene.visualStyle).put("imageUri", scene.imageUri))
    }
    storyboardFile(context, projectId).writeText(array.toString())
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = VideonexDatabase.get(this)
        val dao = database.projectDao()
        val mediaDao = database.mediaAssetDao()
        val timelineDao = database.timelineDao()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel,
                onPrimary = Black, onBackground = Color.White, onSurface = Color.White)) {
                val vm: HomeViewModel = viewModel(factory = HomeViewModel.factory(dao, mediaDao, timelineDao))
                VideonexApp(vm)
            }
        }
    }
}

class HomeViewModel(private val dao: ProjectDao, private val mediaDao: MediaAssetDao, private val timelineDao: TimelineDao) : ViewModel() {
    val projects = dao.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun addProject(name: String, direction: String) = viewModelScope.launch { dao.insert(VideoProject(name = name, direction = direction)) }
    fun assetsFor(projectId: Long) = mediaDao.observeForProject(projectId)
    fun addMedia(projectId: Long, uri: String, displayName: String, mimeType: String) = viewModelScope.launch {
        val assetId = mediaDao.insert(MediaAsset(projectId = projectId, uri = uri, displayName = displayName, mimeType = mimeType))
        val track = if (mimeType.startsWith("audio/")) 2 else if (mimeType.startsWith("video/")) 1 else 0
        val end = timelineDao.trackEnd(projectId, track)
        val defaultDuration = if (track == 2) 30_000L else 5_000L
        timelineDao.insert(TimelineClip(projectId = projectId, mediaAssetId = assetId, trackIndex = track, startMs = end, durationMs = defaultDuration))
    }
    fun timelineFor(projectId: Long) = timelineDao.observeForProject(projectId)
    fun buildImageTimeline(projectId: Long, orderedScenes: List<Pair<String, Long>>) = viewModelScope.launch {
        // Rebuild only the primary image track; audio and video tracks remain untouched.
        timelineDao.deleteTrack(projectId, 0)
        var cursorMs = 0L
        orderedScenes.forEachIndexed { index, item ->
            val uri = item.first
            val durationMs = item.second.coerceAtLeast(1_000L)
            val existing = mediaDao.findByUri(projectId, uri)
            val assetId = existing?.id ?: mediaDao.insert(
                MediaAsset(projectId = projectId, uri = uri, displayName = "Storyboard ${String.format("%03d", index + 1)}", mimeType = "image/*")
            )
            timelineDao.insert(TimelineClip(projectId = projectId, mediaAssetId = assetId, trackIndex = 0,
                startMs = cursorMs, durationMs = durationMs))
            cursorMs += durationMs
        }
    }
    fun updateClip(clip: TimelineClip) = viewModelScope.launch { timelineDao.update(clip) }
    fun deleteClip(clipId: Long, projectId: Long) = viewModelScope.launch { timelineDao.delete(clipId, projectId) }
    fun deleteMedia(assetId: Long, projectId: Long) = viewModelScope.launch { mediaDao.delete(assetId, projectId) }
    fun saveSettings(id: Long, format: String, duration: Int, language: String) = viewModelScope.launch {
        dao.updateSettings(id, format, duration, language)
    }
    fun saveContent(project: VideoProject, topic: String, script: String, title: String, description: String, tags: String) = viewModelScope.launch {
        dao.updateContent(project.id, topic, script, title, description, tags)
    }
    fun deleteProject(id: Long) = viewModelScope.launch { dao.delete(id) }
    companion object {
        fun factory(dao: ProjectDao, mediaDao: MediaAssetDao, timelineDao: TimelineDao) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(dao, mediaDao, timelineDao) as T
        }
    }
}

@Composable
private fun VideonexApp(vm: HomeViewModel) {
    val projects by vm.projects.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf("Bosh sahifa") }
    var showCreate by remember { mutableStateOf(false) }
    var selectedProject by remember { mutableStateOf<VideoProject?>(null) }
    Scaffold(containerColor = Black, bottomBar = {
        NavigationBar(containerColor = Panel) {
            val tabs = listOf("Bosh sahifa", "AI Studio", "Loyihalar", "Sozlamalar")
            tabs.forEach { item ->
                NavigationBarItem(selected = tab == item, onClick = { tab = item },
                    icon = { Icon(when (item) { "Bosh sahifa" -> Icons.Default.Home; "AI Studio" -> Icons.Default.AutoAwesome; "Loyihalar" -> Icons.Default.FolderOpen; else -> Icons.Default.Settings }, null) },
                    label = { Text(item, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold,
                        indicatorColor = Color(0xFF342A17), unselectedIconColor = Muted, unselectedTextColor = Muted))
            }
        }
    }) { padding ->
        when (tab) {
            "Bosh sahifa" -> HomePage(projects, Modifier.padding(padding), onCreate = { showCreate = true }, onOpen = { selectedProject = it })
            "AI Studio" -> StudioPage(projects, Modifier.padding(padding), onOpen = { selectedProject = it })
            "Loyihalar" -> ProjectsPage(projects, Modifier.padding(padding), onOpen = { selectedProject = it }, onCreate = { showCreate = true })
            else -> SettingsPage(Modifier.padding(padding))
        }
    }
    if (showCreate) CreateProjectDialog(onDismiss = { showCreate = false }, onCreate = { name, direction -> vm.addProject(name, direction); showCreate = false })
    selectedProject?.let { project ->
        val assets by vm.assetsFor(project.id).collectAsStateWithLifecycle(initialValue = emptyList())
        val clips by vm.timelineFor(project.id).collectAsStateWithLifecycle(initialValue = emptyList())
        ProjectWorkspace(project = project, assets = assets, clips = clips, onDismiss = { selectedProject = null },
            onSaveSettings = { format, duration, language -> vm.saveSettings(project.id, format, duration, language) },
            onSaveContent = { topic, script, title, description, tags -> vm.saveContent(project, topic, script, title, description, tags) },
            onAddMedia = { uri, name, mime -> vm.addMedia(project.id, uri, name, mime) },
            onBuildImageTimeline = { scenes -> vm.buildImageTimeline(project.id, scenes) },
            onDeleteMedia = { assetId -> vm.deleteMedia(assetId, project.id) },
            onUpdateClip = { vm.updateClip(it) },
            onDeleteClip = { vm.deleteClip(it, project.id) },
            onDelete = { vm.deleteProject(project.id); selectedProject = null })
    }
}

@Composable
private fun PageHeader(subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("VIDEONEX", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(subtitle.uppercase(), color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        }
        Box(Modifier.size(44.dp).background(Panel, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("V", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HomePage(projects: List<VideoProject>, modifier: Modifier, onCreate: () -> Unit, onOpen: (VideoProject) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageHeader("AI Video Creator") }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) {
                Text("Xush kelibsiz!", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("G‘oyangizni video loyihaga aylantiring.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                GoldButton("＋  YANGI VIDEO YARATISH", onCreate)
            }
        }
        item { Text("LOYIHALAR STATISTIKASI", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Loyihalar", projects.size.toString(), Modifier.weight(1f))
                StatCard("Ssenariylar", projects.count { it.script.isNotBlank() }.toString(), Modifier.weight(1f))
                StatCard("SEO tayyor", projects.count { it.seoTitle.isNotBlank() }.toString(), Modifier.weight(1f))
            }
        }
        item { Text("SO‘NGGI LOYIHALAR", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp) }
        if (projects.isEmpty()) item { EmptyPanel() } else items(projects.take(5), key = { it.id }) { ProjectCard(it) { onOpen(it) } }
        item { InfoPanel("ESLATMA", "Hozirgi versiyada loyiha va matnlar telefon xotirasida saqlanadi. Haqiqiy onlayn AI generatsiyasi API ulanishi qo‘shilgandan keyin ishlaydi.") }
    }
}

@Composable
private fun StudioPage(projects: List<VideoProject>, modifier: Modifier, onOpen: (VideoProject) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageHeader("AI Studio") }
        item { InfoPanel("ISH JARAYONI", "Loyihani tanlang. VIDEONEX AI mavzu, to‘liq ssenariy va YouTube SEO yaratadi. Buning uchun Sozlamalar bo‘limida AI API ulanishi sozlangan bo‘lishi kerak.") }
        item { Text("LOYIHANI TANLANG", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        if (projects.isEmpty()) item { EmptyPanel("Avval bosh sahifadan loyiha yarating.") }
        else items(projects, key = { it.id }) { project ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onOpen(project) }.padding(15.dp)) {
                Text(project.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("${project.direction} • ${project.durationMinutes} daqiqa • ${project.language}", color = Muted, fontSize = 11.sp)
                Text(if (project.script.isBlank()) "Ssenariy hali yo‘q — ochish" else "Ssenariy saqlangan — tahrirlash", color = Gold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ProjectsPage(projects: List<VideoProject>, modifier: Modifier, onOpen: (VideoProject) -> Unit, onCreate: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Loyihalar") }
        item { GoldButton("＋  YANGI LOYIHA", onCreate) }
        if (projects.isEmpty()) item { EmptyPanel() } else items(projects, key = { it.id }) { ProjectCard(it) { onOpen(it) } }
    }
}

@Composable
private fun SettingsPage(modifier: Modifier) {
    val context = LocalContext.current
    val config = remember { AiClient.config(context) }
    var endpoint by remember { mutableStateOf(config.endpoint) }
    var model by remember { mutableStateOf(config.model) }
    var apiKey by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(if (config.hasKey) "API kaliti xavfsiz saqlangan." else "API hali ulanmagan.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Sozlamalar") }
        item { InfoPanel("ILOVA", "VIDEONEX • Created by Me\nVersiya: 0.16.0-dev\nDizayn: qora va oltin") }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionLabel("AI API ULANISHI")
                Text("OpenAI-compatible API manzili", color = Muted, fontSize = 11.sp)
                OutlinedTextField(endpoint, { endpoint = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://.../v1") })
                Text("Model nomi", color = Muted, fontSize = 11.sp)
                OutlinedTextField(model, { model = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("model-name") })
                Text("API kaliti (telefon ichida shifrlanadi)", color = Muted, fontSize = 11.sp)
                OutlinedTextField(apiKey, { apiKey = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), placeholder = { Text(if (config.hasKey) "Saqlangan kalit bor — yangilash uchun kiriting" else "API key") })
                GoldButton("API SOZLAMALARINI SAQLASH") {
                    AiClient.saveConfig(context, endpoint, model, apiKey)
                    apiKey = ""
                    status = "Sozlamalar saqlandi. Kalit Android Keystore orqali shifrlanadi."
                }
                OutlinedButton(onClick = {
                    AiClient.clearApiKey(context)
                    apiKey = ""
                    status = "API kaliti telefondan o‘chirildi."
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) {
                    Text("SAQLANGAN API KALITINI O‘CHIRISH")
                }
                OutlinedButton(onClick = {
                    AiClient.saveConfig(context, endpoint, model, apiKey)
                    apiKey = ""
                    busy = true
                    status = "Ulanish tekshirilmoqda..."
                    scope.launch {
                        status = try {
                            withContext(Dispatchers.IO) { AiClient.generate(context, "Reply with exactly: VIDEONEX_OK") }
                            "AI javobi olindi. API ulanishi ishlayapti."
                        } catch (e: Exception) { "Ulanish xatosi: ${e.message ?: "Noma’lum xato"}" }
                        busy = false
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "TEKSHIRILMOQDA..." else "AI ULANISHINI TEKSHIRISH", color = Gold) }
                Text(status, color = if (status.contains("xato", true)) Red else Muted, fontSize = 11.sp)
                Text("Eslatma: endpoint, model va API kaliti xizmat ko‘rsatuvchi provayderga mos bo‘lishi kerak. Bepul limitlar provayderga bog‘liq; pullik tarif avtomatik yoqilmaydi.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        item { InfoPanel("MAXFIYLIK", "Loyihalar telefondagi Room bazasida saqlanadi. API kaliti Android Keystore yordamida shifrlanadi. AI so‘rovlari tanlangan provayderga internet orqali yuboriladi.") }
        item { InfoPanel("VIDEO EKSPORT", "Hozirgi sinov manbasida rasm, video va audio qatlamlarini MP4 ga eksport qilish moduli mavjud. Ayrim murakkab montaj imkoniyatlari hali to‘liq emas; eksport natijasini qurilmada tekshirish talab qilinadi.") }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(13.dp)).padding(11.dp)) {
        Text(value, color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ProjectCard(project: VideoProject, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(Color(0xFF302719), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Movie, null, tint = Gold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(project.name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(project.direction, color = Muted, fontSize = 11.sp)
            Text("${project.format} • ${project.durationMinutes} daq. • ${project.language}", color = Gold, fontSize = 10.sp)
        }
        Text("›", color = Gold, fontSize = 24.sp)
    }
}

@Composable
private fun EmptyPanel(message: String = "Hozircha loyiha yo‘q. Birinchi loyihangizni yarating.") {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.FolderOpen, null, tint = Gold, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(8.dp)); Text(message, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun InfoPanel(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text(body, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun GoldButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(13.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text(label, fontWeight = FontWeight.Bold) }
}

@Composable
private fun CreateProjectDialog(onDismiss: () -> Unit, onCreate: (String, String) -> Unit) {
    val directions = listOf("Tarixiy POV", "Tarix", "Biznes va Finance", "Tarixdagi g‘alati ishlar", "Qadimgi odamlar", "Inson ongi va falsafa", "Horror hikoyalar", "Jamiyat psixologiyasi", "Tibbiyot va salomatlik", "Wojak Doomer", "Brendlar va korporatsiyalar tarixi")
    var name by remember { mutableStateOf("") }; var direction by remember { mutableStateOf(directions.first()) }; var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Yangi loyiha", color = Gold) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Loyiha nomi") }, singleLine = true)
            Text("Video yo‘nalishini tanlang", color = Muted, fontSize = 12.sp)
            Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(direction, color = Color.White) }
                DropdownMenu(expanded, { expanded = false }) { directions.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { direction = it; expanded = false }) } }
            }
        } }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim(), direction) }, enabled = name.isNotBlank()) { Text("YARATISH", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BEKOR", color = Muted) } })
}

@Composable
private fun ProjectWorkspace(project: VideoProject, assets: List<MediaAsset>, clips: List<TimelineClip>, onDismiss: () -> Unit,
    onSaveSettings: (String, Int, String) -> Unit,
    onSaveContent: (String, String, String, String, String) -> Unit,
    onAddMedia: (String, String, String) -> Unit,
    onBuildImageTimeline: (List<Pair<String, Long>>) -> Unit,
    onDeleteMedia: (Long) -> Unit,
    onUpdateClip: (TimelineClip) -> Unit,
    onDeleteClip: (Long) -> Unit,
    onDelete: () -> Unit) {
    var format by remember(project.id) { mutableStateOf(project.format) }
    var duration by remember(project.id) { mutableStateOf(project.durationMinutes.toString()) }
    var language by remember(project.id) { mutableStateOf(project.language) }
    var topic by remember(project.id) { mutableStateOf(project.topic) }
    var script by remember(project.id) { mutableStateOf(project.script) }
    var seoTitle by remember(project.id) { mutableStateOf(project.seoTitle) }
    var seoDescription by remember(project.id) { mutableStateOf(project.seoDescription) }
    var seoTags by remember(project.id) { mutableStateOf(project.seoTags) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var aiBusy by remember { mutableStateOf(false) }
    var aiStatus by remember { mutableStateOf("") }
    var topicIdeas by remember { mutableStateOf(listOf<String>()) }
    val context = LocalContext.current
    var storyboard by remember(project.id) { mutableStateOf(listOf<StoryScene>()) }
    LaunchedEffect(project.id) { storyboard = withContext(Dispatchers.IO) { readStoryboard(context, project.id) } }
    // Debounced local autosave: preserve edits even if the user leaves the project screen.
    LaunchedEffect(project.id, topic, script, seoTitle, seoDescription, seoTags) {
        delay(600)
        onSaveContent(topic, script, seoTitle, seoDescription, seoTags)
    }
    var pendingAiTask by remember { mutableStateOf("") }
    var exporting by remember { mutableStateOf(false) }
    var exportStatus by remember { mutableStateOf("") }
    var exportProgress by remember { mutableFloatStateOf(0f) }
    var exportJob by remember { mutableStateOf<ExportJob?>(null) }
    var exportResolution by remember(project.id) { mutableIntStateOf(720) }
    var exportFps by remember(project.id) { mutableIntStateOf(30) }
    val scope = rememberCoroutineScope()
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selectedUris ->
        selectedUris.forEach { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val name = queryDisplayName(context, uri)
            onAddMedia(uri.toString(), name, mime)
        }
    }
    var pendingImageScene by remember { mutableIntStateOf(-1) }
    var pendingUploadedImageUris by remember { mutableStateOf(listOf<String>()) }
    val orderedImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selectedUris ->
        if (selectedUris.isNotEmpty()) {
            selectedUris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            }
            // Keep the exact order returned by the Android document picker; never sort by filename or AI relevance.
            pendingUploadedImageUris = selectedUris.map { it.toString() }
            if (script.isBlank()) aiStatus = "Avval ssenariyni kiriting yoki yarating."
            else startAi("map_uploaded_images")
        }
    }
    val sceneImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val index = pendingImageScene
        pendingImageScene = -1
        if (uri != null && index in storyboard.indices) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            storyboard = storyboard.toMutableList().also { it[index] = it[index].copy(imageUri = uri.toString()) }
            saveStoryboard(context, project.id, storyboard)
            aiStatus = "Rasm ${storyboard[index].number}-sahnaga biriktirildi."
        }
    }
    fun startAi(task: String) {
        if (!aiBusy) pendingAiTask = task
    }
    fun runAi(task: String) {
        if (aiBusy) return
        pendingAiTask = ""
        val prompt = when (task) {
            "topics" -> "You are a professional YouTube research producer. Create exactly 5 distinct, clickable video topic ideas for direction: ${project.direction}. Output language: $language. Video format: $format. Planned duration: $duration minutes. Do not write a script. For each idea give a short title and one-sentence hook. Avoid generic/repeated ideas. Return numbered list only."
            "script" -> "Write a complete, engaging YouTube video script in $language. Topic: $topic. Channel direction: ${project.direction}. Format: $format. Target duration: $duration minutes. Include a powerful opening hook, coherent sections, transitions, and a memorable ending. Adapt length and pacing to the requested duration. Do not invent facts. Mark claims that need verification and include a short list of 2-3 reliable source types or source URLs when known. Return only the script with section headings."
            "map_uploaded_images" -> "You are a professional video editor. Divide the following complete script into EXACTLY ${pendingUploadedImageUris.size} consecutive chronological visual segments, one segment for each user-uploaded image. The image order is fixed and MUST NOT be changed: image 1 belongs to segment 1 and the opening part of the script; image 2 belongs to segment 2 and the next part; continue in the same order until the final image and final script section. Do not reorder, rank, or semantically reshuffle images. Cover the entire script without omissions or repeated narration. Estimate durationSeconds for each segment so total duration is proportional to the narration. Return title, faithful narration excerpt, detailed English imagePrompt describing what the corresponding image should depict, cameraMotion, visualStyle. Output title/narration in $language. Return valid JSON only: {\"scenes\":[{\"number\":1,\"title\":\"...\",\"durationSeconds\":8,\"narration\":\"...\",\"imagePrompt\":\"...\",\"cameraMotion\":\"...\",\"visualStyle\":\"...\"}]}. Script: ${script.take(24000)}"
            "storyboard" -> "You are a professional film storyboard planner. Split the following complete script into meaningful chronological visual scenes. Create enough scenes to cover the entire script; do not omit important narration. For each scene estimate durationSeconds, include a short title, the exact/faithful narration excerpt, a detailed English imagePrompt suitable for cinematic image generation (describe subject, setting, action, composition, lighting, camera lens, aspect ratio $format), cameraMotion (simple motion suitable for animating a still image), and visualStyle. Keep characters, clothing, locations, and color palette visually consistent across scenes. Output language for title and narration: $language. Return valid JSON only: {\"scenes\":[{\"number\":1,\"title\":\"...\",\"durationSeconds\":8,\"narration\":\"...\",\"imagePrompt\":\"...\",\"cameraMotion\":\"...\",\"visualStyle\":\"...\"}]}. Do not wrap JSON in markdown. Topic: $topic. Script: ${script.take(24000)}"
            else -> "Create YouTube SEO in $language for this video. Direction: ${project.direction}. Topic: $topic. Script: ${script.take(9000)}. Return valid JSON only with keys: title (best title), title_variants (array of 5), description, tags (array), hashtags (array), thumbnail_ideas (array of 3). Make it relevant, natural, searchable, and not keyword-stuffed. Never claim guaranteed views."
        }
        aiBusy = true
        aiStatus = "AI javobi kutilmoqda..."
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val research = if (task == "script") ResearchClient.search(topic, language) else ""
                    val finalPrompt = if (task == "script") {
                        "$prompt\n\n$research\n\nManbalarni ssenariy oxirida havolalari bilan ko‘rsat. Topilmagan faktlarni to‘qima; tekshirilmagan da'volarni alohida belgilab qo‘y."
                    } else prompt
                    AiClient.generate(context, finalPrompt)
                }
                when (task) {
                    "topics" -> {
                        topicIdeas = result.lines().map { it.trim().replace(Regex("^[-*•0-9.) ]+"), "").trim() }.filter { it.length > 5 }.take(5)
                        aiStatus = if (topicIdeas.isNotEmpty()) "5 ta mavzu tayyor. Tanlash uchun pastdagi variantni bosing." else "AI javobi olindi, lekin mavzularni ajratib bo‘lmadi. Matnni qayta yarating."
                    }
                    "script" -> {
                        script = result
                        onSaveContent(topic, result, seoTitle, seoDescription, seoTags)
                        aiStatus = "AI ssenariy yaratdi va loyiha ichiga saqladi."
                    }
                    "map_uploaded_images" -> {
                        val array = org.json.JSONObject(result.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()).optJSONArray("scenes")
                            ?: throw IllegalArgumentException("AI javobida scenes ro‘yxati topilmadi")
                        val parsed = (0 until array.length()).mapNotNull { i ->
                            val o = array.optJSONObject(i) ?: return@mapNotNull null
                            val imageUri = pendingUploadedImageUris.getOrNull(i).orEmpty()
                            StoryScene(i + 1, o.optString("title", "Sahna ${i + 1}"),
                                o.optInt("durationSeconds", 8).coerceIn(1, 600), o.optString("narration"),
                                o.optString("imagePrompt"), o.optString("cameraMotion"), o.optString("visualStyle"), imageUri)
                        }
                        if (parsed.size != pendingUploadedImageUris.size) throw IllegalArgumentException("AI ${pendingUploadedImageUris.size} ta rasm uchun yetarli sahna qaytarmadi. Qayta urinib ko‘ring.")
                        storyboard = parsed
                        withContext(Dispatchers.IO) { saveStoryboard(context, project.id, parsed) }
                        aiStatus = "${parsed.size} ta rasm yuklangan tartibida ssenariyga biriktirildi. Rasm tartibi o‘zgartirilmadi."
                        pendingUploadedImageUris = emptyList()
                    }
                    "storyboard" -> {
                        val array = org.json.JSONObject(result.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()).optJSONArray("scenes")
                            ?: throw IllegalArgumentException("AI javobida scenes ro‘yxati topilmadi")
                        val parsed = (0 until array.length()).mapNotNull { i ->
                            val o = array.optJSONObject(i) ?: return@mapNotNull null
                            StoryScene(o.optInt("number", i + 1), o.optString("title", "Sahna ${i + 1}"),
                                o.optInt("durationSeconds", 8).coerceIn(1, 600), o.optString("narration"),
                                o.optString("imagePrompt"), o.optString("cameraMotion"), o.optString("visualStyle"))
                        }
                        if (parsed.isEmpty()) throw IllegalArgumentException("Sahnalar ro‘yxati bo‘sh")
                        storyboard = parsed
                        withContext(Dispatchers.IO) { saveStoryboard(context, project.id, parsed) }
                        aiStatus = "${parsed.size} ta sahna yaratildi va telefonda saqlandi."
                    }
                    else -> {
                        val json = org.json.JSONObject(result)
                        seoTitle = json.optString("title", "")
                        seoDescription = buildString {
                            append(json.optString("description", ""))
                            val variants = json.optJSONArray("title_variants")
                            if (variants != null) { append("\n\nSarlavha variantlari:"); for (i in 0 until variants.length()) append("\n${i + 1}. ${variants.optString(i)}") }
                            val thumbs = json.optJSONArray("thumbnail_ideas")
                            if (thumbs != null) { append("\n\nThumbnail g‘oyalari:"); for (i in 0 until thumbs.length()) append("\n${i + 1}. ${thumbs.optString(i)}") }
                        }
                        val tags = json.optJSONArray("tags")
                        val hashes = json.optJSONArray("hashtags")
                        seoTags = (0 until (tags?.length() ?: 0)).map { tags!!.optString(it) }.plus((0 until (hashes?.length() ?: 0)).map { hashes!!.optString(it) }).joinToString(", ")
                        onSaveContent(topic, script, seoTitle, seoDescription, seoTags)
                        aiStatus = "AI SEO tayyorladi va loyiha ichiga saqladi."
                    }
                }
            } catch (e: Exception) { aiStatus = "AI xatosi: ${e.message ?: "Noma’lum xato"}" }
            aiBusy = false
        }
    }
    val durationNumber = duration.toIntOrNull()
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.94f), shape = RoundedCornerShape(20.dp), color = Panel) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(project.name, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(project.direction, color = Muted, fontSize = 11.sp) }
                    TextButton(onClick = onDismiss) { Text("YOPISH", color = Gold) }
                }
                Divider(color = Color(0xFF3A3325)); Spacer(Modifier.height(10.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    SectionLabel("VIDEO SOZLAMALARI")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("9:16 Shorts", "16:9 Long").forEach { FilterChip(selected = format == it, onClick = { format = it }, label = { Text(it) }) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), label = { Text("Davomiylik (daq.)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        Spacer(Modifier.width(8.dp))
                        Column { listOf("O‘zbek", "English", "Русский").forEach { TextButton(onClick = { language = it }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text(if (language == it) "● $it" else it, color = if (language == it) Gold else Muted, fontSize = 10.sp) } } }
                    }
                    if (durationNumber == null || durationNumber !in 1..240) Text("Davomiylik 1–240 daqiqa oralig‘ida bo‘lsin.", color = Red, fontSize = 11.sp)
                    GoldButton("SOZLAMALARNI SAQLASH") { if (durationNumber != null && durationNumber in 1..240) onSaveSettings(format, durationNumber, language) }
                    Divider(color = Color(0xFF3A3325)); SectionLabel("LOYIHA MEDIA FAYLLARI")
                    Text("Rasm, video va audio fayllarni telefoningdan tanla. Fayllarning o‘zi telefonda qoladi; VIDEONEX ularning xavfsiz URI manzilini loyiha bilan bog‘laydi.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                    GoldButton("＋  RASM / VIDEO / AUDIO QO‘SHISH") { mediaPicker.launch(arrayOf("image/*", "video/*", "audio/*")) }
                    if (assets.isEmpty()) Text("Hozircha media fayl qo‘shilmagan.", color = Muted, fontSize = 11.sp)
                    assets.forEach { asset ->
                        Row(Modifier.fillMaxWidth().background(Black, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (asset.mimeType.startsWith("image/")) Icons.Default.Movie else Icons.Default.FolderOpen, null, tint = Gold)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(asset.displayName, color = Color.White, fontSize = 12.sp, maxLines = 2)
                                Text(asset.mimeType, color = Muted, fontSize = 9.sp)
                            }
                            TextButton(onClick = { onDeleteMedia(asset.id) }) { Text("O‘CHIRISH", color = Red, fontSize = 9.sp) }
                        }
                    }
                    if (clips.any { it.trackIndex == 0 || it.trackIndex == 1 }) {
                        SectionLabel("EKSPORT SIFATI")
                        Text("O‘lcham (qisqa tomon):", color = Muted, fontSize = 11.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { exportResolution = 720 }, enabled = !exporting, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (exportResolution == 720) Gold else Muted)) { Text(if (exportResolution == 720) "✓ 720p" else "720p") }
                            OutlinedButton(onClick = { exportResolution = 1080 }, enabled = !exporting, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (exportResolution == 1080) Gold else Muted)) { Text(if (exportResolution == 1080) "✓ 1080p" else "1080p") }
                        }
                        Text("Kadr tezligi:", color = Muted, fontSize = 11.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { exportFps = 24 }, enabled = !exporting, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (exportFps == 24) Gold else Muted)) { Text(if (exportFps == 24) "✓ 24 FPS" else "24 FPS") }
                            OutlinedButton(onClick = { exportFps = 30 }, enabled = !exporting, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = if (exportFps == 30) Gold else Muted)) { Text(if (exportFps == 30) "✓ 30 FPS" else "30 FPS") }
                        }
                        GoldButton(if (exporting) "MP4 TAYYORLANMOQDA..." else "▶  TIMELINE'NI MP4 EKSPORT QILISH") {
                            if (!exporting) {
                                exporting = true
                                exportProgress = 0f
                                exportStatus = "Timeline eksporti boshlandi..."
                                exportJob = VideoExportManager.exportProject(context, assets, clips,
                                    settings = ExportSettings(shortSide = exportResolution, frameRate = exportFps),
                                    onComplete = { file ->
                                        exporting = false
                                        exportJob = null
                                        exportProgress = 1f
                                        exportStatus = "MP4 tayyor. Galereyaga saqlanmoqda..."
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    VideoExportManager.saveToGallery(context, file)
                                                }
                                                exportStatus = "MP4 Galereya → Movies/VIDEONEX papkasiga saqlandi."
                                            } catch (error: Exception) {
                                                exportStatus = "MP4 tayyor, lekin Galereyaga saqlanmadi: ${error.message ?: "xatolik"}. Ilova Movies papkasida saqlangan."
                                            }
                                        }
                                    },
                                    onError = { message -> exporting = false; exportJob = null; exportStatus = "Eksport xatosi: $message" },
                                    onProgress = { value -> exportProgress = value.coerceIn(0, 100) / 100f },
                                    onCancelled = { exporting = false; exportJob = null; exportProgress = 0f; exportStatus = "Eksport bekor qilindi." })
                                if (exportJob == null) exporting = false
                            }
                        }
                        if (exporting) {
                            LinearProgressIndicator(progress = exportProgress, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Black)
                            Text("Eksport: ${(exportProgress * 100).toInt()}%", color = Gold, fontSize = 11.sp)
                            OutlinedButton(onClick = { exportJob?.cancel() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Text("EKSPORTNI BEKOR QILISH") }
                        }
                        if (exportStatus.isNotBlank()) Text(exportStatus, color = Gold, fontSize = 10.sp)
                        Text("Tanlangan sifat maqsadli o‘lchamdir: 720p yoki 1080p, 24 yoki 30 FPS. Yakuniy kodlash qurilma encoder imkoniyatiga bog‘liq; mos kelmasa eksport xato beradi. MP4 Galereya → Movies/VIDEONEX papkasiga saqlanadi (Android 10+).", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI AUDIO–IMAGE SYNC")
                    Text("Ovoz faylining haqiqiy davomiyligini o‘qib, rasmlarni yuklangan ketma-ketlikda butun audio vaqtiga taqsimlaydi. Har bir sahna ulushi uning ovoz matni uzunligiga qarab hisoblanadi. Bu so‘zma-so‘z lab-sinxron emas; aniq nutq segmentlari uchun keyin speech-to-text vaqt belgilari kerak bo‘ladi.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    GoldButton("♫  RASMLARNI OVOZGA MOSLASHTIRISH") {
                        val audioClip = clips.filter { it.trackIndex >= 2 }.minByOrNull { it.startMs }
                        val audioAsset = audioClip?.let { a -> assets.firstOrNull { it.id == a.mediaAssetId } }
                        val imageClips = clips.filter { it.trackIndex == 0 }.sortedWith(compareBy<TimelineClip> { it.startMs }.thenBy { it.id })
                        if (audioAsset == null || audioClip == null) {
                            aiStatus = "Avval loyiha uchun audio/ovoz faylini yuklang."
                        } else if (imageClips.isEmpty()) {
                            aiStatus = "Avval rasmlarni storyboard orqali timeline’ga joylashtiring."
                        } else {
                            scope.launch {
                                try {
                                    val totalMs = withContext(Dispatchers.IO) {
                                        val retriever = MediaMetadataRetriever()
                                        try {
                                            retriever.setDataSource(context, Uri.parse(audioAsset.uri))
                                            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                                        } finally { retriever.release() }
                                    }
                                    if (totalMs <= 0L) {
                                        aiStatus = "Audio davomiyligini aniqlab bo‘lmadi. Boshqa audio faylni sinab ko‘ring."
                                    } else {
                                        val matched = imageClips.map { clip ->
                                            val asset = assets.firstOrNull { it.id == clip.mediaAssetId }
                                            val scene = storyboard.firstOrNull { it.imageUri.isNotBlank() && it.imageUri == asset?.uri }
                                            // Estimate speaking time by word count; if narration is empty, use the scene's manual duration.
                                            val words = scene?.narration?.trim()?.split(Regex("\\s+"))?.count { it.isNotBlank() } ?: 0
                                            clip to (if (words > 0) words.toLong() else scene?.durationSeconds?.coerceAtLeast(1)?.toLong() ?: 1L)
                                        }
                                        val totalWeight = matched.sumOf { it.second }.coerceAtLeast(1L)
                                        var cursor = 0L
                                        matched.forEachIndexed { index, pair ->
                                            val durationPart = if (index == matched.lastIndex) totalMs - cursor else (totalMs * pair.second / totalWeight).coerceAtLeast(1L)
                                            val safeDuration = durationPart.coerceAtLeast(1L)
                                            onUpdateClip(pair.first.copy(startMs = cursor, durationMs = safeDuration))
                                            cursor += safeDuration
                                        }
                                        onUpdateClip(audioClip.copy(startMs = 0L, durationMs = totalMs))
                                        aiStatus = "Tayyor: ${imageClips.size} ta rasm $totalMs ms audio davomiyligiga yuklangan tartibda moslandi."
                                    }
                                } catch (e: Exception) {
                                    aiStatus = "Audio tahlilida xato: ${e.message ?: "noma’lum xato"}"
                                }
                            }
                        }
                    }
                    if (aiStatus.isNotBlank()) Text(aiStatus, color = Gold, fontSize = 10.sp)
                    Divider(color = Color(0xFF3A3325)); SectionLabel("MONTAJ TIMELINE")
                    Text("Rasmlar asosiy qatlamga, videolar ustki PIP qatlamiga, audiolar alohida audio trekka joylanadi. PIP videosining o‘lchami va ekrandagi joyini slayderlar bilan sozlang. Boshlanish va davomiylik millisekundlarda tahrirlanadi.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                    if (clips.isEmpty()) Text("Timeline hozircha bo‘sh. Avval rasm, video yoki audio qo‘shing.", color = Muted, fontSize = 11.sp)
                    clips.forEach { clip ->
                        val asset = assets.firstOrNull { it.id == clip.mediaAssetId }
                        var startText by remember(clip.id, clip.startMs) { mutableStateOf(clip.startMs.toString()) }
                        var lengthText by remember(clip.id, clip.durationMs) { mutableStateOf(clip.durationMs.toString()) }
                        var clipVolume by remember(clip.id, clip.volume) { mutableFloatStateOf(clip.volume.coerceIn(0f, 1f)) }
                        var overlayScale by remember(clip.id, clip.overlayScale) { mutableFloatStateOf(clip.overlayScale.coerceIn(0.15f, 0.80f)) }
                        var overlayX by remember(clip.id, clip.overlayX) { mutableFloatStateOf(clip.overlayX.coerceIn(-0.85f, 0.85f)) }
                        var overlayY by remember(clip.id, clip.overlayY) { mutableFloatStateOf(clip.overlayY.coerceIn(-0.85f, 0.85f)) }
                        Column(Modifier.fillMaxWidth().background(Black, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(asset?.displayName ?: "Media #${clip.mediaAssetId}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("${when (clip.trackIndex) { 0 -> "ASOSIY RASM QATLAMI"; 1 -> "USTKI VIDEO PIP QATLAMI"; else -> "AUDIO TREKI" }} · Trek ${clip.trackIndex + 1}", color = Muted, fontSize = 9.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(startText, { startText = it.filter(Char::isDigit).take(9) }, modifier = Modifier.weight(1f), label = { Text("Boshlanish (ms)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                OutlinedTextField(lengthText, { lengthText = it.filter(Char::isDigit).take(9) }, modifier = Modifier.weight(1f), label = { Text("Davomiylik (ms)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                            }
                            if (clip.trackIndex >= 2) {
                                Text("AUDIO OVOZI: ${(clipVolume * 100).toInt()}%", color = Muted, fontSize = 10.sp)
                                Slider(value = clipVolume, onValueChange = { clipVolume = it }, valueRange = 0f..1f, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Muted))
                            }
                            if (clip.trackIndex == 1) {
                                Text("PIP O‘LCHAMI: ${(overlayScale * 100).toInt()}%", color = Muted, fontSize = 10.sp)
                                Slider(value = overlayScale, onValueChange = { overlayScale = it }, valueRange = 0.15f..0.80f, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Muted))
                                Text("GORIZONTAL JOYLASHUV: ${(overlayX * 100).toInt()}", color = Muted, fontSize = 10.sp)
                                Slider(value = overlayX, onValueChange = { overlayX = it }, valueRange = -0.85f..0.85f, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Muted))
                                Text("VERTIKAL JOYLASHUV: ${(overlayY * 100).toInt()}", color = Muted, fontSize = 10.sp)
                                Slider(value = overlayY, onValueChange = { overlayY = it }, valueRange = -0.85f..0.85f, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Muted))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { val start = startText.toLongOrNull(); val len = lengthText.toLongOrNull(); if (start != null && len != null && start >= 0 && len > 0) onUpdateClip(clip.copy(startMs = start, durationMs = len, volume = clipVolume, overlayScale = overlayScale, overlayX = overlayX, overlayY = overlayY)) }) { Text("SAQLASH", color = Gold, fontSize = 10.sp) }
                                TextButton(onClick = { onDeleteClip(clip.id) }) { Text("TREKDAN OLIB TASHLASH", color = Red, fontSize = 10.sp) }
                            }
                        }
                    }
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI MAVZU YARATISH")
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  AI 5 TA MAVZU TAKLIF QILSIN") { startAi("topics") }
                    topicIdeas.forEachIndexed { index, idea ->
                        TextButton(onClick = { topic = idea; onSaveContent(idea, script, seoTitle, seoDescription, seoTags) }, modifier = Modifier.fillMaxWidth()) {
                            Text("${index + 1}. $idea", color = if (topic == idea) Gold else Color.White)
                        }
                    }
                    OutlinedTextField(topic, { topic = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Tanlangan mavzu (AI natijasi)") }, minLines = 2)
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI SSENARIY YARATISH")
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  AI TO‘LIQ SSENARIY YOZSIN") { if (topic.isBlank()) aiStatus = "Avval AI mavzu yaratsin va bittasini tanlang." else startAi("script") }
                    OutlinedTextField(script, { script = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp), label = { Text("AI yaratgan ssenariy — tahrirlash mumkin") }, minLines = 6)
                    OutlinedButton(onClick = { script = offlineOutline(project, topic, language); aiStatus = "Oflayn reja yaratildi. Bu haqiqiy AI javobi emas." }, modifier = Modifier.fillMaxWidth()) { Text("OFLAYN REJA (AI ULANMAGANDA)", color = Gold) }
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI STORYBOARD — SAHNALAR VA RASM PROMPTLARI")
                    Text("AI to‘liq ssenariyni ketma-ket sahnalarga ajratadi. Har bir sahnada davomiylik, ovoz matni, rasm prompti va kamera harakati bo‘ladi.", color = Muted, fontSize = 11.sp)
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  SSENARIYDAN SAHNALAR YARATISH") {
                        if (script.isBlank()) aiStatus = "Avval to‘liq ssenariy yarating yoki kiriting." else startAi("storyboard")
                    }
                    OutlinedButton(onClick = {
                        if (script.isBlank()) aiStatus = "Avval ssenariyni kiriting yoki yarating."
                        else orderedImagePicker.launch(arrayOf("image/*"))
                    }, modifier = Modifier.fillMaxWidth(), enabled = !aiBusy) {
                        Text("RASMLARNI KETMA-KET YUKLASH VA SSENARIYGA MOSLASH", color = Gold)
                    }
                    Text("Yuklangan rasmlar tartibi qat’iy saqlanadi: 1-rasm — ssenariy boshi, 2-rasm — keyingi qism va hokazo. AI ssenariyni rasmlar soniga teng ketma-ket bo‘laklarga ajratadi. Rasmlar qayta tartiblanmaydi.", color = Muted, fontSize = 10.sp)
                    if (storyboard.isNotEmpty()) {
                        Text("SAHNALAR: ${storyboard.size} TA", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        OutlinedButton(onClick = {
                            val ordered = storyboard.filter { it.imageUri.isNotBlank() }
                                .map { it.imageUri to (it.durationSeconds.coerceAtLeast(1) * 1000L) }
                            if (ordered.isEmpty()) aiStatus = "Avval storyboard sahnalariga rasmlarni biriktiring."
                            else {
                                onBuildImageTimeline(ordered)
                                aiStatus = "${ordered.size} ta rasm yuklangan tartibda timeline’ga joylandi. Eski rasm yo‘lagi yangilandi; audio va video yo‘laklari saqlandi."
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text("RASMLARNI TIMELINE’GA JOYLASHTIRISH", color = Gold)
                        }
                        Text("Rasmlar 1-rasmdan boshlab ketma-ket joylanadi. Har birining davomiyligi storyboard’dagi vaqtga teng. Bu amal faqat asosiy rasm yo‘lagini yangilaydi.", color = Muted, fontSize = 10.sp)
                        storyboard.forEachIndexed { index, scene ->
                            Card(colors = CardDefaults.cardColors(containerColor = Black), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text("${scene.number.toString().padStart(3, '0')} · ${scene.durationSeconds} soniya", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    OutlinedTextField(scene.durationSeconds.toString(), { value ->
                                        val seconds = value.filter { it.isDigit() }.take(4).toIntOrNull()?.coerceIn(1, 3600) ?: 1
                                        storyboard = storyboard.toMutableList().also { it[index] = scene.copy(durationSeconds = seconds) }
                                        saveStoryboard(context, project.id, storyboard)
                                    }, modifier = Modifier.fillMaxWidth(), label = { Text("Sahna davomiyligi (soniya)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    OutlinedTextField(scene.title, { value -> storyboard = storyboard.toMutableList().also { it[index] = scene.copy(title = value) }; saveStoryboard(context, project.id, storyboard) }, modifier = Modifier.fillMaxWidth(), label = { Text("Sahna nomi") }, singleLine = true)
                                    OutlinedTextField(scene.narration, { value -> storyboard = storyboard.toMutableList().also { it[index] = scene.copy(narration = value) }; saveStoryboard(context, project.id, storyboard) }, modifier = Modifier.fillMaxWidth(), label = { Text("Ovoz / ssenariy parchasi") }, minLines = 2)
                                    OutlinedTextField(scene.imagePrompt, { value -> storyboard = storyboard.toMutableList().also { it[index] = scene.copy(imagePrompt = value) }; saveStoryboard(context, project.id, storyboard) }, modifier = Modifier.fillMaxWidth(), label = { Text("Rasm yaratish prompti (English)") }, minLines = 3)
                                    OutlinedTextField(scene.cameraMotion, { value -> storyboard = storyboard.toMutableList().also { it[index] = scene.copy(cameraMotion = value) }; saveStoryboard(context, project.id, storyboard) }, modifier = Modifier.fillMaxWidth(), label = { Text("Kamera harakati") }, minLines = 1)
                                    Text("Uslub: ${scene.visualStyle}", color = Muted, fontSize = 10.sp)
                                    if (scene.imageUri.isNotBlank()) {
                                        AndroidView(
                                            factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
                                            update = { view -> try { view.setImageURI(Uri.parse(scene.imageUri)) } catch (_: Exception) { view.setImageDrawable(null) } },
                                            modifier = Modifier.fillMaxWidth().height(150.dp)
                                        )
                                        Text("RASМ BIRIKTIRILGAN", color = Gold, fontSize = 10.sp)
                                    } else Text("Hali rasm biriktirilmagan", color = Muted, fontSize = 10.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { pendingImageScene = index; sceneImagePicker.launch(arrayOf("image/*")) }) { Text(if (scene.imageUri.isBlank()) "RASМ TANLASH" else "RASМNI ALMASHTIRISH", color = Gold, fontSize = 10.sp) }
                                        if (scene.imageUri.isNotBlank()) TextButton(onClick = { storyboard = storyboard.toMutableList().also { it[index] = it[index].copy(imageUri = "") }; saveStoryboard(context, project.id, storyboard); aiStatus = "Sahna rasmi olib tashlandi." }) { Text("RASМNI O‘CHIRISH", color = Red, fontSize = 10.sp) }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { val text = scene.imagePrompt; android.content.ClipData.newPlainText("VIDEONEX image prompt", text).also { clip -> (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip) } }) { Text("PROMPTNI NUSXALASH", color = Gold, fontSize = 10.sp) }
                                        TextButton(onClick = { storyboard = storyboard.toMutableList().also { it.removeAt(index) }.mapIndexed { i, item -> item.copy(number = i + 1) }; saveStoryboard(context, project.id, storyboard) }) { Text("O‘CHIRISH", color = Red, fontSize = 10.sp) }
                                    }
                                }
                            }
                        }
                        OutlinedButton(onClick = { saveStoryboard(context, project.id, storyboard); aiStatus = "Storyboard saqlandi." }, modifier = Modifier.fillMaxWidth()) { Text("STORYBOARDNI SAQLASH", color = Gold) }
                    } else Text("Hozircha sahnalar yaratilmagan.", color = Muted, fontSize = 11.sp)
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI YOUTUBE SEO")
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  AI SEO TO‘LIQ YARATSIN") { if (topic.isBlank()) aiStatus = "Avval mavzuni tanlang." else startAi("seo") }
                    OutlinedTextField(seoTitle, { seoTitle = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AI sarlavhasi") }, singleLine = true)
                    OutlinedTextField(seoDescription, { seoDescription = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AI tavsifi va thumbnail g‘oyalari") }, minLines = 3)
                    OutlinedTextField(seoTags, { seoTags = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AI teglar va hashtaglar") }, minLines = 2)
                    if (aiStatus.isNotBlank()) Text(aiStatus, color = if (aiStatus.contains("xato", true)) Red else Gold, fontSize = 11.sp)
                    GoldButton("BARCHA MATNLARNI SAQLASH") { onSaveContent(topic, script, seoTitle, seoDescription, seoTags) }
                    OutlinedButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Text("LOYIHANI O‘CHIRISH") }
                }
            }
        }
    }
    if (showDeleteConfirm) AlertDialog(onDismissRequest = { showDeleteConfirm = false }, containerColor = Panel,
        title = { Text("Loyiha o‘chirilsinmi?", color = Gold) }, text = { Text("Bu loyiha va undagi saqlangan matnlar o‘chadi.", color = Muted) },
        confirmButton = { TextButton(onClick = onDelete) { Text("O‘CHIRISH", color = Red) } }, dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("BEKOR", color = Muted) } })
    if (pendingAiTask.isNotBlank()) AlertDialog(
        onDismissRequest = { pendingAiTask = "" }, containerColor = Panel,
        title = { Text("AI so‘roviga ruxsat", color = Gold) },
        text = { Text("Bu amal internetdan foydalanadi. So‘rov tanlangan AI provayderiga yuboriladi; ssenariy yaratishda mavzu bo‘yicha Wikipedia va Crossref ochiq manbalaridan qidiruv ham bajariladi. Ssenariy matni va loyiha ma’lumotlari AI provayderiga yuboriladi. Davom ettirasizmi?", color = Muted) },
        confirmButton = { TextButton(onClick = { runAi(pendingAiTask) }) { Text("DAVOM ETISH", color = Gold) } },
        dismissButton = { TextButton(onClick = { pendingAiTask = "" }) { Text("BEKOR", color = Muted) } }
    )
}

@Composable
private fun SectionLabel(text: String) { Text(text, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }

private fun queryDisplayName(context: android.content.Context, uri: Uri): String {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: (uri.lastPathSegment ?: "Media fayl")
    } catch (_: Exception) { uri.lastPathSegment ?: "Media fayl" }
}

private fun offlineOutline(project: VideoProject, topic: String, language: String): String {
    val subject = topic.ifBlank { "[MAVZUNI KIRITING]" }
    return if (language == "English") """INTRO / HOOK\nOpen with a surprising question about $subject.\n\nCONTEXT\nIntroduce the time, place, people, and background.\n\nMAIN STORY\n1. Explain the first important event.\n2. Show the key conflict or discovery.\n3. Explain the consequences with verifiable details.\n\nENDING\nSummarize the central idea and leave one thoughtful question.\n\nRESEARCH NOTES\nAdd at least 2–3 reliable sources and verify dates, names, and numbers before publishing."""
    else """KIRISH / HOOK\n$subject — tomoshabinni qiziqtiradigan kuchli savol yoki fakt bilan boshlang.\n\nKONTEKST\nVoqea, davr, joy va asosiy qahramonlarni qisqacha tanishtiring.\n\nASOSIY QISM\n1. Birinchi muhim voqea yoki dalilni tushuntiring.\n2. Muammo, qarama-qarshilik yoki kashfiyotni ochib bering.\n3. Natijalar va oqibatlarni misollar bilan ko‘rsating.\n\nYAKUN\nAsosiy xulosani ayting va tomoshabinga o‘ylantiruvchi savol qoldiring.\n\nTEKSHIRUV\nKamida 2–3 ishonchli manba toping. Sana, ism va raqamlarni e’lon qilishdan oldin tekshiring.\n\nESLATMA\nBu ${project.durationMinutes} daqiqalik video uchun tahrirlanadigan reja. Bu matn avtomatik AI tadqiqoti emas."""
}
