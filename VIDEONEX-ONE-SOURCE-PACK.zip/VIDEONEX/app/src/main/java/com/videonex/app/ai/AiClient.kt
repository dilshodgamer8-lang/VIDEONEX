package com.videonex.app.ai

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    private const val PREFS = "videonex_ai_settings"
    data class Config(val endpoint: String, val model: String, val hasKey: Boolean)

    fun saveConfig(context: Context, endpoint: String, model: String, apiKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("endpoint", endpoint.trim()).putString("model", model.trim()).apply()
        if (apiKey.isNotBlank()) SecureKeyStore.save(context, apiKey.trim())
    }

    fun clearApiKey(context: Context) = SecureKeyStore.clear(context)

    fun config(context: Context): Config {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Config(prefs.getString("endpoint", "") ?: "", prefs.getString("model", "") ?: "", SecureKeyStore.read(context).isNotBlank())
    }

    private fun chatCompletionsUrl(endpoint: String): String {
        val base = endpoint.trim().trimEnd('/')
        require(base.startsWith("https://", ignoreCase = true)) {
            "API manzili https:// bilan boshlanishi kerak."
        }
        val lower = base.lowercase()
        return when {
            lower.endsWith("/chat/completions") -> base
            lower.endsWith("/v1") -> "$base/chat/completions"
            else -> "$base/v1/chat/completions"
        }
    }

    fun generate(context: Context, prompt: String): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val endpoint = prefs.getString("endpoint", "")?.trim().orEmpty()
        val model = prefs.getString("model", "")?.trim().orEmpty()
        val apiKey = SecureKeyStore.read(context)
        require(endpoint.isNotBlank()) { "API manzili kiritilmagan. Sozlamalar → AI API bo‘limini tekshiring." }
        require(model.isNotBlank()) { "AI model nomini kiriting." }
        require(apiKey.isNotBlank()) { "API kaliti kiritilmagan yoki uni o‘qib bo‘lmadi. Sozlamalar → AI API bo‘limini tekshiring." }

        val requestUrl = chatCompletionsUrl(endpoint)
        val connection = (URL(requestUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 90000
            doOutput = true
            useCaches = false
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val body = JSONObject().put("model", model)
                .put("messages", org.json.JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                .put("temperature", 0.7).put("max_tokens", 5000)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = try {
                    val error = JSONObject(response).optJSONObject("error")
                    error?.optString("message")?.takeIf { !it.isNullOrBlank() } ?: response
                } catch (_: Exception) { response }
                throw IllegalStateException("AI server xatosi ($code): ${detail.take(350).ifBlank { "Server javob bermadi" }}")
            }
            val root = JSONObject(response)
            val choices = root.optJSONArray("choices")
                ?: throw IllegalStateException("AI javobi noto‘g‘ri formatda: choices topilmadi.")
            if (choices.length() == 0) throw IllegalStateException("AI server bo‘sh choices qaytardi.")
            val content = choices.optJSONObject(0)?.optJSONObject("message")?.optString("content", "")?.trim().orEmpty()
            if (content.isBlank() || content == "null") {
                val reason = choices.optJSONObject(0)?.optJSONObject("message")?.optString("refusal", "")
                throw IllegalStateException(reason?.takeIf { it.isNotBlank() } ?: "AI bo‘sh javob qaytardi.")
            }
            return content
        } finally {
            connection.disconnect()
        }
    }
}
