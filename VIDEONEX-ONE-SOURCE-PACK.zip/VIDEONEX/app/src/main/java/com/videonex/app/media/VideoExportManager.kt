package com.videonex.app.media

import android.content.Context
import android.content.ContentValues
import android.os.Build
import android.media.MediaCodecList
import android.provider.MediaStore
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Environment
import androidx.media3.common.util.Size
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.audio.GainProcessor
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.Presentation
import com.videonex.app.data.MediaAsset
import com.videonex.app.data.TimelineClip
import java.io.File

/**
 * Picture-in-picture compositor for the two visual tracks.
 * Sequence 0 is the foreground video track; sequence 1 is the full-frame image base.
 * Transparent alpha is used while the foreground track is inside a timeline gap.
 */
@OptIn(UnstableApi::class)
private data class PipOverlay(
    val intervalUs: LongRange,
    val scale: Float,
    val x: Float,
    val y: Float
)

@OptIn(UnstableApi::class)
private class PictureInPictureCompositorSettings(
    private val foregroundOverlays: List<PipOverlay>
) : VideoCompositorSettings {
    override fun getOutputSize(inputSizes: List<Size>): Size = inputSizes.firstOrNull() ?: Size(1280, 720)

    override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
        if (inputId != 0) return StaticOverlaySettings.Builder().build()
        val active = foregroundOverlays.firstOrNull { presentationTimeUs in it.intervalUs }
        return StaticOverlaySettings.Builder()
            .setAlphaScale(if (active != null) 1f else 0f)
            .setScale(active?.scale ?: 0.34f, active?.scale ?: 0.34f)
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(active?.x ?: 0.60f, active?.y ?: 0.60f)
            .build()
    }
}

/**
 * Timeline export milestone.
 * Image and video tracks can now overlap: video is rendered as a picture-in-picture layer
 * over the image track. Audio clips remain independent offset sequences and are mixed.
 */
@OptIn(UnstableApi::class)
class ExportJob internal constructor(
    private val transformer: Transformer,
    private val outputFile: File,
    private val handler: Handler,
    private val progressRunnable: Runnable,
    private val onCancelled: () -> Unit
) {
    private var finished = false
    @Volatile private var cancelled = false

    fun isCancelled(): Boolean = cancelled

    fun markFinished() {
        finished = true
        handler.removeCallbacks(progressRunnable)
    }

    fun cancel() {
        if (finished) return
        finished = true
        cancelled = true
        handler.removeCallbacks(progressRunnable)
        try { transformer.cancel() } catch (_: Exception) { }
        handler.post {
            if (outputFile.exists()) outputFile.delete()
            onCancelled()
        }
    }
}

data class ExportSettings(
    /** Target short edge: 720 means 720p; 1080 means 1080p, portrait or landscape. */
    val shortSide: Int = 720,
    /** Target frame rate for still images and maximum frame rate for video clips. */
    val frameRate: Int = 30
) {
    fun validate() {
        require(shortSide == 720 || shortSide == 1080) { "Video sifati 720p yoki 1080p bo‘lishi kerak." }
        require(frameRate == 24 || frameRate == 30) { "FPS 24 yoki 30 bo‘lishi kerak." }
    }
}

data class EncoderCapability(
    val supported: Boolean,
    val message: String,
    val encoderName: String? = null
)

object VideoExportManager {
    /** Checks whether this device exposes an AVC encoder for the selected portrait/landscape size and FPS. */
    fun checkEncoderCapability(settings: ExportSettings): EncoderCapability {
        try { settings.validate() } catch (error: IllegalArgumentException) {
            return EncoderCapability(false, error.message ?: "Eksport sozlamasi noto‘g‘ri.")
        }
        val candidates = listOf(
            settings.shortSide to (settings.shortSide * 16 / 9),
            (settings.shortSide * 16 / 9) to settings.shortSide
        )
        return try {
            val encoders = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
                .filter { it.isEncoder && it.supportedTypes.any { type -> type.equals("video/avc", ignoreCase = true) } }
            val match = encoders.firstOrNull { codec ->
                val type = codec.supportedTypes.first { it.equals("video/avc", ignoreCase = true) }
                val caps = codec.getCapabilitiesForType(type).videoCapabilities
                candidates.any { (width, height) ->
                    try { caps.areSizeAndRateSupported(width, height, settings.frameRate.toDouble()) }
                    catch (_: Exception) { false }
                }
            }
            if (match != null) EncoderCapability(true, "Tanlangan ${settings.shortSide}p / ${settings.frameRate} FPS uchun AVC encoder topildi.", match.name)
            else EncoderCapability(false, "Bu qurilmada tanlangan ${settings.shortSide}p / ${settings.frameRate} FPS uchun mos AVC encoder aniqlanmadi. 720p yoki 24 FPS ni tanlab ko‘ring.")
        } catch (error: Exception) {
            EncoderCapability(false, "Encoder imkoniyatini tekshirib bo‘lmadi: ${error.message ?: "noma’lum xato"}")
        }
    }
    /** Copies a completed MP4 into the public Movies/VIDEONEX collection. */
    fun saveToGallery(context: Context, source: File): Uri {
        require(source.exists() && source.isFile && source.length() > 0L) {
            "Saqlanadigan MP4 fayl topilmadi yoki bo‘sh."
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            throw IllegalStateException("Galereyaga avtomatik saqlash Android 10 yoki yangiroq versiyada ishlaydi. MP4 ilovaning Movies papkasida qoldi.")
        }
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, source.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VIDEONEX")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val destination = resolver.insert(collection, values)
            ?: throw IllegalStateException("Telefon xotirasida MP4 uchun joy ajratilmadi.")
        try {
            resolver.openOutputStream(destination, "w")?.use { output ->
                source.inputStream().use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Galereya faylini yozish ochilmadi.")
            val ready = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(destination, ready, null, null)
            return destination
        } catch (error: Exception) {
            try { resolver.delete(destination, null, null) } catch (_: Exception) { }
            throw error
        }
    }
    fun exportProject(
        context: Context,
        assets: List<MediaAsset>,
        clips: List<TimelineClip>,
        onComplete: (File) -> Unit,
        onError: (String) -> Unit,
        onProgress: (Int) -> Unit = {},
        onCancelled: () -> Unit = {},
        settings: ExportSettings = ExportSettings()
    ): ExportJob? {
        try { settings.validate() } catch (error: IllegalArgumentException) {
            onError(error.message ?: "Eksport sozlamasi noto‘g‘ri.")
            return null
        }
        // Preflight validation prevents starting an export with missing media or invalid timing.
        if (clips.isEmpty()) {
            onError("Timeline bo‘sh. Avval rasm, video yoki audio qo‘shing.")
            return null
        }
        val byId = assets.associateBy { it.id }
        val missingAssetClip = clips.firstOrNull { it.mediaAssetId !in byId }
        if (missingAssetClip != null) {
            onError("Timeline’da media fayli topilmaydigan klip bor. Uni qayta biriktiring yoki o‘chiring.")
            return null
        }
        val invalidClip = clips.firstOrNull { it.startMs < 0L || it.durationMs <= 0L || it.trackIndex < 0 }
        if (invalidClip != null) {
            onError("Timeline’da noto‘g‘ri vaqt yoki trek raqamiga ega klip bor.")
            return null
        }
        // SAF/cloud document providers may expose a readable stream without an AssetFileDescriptor.
        // Use ContentResolver.openInputStream so valid cloud-backed media is not rejected prematurely.
        val unreadableAsset = assets.firstOrNull { asset ->
            clips.any { it.mediaAssetId == asset.id } && try {
                context.contentResolver.openInputStream(Uri.parse(asset.uri))?.use { true } != true
            } catch (_: Exception) { true }
        }
        if (unreadableAsset != null) {
            onError("'${unreadableAsset.displayName}' fayliga kirib bo‘lmadi. Faylni qayta tanlang yoki telefon xotirasiga yuklang.")
            return null
        }
        val misplacedVisual = clips.firstOrNull { clip ->
            clip.trackIndex in 0..1 && byId[clip.mediaAssetId]?.mimeType?.let {
                it.startsWith("image/") || it.startsWith("video/")
            } != true
        }
        if (misplacedVisual != null) {
            onError("Rasm/video yo‘lagida audio yoki qo‘llab-quvvatlanmaydigan fayl bor. Uni audio yo‘lagiga ko‘chiring.")
            return null
        }
        val misplacedAudio = clips.firstOrNull { clip ->
            clip.trackIndex >= 2 && byId[clip.mediaAssetId]?.mimeType?.startsWith("audio/") != true
        }
        if (misplacedAudio != null) {
            onError("Audio yo‘lagida audio bo‘lmagan fayl bor. Uni rasm yoki video yo‘lagiga ko‘chiring.")
            return null
        }
        val visualClips = clips
            .filter { it.trackIndex == 0 || it.trackIndex == 1 }
            .filter { byId[it.mediaAssetId]?.mimeType?.let { type -> type.startsWith("image/") || type.startsWith("video/") } == true }
            .sortedWith(compareBy<TimelineClip> { it.startMs.coerceAtLeast(0L) }.thenBy { it.id })
        val audioClips = clips
            .filter { it.trackIndex >= 2 }
            .filter { byId[it.mediaAssetId]?.mimeType?.startsWith("audio/") == true }
            .sortedWith(compareBy<TimelineClip> { it.startMs.coerceAtLeast(0L) }.thenBy { it.id })

        if (visualClips.isEmpty()) {
            onError("Eksport uchun rasm yoki video trek qo‘shing.")
            return null
        }
        val encoderCapability = checkEncoderCapability(settings)
        if (!encoderCapability.supported) {
            onError(encoderCapability.message)
            return null
        }

        fun makeVisualItem(clip: TimelineClip, asset: MediaAsset): EditedMediaItem {
            val isImage = asset.mimeType.startsWith("image/")
            val mediaBuilder = MediaItem.Builder().setUri(Uri.parse(asset.uri))
            if (isImage) {
                mediaBuilder.setImageDurationMs(clip.durationMs.coerceAtLeast(500L))
            } else {
                mediaBuilder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setEndPositionMs(clip.durationMs.coerceAtLeast(500L))
                        .build()
                )
            }
            val editedBuilder = EditedMediaItem.Builder(mediaBuilder.build())
                .setFrameRate(settings.frameRate)
                .setEffects(Effects(
                    emptyList(),
                    listOf(Presentation.createForShortSide(settings.shortSide))
                ))
            if (!isImage) editedBuilder.setRemoveAudio(true)
            return editedBuilder.build()
        }

        fun makeAudioItem(clip: TimelineClip, asset: MediaAsset): EditedMediaItem {
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(asset.uri))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setEndPositionMs(clip.durationMs.coerceAtLeast(500L))
                        .build()
                )
                .build()
            val gain = clip.volume.coerceIn(0f, 1f)
            val builder = EditedMediaItem.Builder(mediaItem).setRemoveVideo(true)
            if (gain < 0.999f) {
                val gainProcessor = GainProcessor(object : GainProcessor.GainProvider {
                    override fun getGainFactorAtSamplePosition(samplePosition: Long, sampleRate: Int): Float = gain
                    override fun isUnityUntil(samplePosition: Long, sampleRate: Int): Long =
                        if (gain >= 0.999f) C.TIME_END_OF_SOURCE else C.TIME_UNSET
                })
                builder.setEffects(Effects(listOf(gainProcessor), emptyList()))
            }
            return builder.build()
        }

        try {
            val sequences = mutableListOf<EditedMediaItemSequence>()
            val visualTracks = listOf(0, 1).filter { track -> visualClips.any { it.trackIndex == track } }
            val hasPictureInPicture = visualTracks.size == 2
            // When both tracks exist, put video track 1 first (foreground) and image track 0 second (background).
            // Media3 composites the first registered video source above later sources.
            val orderedVisualTracks = if (hasPictureInPicture) listOf(1, 0) else visualTracks
            val foregroundOverlays = mutableListOf<PipOverlay>()

            orderedVisualTracks.forEach { trackIndex ->
                val trackClips = visualClips.filter { it.trackIndex == trackIndex }
                val sequenceBuilder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                var cursorMs = 0L
                trackClips.forEach { clip ->
                    val asset = byId[clip.mediaAssetId] ?: return@forEach
                    val requestedStartMs = clip.startMs.coerceAtLeast(0L)
                    // Clips within the same track cannot overlap yet; cross-track overlap is supported.
                    val actualStartMs = maxOf(requestedStartMs, cursorMs)
                    val gapMs = actualStartMs - cursorMs
                    if (gapMs > 0L) sequenceBuilder.addGap(gapMs * 1_000L)
                    val durationMs = clip.durationMs.coerceAtLeast(500L)
                    sequenceBuilder.addItem(makeVisualItem(clip.copy(startMs = actualStartMs), asset))
                    if (trackIndex == 1 && hasPictureInPicture) {
                        foregroundOverlays += PipOverlay(
                            intervalUs = (actualStartMs * 1_000L)..((actualStartMs + durationMs) * 1_000L),
                            scale = clip.overlayScale.coerceIn(0.15f, 0.80f),
                            x = clip.overlayX.coerceIn(-0.85f, 0.85f),
                            y = clip.overlayY.coerceIn(-0.85f, 0.85f)
                        )
                    }
                    cursorMs = actualStartMs + durationMs
                }
                sequences += sequenceBuilder.build()
            }
            if (sequences.isEmpty()) {
                onError("Timeline’da eksport qilinadigan rasm yoki video topilmadi.")
                return null
            }

            // Each audio clip is an independent sequence with its own leading gap.
            // Composition mixes these audio-only sequences, preserving their start offsets.
            audioClips.forEach { clip ->
                val asset = byId[clip.mediaAssetId] ?: return@forEach
                val audioBuilder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
                val startMs = clip.startMs.coerceAtLeast(0L)
                if (startMs > 0L) audioBuilder.addGap(startMs * 1_000L)
                audioBuilder.addItem(makeAudioItem(clip, asset))
                sequences += audioBuilder.build()
            }

            val compositionBuilder = Composition.Builder(sequences)
            if (hasPictureInPicture) {
                compositionBuilder.setVideoCompositorSettings(
                    PictureInPictureCompositorSettings(foregroundOverlays)
                )
            }
            val composition = compositionBuilder.build()
            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.cacheDir
            if (!outputDir.exists() && !outputDir.mkdirs()) {
                onError("Eksport papkasini yaratib bo‘lmadi.")
                return null
            }
            val output = File(outputDir, "VIDEONEX_${System.currentTimeMillis()}.mp4")
            val mainHandler = Handler(Looper.getMainLooper())
            lateinit var transformer: Transformer
            lateinit var job: ExportJob
            val progressHolder = ProgressHolder()
            var terminal = false
            val progressRunnable = object : Runnable {
                override fun run() {
                    if (terminal) return
                    try {
                        val state = transformer.getProgress(progressHolder)
                        if (state == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(progressHolder.progress)
                        if (state != Transformer.PROGRESS_STATE_NOT_STARTED) mainHandler.postDelayed(this, 500L)
                    } catch (_: Exception) { }
                }
            }
            transformer = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        terminal = true
                        job.markFinished()
                        onProgress(100)
                        if (output.exists() && output.length() > 0L) onComplete(output)
                        else onError("Eksport tugadi, ammo MP4 fayl bo‘sh.")
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        terminal = true
                        job.markFinished()
                        if (output.exists()) output.delete()
                        if (!job.isCancelled()) onError(exportException.message ?: "Timeline eksport xatosi")
                    }
                })
                .build()
            job = ExportJob(transformer, output, mainHandler, progressRunnable) {
                terminal = true
                onCancelled()
            }
            transformer.start(composition, output.absolutePath)
            mainHandler.post(progressRunnable)
            return job
        } catch (e: Exception) {
            onError(e.message ?: "Eksportni boshlash imkoni bo‘lmadi")
            return null
        }
    }

    /** Compatibility path for older callers. */
    fun exportSingleVideo(
        context: Context,
        input: Uri,
        onComplete: (File) -> Unit,
        onError: (String) -> Unit
    ) {
        val asset = MediaAsset(projectId = -1L, uri = input.toString(), displayName = "Video", mimeType = "video/*")
        val clip = TimelineClip(projectId = -1L, mediaAssetId = asset.id, trackIndex = 1, startMs = 0L, durationMs = 60_000L)
        exportProject(context, listOf(asset), listOf(clip), onComplete, onError)
    }
}
