# VIDEONEX — yagona source ZIP

## GitHub orqali APK olish
1. ZIP ichidagi barcha fayl va papkalarni GitHub repozitoriyingizning asosiy (root) qismiga yuklang. `VIDEONEX` papkasi va `.github` papkasi root ichida turishi kerak.
2. GitHub'da **Actions** bo'limini oching.
3. **Build VIDEONEX APK** workflow'ini tanlang va **Run workflow** ni bosing.
4. Build yashil tugasa, shu run sahifasining **Artifacts** qismidan `VIDEONEX-debug-apk` ni yuklab oling.
5. ZIP ichidagi APK fayl emas, manba kodidir. APK GitHub Actions muvaffaqiyatli build qilgandan keyin artifact sifatida paydo bo'ladi.

## Muhim
- Android loyiha: `VIDEONEX/`
- Versiya: `0.27.7-dev` (versionCode 33)
- JDK 17, Gradle 8.9, Android SDK 35 ishlatiladi.
- AI funksiyalari uchun ilova ichida mos OpenAI-compatible API endpoint, model va API kalitini kiritish kerak. Bepul va cheksiz AI xizmati kafolatlanmaydi.
- Rasm yuklash tartibi saqlanadi: 1-rasm 1-sahnaga, 2-rasm 2-sahnaga va hokazo.
- Hozirgi manbada AI mavzu/ssenariy/storyboard/SEO, loyiha saqlash, timeline ma'lumotlari va Media3 MP4 eksporti mavjud.
- AI ovoz (TTS), eksport MP4 ichiga avtomatik subtitr qo'shish va thumbnail rasmlarini real fayl sifatida generatsiya qilish to'liq amalga oshirilgan deb hisoblanmasin. SEO qismida thumbnail g'oyalari beriladi.
- Eksport imkoniyati telefon kodeki va xotirasiga bog'liq. Ushbu ZIP uchun Android build yoki telefondagi eksport sinovi bajarilmagan.

Bu ZIP bitta joyga jamlangan source paketidir; u tayyor APK emas.
