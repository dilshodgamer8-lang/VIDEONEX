# VIDEONEX — Android starter project

VIDEONEX is a personal Uzbek-language AI YouTube video creator. This first milestone contains the black/gold Dashboard, local Room database, project creation, and the 11 agreed content directions.

## Build requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install any requested Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Current scope
- Local project list stored in Room on the phone.
- Black/gold Dashboard.
- Create a project and choose one of 11 content directions.
- No network permission is requested in this initial build.

## Not implemented yet
AI providers, API Manager, script research, image/voice generation, timeline editor, rendering, project ZIP backup, version history, and consent/data-usage dialogs are later milestones. No paid service is connected.
