package com.videonex.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeProjects(): Flow<List<VideoProject>>

    @Insert
    suspend fun insert(project: VideoProject): Long

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun delete(projectId: Long)
}
