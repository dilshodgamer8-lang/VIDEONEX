package com.videonex.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [VideoProject::class], version = 1, exportSchema = false)
abstract class VideonexDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile private var INSTANCE: VideonexDatabase? = null
        fun get(context: Context): VideonexDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VideonexDatabase::class.java,
                "videonex_local.db"
            ).build().also { INSTANCE = it }
        }
    }
}
