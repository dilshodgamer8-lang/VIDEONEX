package com.videonex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.videonex.app.data.VideoProject
import com.videonex.app.data.VideonexDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD6AD55)
private val Muted = Color(0xFFAAAAAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = VideonexDatabase.get(this).projectDao()
        setContent {
            val vm: HomeViewModel = viewModel(factory = HomeViewModel.factory(dao))
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, background = Black, surface = Panel,
                onPrimary = Black, onBackground = Color.White, onSurface = Color.White
            )) {
                HomeScreen(vm)
            }
        }
    }
}

class HomeViewModel(private val dao: com.videonex.app.data.ProjectDao) : ViewModel() {
    val projects = dao.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun addProject(name: String, direction: String) = viewModelScope.launch {
        dao.insert(VideoProject(name = name, direction = direction))
    }
    companion object {
        fun factory(dao: com.videonex.app.data.ProjectDao) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(dao) as T
        }
    }
}

@Composable
private fun HomeScreen(vm: HomeViewModel) {
    val projects by vm.projects.collectAsStateWithLifecycle()
    var showCreate by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Bosh sahifa") }
    var openedProject by remember { mutableStateOf<VideoProject?>(null) }

    Scaffold(containerColor = Black, bottomBar = {
        NavigationBar(containerColor = Panel, contentColor = Gold) {
            listOf("Bosh sahifa", "AI Studio", "Loyihalar", "Sozlamalar").forEach { item ->
                NavigationBarItem(
                    selected = selectedTab == item,
                    onClick = { selectedTab = item },
                    icon = { Icon(if (item == "Loyihalar") Icons.Default.FolderOpen else Icons.Default.Movie, null) },
                    label = { Text(item, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold,
                        indicatorColor = Color(0xFF342A17), unselectedIconColor = Muted, unselectedTextColor = Muted)
                )
            }
        }
    }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(Black).padding(padding),
            contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("VIDEONEX", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("AI VIDEO CREATOR", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Box(Modifier.size(44.dp).background(Panel, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Text("V", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) {
                    Text("Xush kelibsiz!", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("G‘oyangizni tayyor YouTube videosiga aylantiring.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("YANGI VIDEO YARATISH", fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Text("LOYIHALAR STATISTIKASI", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Jami loyihalar", projects.size.toString(), Modifier.weight(1f))
                    StatCard("Tayyor videolar", "0", Modifier.weight(1f))
                    StatCard("AI vazifalari", "0", Modifier.weight(1f))
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("SO‘NGGI LOYIHALAR", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
                    Text("Barchasi", color = Gold, fontSize = 12.sp)
                }
            }
            if (projects.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOpen, null, tint = Gold, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Hozircha loyiha yo‘q", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Birinchi videongizni yaratishdan boshlang.", color = Muted, fontSize = 12.sp)
                    }
                }
            } else {
                items(projects, key = { it.id }) { project -> ProjectRow(project, onClick = { openedProject = project }) }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("AI XIZMATLARI", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text("Offline rejim tayyor", color = Gold, fontSize = 11.sp)
                }
            }
            item {
                Text("Internet bo‘lmaganda mahalliy loyihalarni boshqarish mumkin. AI xizmatlari internet va mavjud bepul limitlarga bog‘liq.", color = Muted, fontSize = 12.sp)
            }
        }
    }
    if (showCreate) CreateProjectDialog(onDismiss = { showCreate = false }, onCreate = { name, direction ->
        vm.addProject(name, direction); showCreate = false
    })
    openedProject?.let { project -> ProjectDetailDialog(project = project, onDismiss = { openedProject = null }) }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(value, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 10.sp, lineHeight = 13.sp)
    }
}

@Composable
private fun ProjectRow(project: VideoProject, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Color(0xFF302719), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Movie, null, tint = Gold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(project.name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(project.direction, color = Muted, fontSize = 11.sp)
        }
        Text(project.status, color = Gold, fontSize = 10.sp)
    }
}

@Composable
private fun CreateProjectDialog(onDismiss: () -> Unit, onCreate: (String, String) -> Unit) {
    val directions = listOf("Tarixiy POV", "Tarix", "Biznes va Finance", "Tarixdagi g‘alati ishlar", "Qadimgi odamlar", "Inson ongi va falsafa", "Horror hikoyalar", "Jamiyat psixologiyasi", "Tibbiyot va salomatlik", "Wojak Doomer", "Brendlar va korporatsiyalar tarixi")
    var name by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf(directions.first()) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel,
        title = { Text("Yangi loyiha", color = Gold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Loyiha nomi") }, singleLine = true)
                Text("Video yo‘nalishini tanlang", color = Muted, fontSize = 12.sp)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(direction, color = Color.White) }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        directions.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { direction = option; expanded = false }) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim(), direction) }, enabled = name.isNotBlank()) { Text("YARATISH", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BEKOR QILISH", color = Muted) } }
    )
}


@Composable
private fun ProjectDetailDialog(project: VideoProject, onDismiss: () -> Unit) {
    var format by remember { mutableStateOf("16:9 Long") }
    var duration by remember { mutableStateOf("10 daqiqa") }
    var language by remember { mutableStateOf("O‘zbek") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(project.name, color = Gold, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Yo‘nalish: ${project.direction}", color = Muted, fontSize = 12.sp)
                Text("VIDEO FORMATI", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("9:16 Shorts", "16:9 Long").forEach { option ->
                        FilterChip(selected = format == option, onClick = { format = option }, label = { Text(option) })
                    }
                }
                Text("DAVOMIYLIK", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("5 daqiqa", "10 daqiqa", "15 daqiqa", "20 daqiqa").forEach { option ->
                        FilterChip(selected = duration == option, onClick = { duration = option }, label = { Text(option, fontSize = 10.sp) })
                    }
                }
                Text("VIDEO TILI", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("O‘zbek", "English", "Русский").forEach { option ->
                        FilterChip(selected = language == option, onClick = { language = option }, label = { Text(option) })
                    }
                }
                Text("Keyingi bosqichda mavzu tanlash va AI ssenariy yaratish qo‘shiladi.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("DAVOM ETISH", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("YOPISH", color = Muted) } }
    )
}
