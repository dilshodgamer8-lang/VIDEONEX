package com.videonex.app.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/**
 * Free source-discovery helper. It retrieves public reference metadata/snippets;
 * it does not independently prove claims or replace human fact-checking.
 */
object ResearchClient {
    private data class Source(val title: String, val detail: String, val url: String)

    fun search(topic: String, language: String): String {
        val query = topic.trim().take(180)
        if (query.isBlank()) return "Tadqiqot bajarilmadi: mavzu bo‘sh."
        val lang = when (language.lowercase()) {
            "english", "inglizcha", "en" -> "en"
            "русский", "russian", "ru" -> "ru"
            else -> "uz"
        }
        val sources = mutableListOf<Source>()
        try { sources += searchWikipedia(query, lang) } catch (_: Exception) { }
        try { sources += searchCrossref(query) } catch (_: Exception) { }
        if (sources.isEmpty()) {
            return "Ochiq manba qidiruvi hozir ishlamadi. Faktlarni taxmin qilmang; ssenariyda tekshirilishi kerak bo‘lgan joylarni belgilang."
        }
        return buildString {
            append("TOPILGAN OCHIQ MANBA NOMZODLARI (ularni mustaqil tekshirish shart):\n")
            sources.distinctBy { it.url }.take(6).forEachIndexed { index, source ->
                append("${index + 1}. ${source.title}\n")
                if (source.detail.isNotBlank()) append("   Izoh: ${source.detail}\n")
                append("   Havola: ${source.url}\n")
            }
            append("\nEslatma: bu natijalar faktlarning to‘g‘riligini kafolatlamaydi. Muhim sana, raqam va da'volarni manbaning o‘zidan tekshiring.")
        }
    }

    private fun searchWikipedia(query: String, lang: String): List<Source> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val endpoint = "https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encoded}&srlimit=3&format=json&utf8=1"
        val json = JSONObject(get(endpoint))
        val rows = json.optJSONObject("query")?.optJSONArray("search") ?: return emptyList()
        return (0 until rows.length()).mapNotNull { index ->
            val row = rows.optJSONObject(index) ?: return@mapNotNull null
            val title = row.optString("title").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val page = URLEncoder.encode(title.replace(' ', '_'), "UTF-8")
            Source(title, row.optString("snippet").replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim(), "https://${lang}.wikipedia.org/wiki/${page}")
        }
    }

    private fun searchCrossref(query: String): List<Source> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val endpoint = "https://api.crossref.org/works?query.title=${encoded}&rows=3&select=title,DOI,publisher,published,URL"
        val items = JSONObject(get(endpoint)).optJSONObject("message")?.optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).mapNotNull { index ->
            val item = items.optJSONObject(index) ?: return@mapNotNull null
            val titleArray = item.optJSONArray("title")
            val title = titleArray?.optString(0)?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val publisher = item.optString("publisher")
            val year = item.optJSONObject("published")?.optJSONArray("date-parts")?.optJSONArray(0)?.optInt(0, 0) ?: 0
            val url = item.optString("URL").ifBlank { item.optString("DOI").takeIf { it.isNotBlank() }?.let { "https://doi.org/$it" }.orEmpty() }
            if (url.isBlank()) return@mapNotNull null
            Source(title, listOf(publisher, if (year > 0) year.toString() else "").filter { it.isNotBlank() }.joinToString(" • "), url)
        }
    }

    private fun get(address: String): String {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "VIDEONEX-Android/0.16 (personal video research app)")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Manba qidiruvi xatosi: HTTP $code")
            return body
        } finally { connection.disconnect() }
    }
}
