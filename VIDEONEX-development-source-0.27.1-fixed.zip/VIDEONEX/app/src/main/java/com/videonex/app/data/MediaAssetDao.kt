package com.videonex.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaAssetDao {
    @Query("SELECT * FROM media_assets WHERE projectId = :projectId ORDER BY addedAt DESC")
    fun observeForProject(projectId: Long): Flow<List<MediaAsset>>

    @Insert
    suspend fun insert(asset: MediaAsset): Long

    @Query("SELECT * FROM media_assets WHERE projectId = :projectId AND uri = :uri LIMIT 1")
    suspend fun findByUri(projectId: Long, uri: String): MediaAsset?

    @Query("DELETE FROM media_assets WHERE id = :assetId AND projectId = :projectId")
    suspend fun delete(assetId: Long, projectId: Long)
}
