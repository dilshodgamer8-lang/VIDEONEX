# VIDEONEX — development source 0.16.0-dev

## Current implemented modules
- Android Compose dashboard and Uzbek-language project workflow.
- 11 video directions, project format, duration, and language settings.
- Local Room database for projects, imported media, and editable timeline clips.
- AI topic suggestions, script generation, and YouTube SEO through a user-configured OpenAI-compatible API.
- API credentials encrypted with Android Keystore, with an in-app clear-key action.
- Free source discovery for script preparation using Wikipedia search and Crossref metadata. These are source candidates only; they do not independently verify claims.
- Imported image/video/audio assets and a basic multi-track timeline model.
- Media3 composition export prototype with image/video layers, audio sequences, PIP controls, progress, and cancellation.
- Generated script and SEO content are saved to the local project automatically; selected topic is also saved.

## Important limitations — not a finished product
- AI image generation, automatic narration/TTS, subtitle generation, automatic image-to-script matching, thumbnail image generation, transitions, keyframes, and a full preview/editor are not implemented as complete workflows.
- Research currently searches Wikipedia and Crossref only. It is not a comprehensive web search or a fact-checking guarantee.
- The Media3 timeline exporter has not passed a full Android Gradle build or real-device rendering test. Complex timing, overlaps, and device-specific codec behavior remain unverified.
- A user-configured AI endpoint and API key are required for AI text generation. Free quotas depend on the selected provider; no unlimited free AI service is promised.

## Build requirements
- JDK 17
- Gradle 8.9 or compatible
- Android SDK platform/build-tools 35
- Internet access to resolve Gradle dependencies

Run `gradle assembleDebug` from this directory. This source snapshot has not yet been verified by a successful Android Gradle build or on-device test. Do not treat it as a final APK.


v0.26 adds an AVC encoder capability preflight before export. It queries Android MediaCodec capabilities for the selected short-edge resolution and frame rate in both portrait and landscape orientations. The check is advisory and cannot replace real-device export testing.
