package com.videonex.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "timeline_clips",
    foreignKeys = [
        ForeignKey(entity = VideoProject::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = MediaAsset::class, parentColumns = ["id"], childColumns = ["mediaAssetId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("projectId"), Index("mediaAssetId")]
)
data class TimelineClip(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val mediaAssetId: Long,
    val trackIndex: Int,
    val startMs: Long,
    val durationMs: Long,
    val volume: Float = 1f,
    val overlayScale: Float = 0.34f,
    val overlayX: Float = 0.60f,
    val overlayY: Float = 0.60f
)
