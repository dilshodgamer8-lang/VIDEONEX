package com.videonex.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TimelineDao {
    @Query("SELECT * FROM timeline_clips WHERE projectId = :projectId ORDER BY trackIndex, startMs, id")
    fun observeForProject(projectId: Long): Flow<List<TimelineClip>>

    @Query("SELECT COALESCE(MAX(startMs + durationMs), 0) FROM timeline_clips WHERE projectId = :projectId AND trackIndex = :trackIndex")
    suspend fun trackEnd(projectId: Long, trackIndex: Int): Long

    @Insert
    suspend fun insert(clip: TimelineClip): Long

    @Update
    suspend fun update(clip: TimelineClip)

    @Query("DELETE FROM timeline_clips WHERE id = :clipId AND projectId = :projectId")
    suspend fun delete(clipId: Long, projectId: Long)

    @Query("DELETE FROM timeline_clips WHERE projectId = :projectId AND trackIndex = :trackIndex")
    suspend fun deleteTrack(projectId: Long, trackIndex: Int)
}
