package com.videonex.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [VideoProject::class, MediaAsset::class, TimelineClip::class], version = 6, exportSchema = false)
abstract class VideonexDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun mediaAssetDao(): MediaAssetDao
    abstract fun timelineDao(): TimelineDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE projects_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    name TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    format TEXT NOT NULL,
                    durationMinutes INTEGER NOT NULL,
                    language TEXT NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    status TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""INSERT INTO projects_new (id, name, direction, format, durationMinutes, language, createdAt, updatedAt, status)
                    SELECT id, name, direction, format, 10, 'O‘zbek', createdAt, updatedAt, status FROM projects""".trimIndent())
                db.execSQL("DROP TABLE projects")
                db.execSQL("ALTER TABLE projects_new RENAME TO projects")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN topic TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN script TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN seoTitle TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN seoDescription TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN seoTags TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS media_assets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    projectId INTEGER NOT NULL,
                    uri TEXT NOT NULL,
                    displayName TEXT NOT NULL,
                    mimeType TEXT NOT NULL,
                    addedAt INTEGER NOT NULL,
                    FOREIGN KEY(projectId) REFERENCES projects(id) ON UPDATE NO ACTION ON DELETE CASCADE
                )""".trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_media_assets_projectId ON media_assets(projectId)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS timeline_clips (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    projectId INTEGER NOT NULL,
                    mediaAssetId INTEGER NOT NULL,
                    trackIndex INTEGER NOT NULL,
                    startMs INTEGER NOT NULL,
                    durationMs INTEGER NOT NULL,
                    volume REAL NOT NULL,
                    FOREIGN KEY(projectId) REFERENCES projects(id) ON UPDATE NO ACTION ON DELETE CASCADE,
                    FOREIGN KEY(mediaAssetId) REFERENCES media_assets(id) ON UPDATE NO ACTION ON DELETE CASCADE
                )""".trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_timeline_clips_projectId ON timeline_clips(projectId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_timeline_clips_mediaAssetId ON timeline_clips(mediaAssetId)")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE timeline_clips ADD COLUMN overlayScale REAL NOT NULL DEFAULT 0.34")
                db.execSQL("ALTER TABLE timeline_clips ADD COLUMN overlayX REAL NOT NULL DEFAULT 0.60")
                db.execSQL("ALTER TABLE timeline_clips ADD COLUMN overlayY REAL NOT NULL DEFAULT 0.60")
            }
        }

        @Volatile private var INSTANCE: VideonexDatabase? = null

        fun get(context: Context): VideonexDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VideonexDatabase::class.java,
                "videonex_local.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6).build().also { INSTANCE = it }
        }
    }
}
