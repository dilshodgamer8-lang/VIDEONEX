# VIDEONEX FULL BUILD — v0.8 development source

## v0.8: media preview and basic MP4 transcode
- Added Media3 ExoPlayer preview for imported video assets.
- Added Media3 Transformer export for a selected single video asset to MP4.
- Output is written to the app-specific Movies directory; no broad storage permission is requested.
- Export errors are surfaced in the project workspace.

## Important scope boundary
This is **not yet a full multi-track render engine**. The current exporter transcodes one selected video file. It does not yet combine timeline clips, still images, audio tracks, subtitles, transitions, overlays, or effects. The timeline remains editable metadata. These require a later composition/render implementation and device testing.

## Existing modules
- Local projects and Room persistence.
- AI topic ideas, script and YouTube SEO through a user-configured OpenAI-compatible endpoint.
- API key encryption using Android Keystore.
- Local media library and editable multi-track timeline metadata.

## Build
Requires JDK 17, Gradle 8.9, Android SDK 35, and internet access to resolve Media3 1.9.0 dependencies. Run `gradle assembleDebug` from this directory. This source archive has not yet been verified by a successful Android Gradle build or on-device test.

## v0.8 implementation note
The project workspace now exposes an MP4 export action when at least one video asset is present. It transcodes the first imported video asset through Media3 Transformer into the app-specific Movies directory. This is a single-file export path, not yet a render of the edited multi-track timeline. A successful Gradle build and device export test are still required.


## v0.9 development milestone
- Added Media3 Composition-based timeline export: sequential image/video visual clips and a separate audio sequence.
- Video source audio is disabled on the visual sequence to avoid unintentionally duplicating its sound when an audio track is supplied.
- Export output is checked for a non-empty MP4 file.
- Current limitation: this milestone concatenates clips in sequence order; absolute timeline gaps, overlaps, per-clip volume, fades, transitions, and precise source in/out editing are not yet implemented.
- Android build and on-device export still require GitHub Actions and device testing.


## v0.10 development milestone
- Upgraded Media3 modules consistently to 1.9.0 to use track-type-aware sequence builders and timeline gaps.
- Visual image/video clips now retain blank gaps before clips when their timeline start is later than the previous visual clip end.
- Audio clips are exported as separate audio-only sequences with their own start offsets; overlapping audio clips can be mixed by the composition.
- Visual clips that overlap are still flattened sequentially; per-clip volume, fades, transitions, subtitles, overlays, and precise source in-points remain future work.
- This source has not yet passed a Gradle build or device export test.


## Export behavior in v0.10
- Visual clip start offsets create blank gaps in the exported sequence. If visual clips overlap, the later clip is placed after the previous visual clip because this version uses one visual sequence.
- Audio clips are separate audio-only sequences, each with its own start offset, allowing audio clips to overlap/mix.
- Per-clip volume is stored in the timeline model but is not yet applied by the renderer.


## v0.11 development milestone
- Added per-audio-clip gain processing (0–100%) using Media3 GainProcessor.
- Added export progress polling, percentage display, and cancel support.
- Cancelled/failed partial MP4 files are deleted.
- This source snapshot has ZIP integrity validation only; a successful Gradle build and on-device export test are still required.


## v0.12.0-dev — Visual overlay / picture-in-picture
- Image track is the full-frame base sequence.
- Video track is composited as a smaller foreground picture-in-picture layer when both visual tracks are present.
- Foreground alpha is hidden during timeline gaps, preventing black gap frames from covering the base image.
- Same-track clips remain sequential; cross-track visual overlap is now represented in the composition.
- PIP placement is currently fixed to the upper-right area; user-adjustable position/scale is not yet implemented.
- ZIP/source checks only; Gradle build and on-device rendering still require verification.


## v0.13 — PIP joylashuvini sozlash
- Har bir ustki video klip uchun PIP o‘lchami (15–80%) va gorizontal/vertikal joylashuv sozlamalari qo‘shildi.
- Sozlamalar Room bazasida saqlanadi; 5→6 migratsiya eski loyihalarni saqlab qoladi.
- Eksport compositor’i har bir klipning o‘z geometriyasidan foydalanadi.
- Cheklov: hozircha bitta PIP video trek mavjud; bir nechta ustma-ust PIP qatlamlar va preview hali yo‘q.
- APK build va qurilmadagi eksport testi bajarilmagan.


## v0.14 — asosiy holatlarni to‘g‘rilash
- Ilova ichidagi versiya yorlig‘i build versiyasi bilan moslashtirildi.
- Sozlamalardagi eksport tavsifi amaldagi kodga moslashtirildi: timeline eksport moduli mavjud, ammo qurilmada hali tasdiqlanmagan.
- Yangi ortiqcha funksiya qo‘shilmadi.
- Bu manba hali Gradle build va real qurilma sinovidan o‘tmagan.


## v0.15 — source review correction

- Fixed a Kotlin UI syntax error in the timeline explanatory text (`Text(...)` wrapper was missing).
- Updated the development version to `0.15.0-dev`.
- No new user-facing feature was added.
- Kotlin parser check completed with no syntax diagnostics. A full Android Gradle build and on-device export test have not yet been run.

## v0.18 — Scene Image Manager
- Added per-scene image selection from device storage.
- Selected image URI is persisted in the project's storyboard JSON and restored when reopening the project.
- Added scene image preview, replace, and remove actions.
- Kept image generation separate: the configured chat-completions endpoint only generates text/prompts; actual image generation requires a compatible image-generation provider/API and is not falsely simulated.
- Build/device validation has not yet been performed in this environment.


## v0.19 — Yuklangan rasmlarni ssenariyga ketma-ket moslash

- Foydalanuvchi bir nechta rasmni Android fayl tanlagichidan bir martada tanlaydi.
- Tanlagich qaytargan tartib saqlanadi; ilova rasmlarni nomi yoki AI bahosiga qarab qayta tartiblamaydi.
- AI ssenariyni rasmlar soniga teng, ketma-ket va to‘liq qamrab oluvchi bo‘laklarga ajratadi.
- 1-rasm ssenariy boshidagi bo‘lakka, 2-rasm keyingi bo‘lakka va hokazo biriktiriladi.
- Har bir rasm va uning ssenariy bo‘lagi storyboard faylida loyiha bilan birga saqlanadi.
- Bu funksiya rasm mazmunini ko‘rish/vision tahlili deb da’vo qilmaydi; moslash foydalanuvchi tanlagan tartib va ssenariyning xronologik bo‘linishiga asoslanadi.

Build holati: manba ZIP arxivi tekshirildi. Android Gradle build va qurilmada sinov bajarilmagan.


## v0.20 — Storyboard to timeline
- Added a command to place storyboard images onto the primary image timeline track in the exact storyboard/upload order.
- Each image clip uses its scene duration and starts immediately after the previous image.
- Rebuilding this image track leaves audio and video tracks untouched. Existing media assets are reused by URI.
- This module does not generate images or inspect image contents.


## v0.22 development update
- Added editable per-scene duration (1–3600 seconds) in storyboard.
- Audio-to-image duration allocation now uses narration word counts as a rough speaking-time weight, falling back to the manually entered scene duration when narration is empty.
- This is an estimate, not speech recognition or word-level timestamps.


## v0.23 — Export preflight validation
- Rejects empty timelines before export.
- Checks that every timeline clip points to an existing media asset.
- Rejects negative start times, non-positive durations, and invalid track indexes.
- Checks that referenced content URIs can still be opened before starting Media3 export.
- Reports a user-readable error so missing media can be reselected instead of failing mid-export.
- Android Gradle build and device testing are still required.


## v0.24 — MP4 galereyaga saqlash
- Eksport tugagach MP4 Android MediaStore orqali `Movies/VIDEONEX` papkasiga ko‘chiriladi.
- Fayl avval vaqtincha (`IS_PENDING`) holatda yoziladi va nusxa to‘liq tugagach galereyada ko‘rinadigan qilinadi.
- Saqlash xatosida yarimta galereya fayli o‘chiriladi; tayyor MP4 ilovaning Movies papkasida qoladi.
- Galereyaga avtomatik saqlash Android 10+ da ishlaydi.


## v0.25 export quality controls
- Added target output short-side selection: 720p or 1080p, preserving portrait/landscape orientation.
- Added 24 or 30 FPS selection. Still images receive the selected frame rate; video clips use it as a maximum frame rate.
- Uses Media3 `Presentation.createForShortSide` to scale visual media. Actual encoder support remains device-dependent and must be verified by a real Android build/device export test.


## v0.26 — encoder preflight
- Before starting MP4 export, checks Android's regular codec list for an AVC video encoder that advertises the selected 720p/1080p portrait or landscape size and 24/30 FPS.
- If no matching encoder is reported, export is stopped with a clear message instead of starting a predictably unsupported job.
- This is a capability pre-check, not a guarantee that a full export will succeed; real media, memory, thermal, and device-specific Transformer behavior still require device testing.


## v0.27 — Project text autosave
- Added a 600 ms debounced autosave for the project topic, script, SEO title, SEO description, and tags.
- Text edits are written to the existing local Room project record while the user works; the manual save action remains available.
- Autosave uses the existing `ProjectDao.updateContent` path and does not add cloud storage or new paid services.
- ZIP integrity can be checked locally; a Gradle build and device test are still required before treating this as a working APK.


## v0.27.1 — compile error fixes
- Moved the local `startAi` callback above the document-picker callback that invokes it, fixing the unresolved reference caused by declaration order.
- Updated `PictureInPictureCompositorSettings.getOutputSize` to use the mutable list parameter required by the Media3 `VideoCompositorSettings` Kotlin override.
- Incremented Android versionCode to 28 and versionName to `0.27.1-dev`.
- These source-level fixes address the two compiler errors reported from GitHub Actions. A fresh Gradle build and device test are still required; this archive is not a verified APK.
