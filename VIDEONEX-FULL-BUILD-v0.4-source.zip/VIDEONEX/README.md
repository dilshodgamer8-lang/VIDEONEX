# VIDEONEX — FULL BUILD development source

Android application built with Kotlin, Jetpack Compose and Room.

## Included in this development package
- Uzbek black/gold navigation: Home, AI Studio, Projects, Settings.
- Local Room project storage.
- Project format, duration (1–240 minutes) and language settings.
- Persistent topic, script, YouTube title, description and tags.
- Editable offline outline template (not represented as real AI generation).
- Project deletion confirmation.
- Room migrations from schema v1 → v2 → v3.

## Build
Open `VIDEONEX` in Android Studio or use the repository GitHub Actions workflow.
The app requires JDK 17, Android SDK 35 and Gradle 8.9 (the repository workflow provisions these).

## Important status
This is an in-progress development build, not the finished VIDEONEX product. Real online AI research/generation, encrypted API-key manager, media import, multitrack editing, subtitles, rendering/export, thumbnail generation, backup/restore and automated tests are not implemented in this package. Do not advertise these as working features yet.

All current project data is stored locally in the app's Room database.
