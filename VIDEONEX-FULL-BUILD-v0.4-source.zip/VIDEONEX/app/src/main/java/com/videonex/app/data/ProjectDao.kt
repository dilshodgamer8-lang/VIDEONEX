package com.videonex.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeProjects(): Flow<List<VideoProject>>

    @Insert
    suspend fun insert(project: VideoProject): Long

    @Query("UPDATE projects SET format = :format, durationMinutes = :durationMinutes, language = :language, updatedAt = :updatedAt WHERE id = :projectId")
    suspend fun updateSettings(projectId: Long, format: String, durationMinutes: Int, language: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE projects SET topic = :topic, script = :script, seoTitle = :seoTitle, seoDescription = :seoDescription, seoTags = :seoTags, updatedAt = :updatedAt WHERE id = :projectId")
    suspend fun updateContent(projectId: Long, topic: String, script: String, seoTitle: String, seoDescription: String, seoTags: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun delete(projectId: Long)
}
