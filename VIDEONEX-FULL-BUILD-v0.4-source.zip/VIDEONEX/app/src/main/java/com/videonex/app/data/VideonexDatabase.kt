package com.videonex.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [VideoProject::class], version = 3, exportSchema = false)
abstract class VideonexDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE projects_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    name TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    format TEXT NOT NULL,
                    durationMinutes INTEGER NOT NULL,
                    language TEXT NOT NULL,
                    createdAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    status TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""INSERT INTO projects_new (id, name, direction, format, durationMinutes, language, createdAt, updatedAt, status)
                    SELECT id, name, direction, format, 10, 'O‘zbek', createdAt, updatedAt, status FROM projects""".trimIndent())
                db.execSQL("DROP TABLE projects")
                db.execSQL("ALTER TABLE projects_new RENAME TO projects")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN topic TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN script TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN seoTitle TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN seoDescription TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE projects ADD COLUMN seoTags TEXT NOT NULL DEFAULT ''")
            }
        }

        @Volatile private var INSTANCE: VideonexDatabase? = null

        fun get(context: Context): VideonexDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VideonexDatabase::class.java,
                "videonex_local.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}
