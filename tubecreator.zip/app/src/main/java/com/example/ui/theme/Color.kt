package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Studio Palette
val StudioRed = Color(0xFFFF2A42)
val StudioRedVariant = Color(0xFFCC182E)
val StudioRedGlow = Color(0x33FF2A42)

val DarkBackground = Color(0xFF090D14)
val DarkSurface = Color(0xFF111724)
val DarkSurfaceElevated = Color(0xFF182235)
val DarkSurfaceBorder = Color(0xFF26354D)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentGold = Color(0xFFF59E0B)
val AccentCyan = Color(0xFF06B6D4)
val AccentEmerald = Color(0xFF10B981)
val AccentPurple = Color(0xFF8B5CF6)
val AccentOrange = Color(0xFFF97316)
