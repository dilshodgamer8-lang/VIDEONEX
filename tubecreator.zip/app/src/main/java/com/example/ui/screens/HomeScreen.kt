package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Template
import com.example.ui.components.AboutDialog
import com.example.ui.components.AddTemplateDialog
import com.example.ui.components.CategoryBadge
import com.example.ui.components.ImportExportDialog
import com.example.ui.components.InfoPill
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StudioRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TubeCreatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: TubeCreatorViewModel,
  modifier: Modifier = Modifier
) {
  val templates by viewModel.templates.collectAsState()
  val projects by viewModel.projects.collectAsState()
  val context = LocalContext.current

  var selectedCategory by remember { mutableStateOf("Barchasi") }
  var showAddDialog by remember { mutableStateOf(false) }
  var showImportExportDialog by remember { mutableStateOf(false) }
  var showAboutDialog by remember { mutableStateOf(false) }

  val categories = listOf("Barchasi", "Tarix", "Horror", "Psixologiya", "Biznes", "Tibbiyot", "Madaniyat", "Hujjatli", "Falsafa")

  val filteredTemplates = remember(templates, selectedCategory) {
    if (selectedCategory == "Barchasi") templates
    else templates.filter { it.category.equals(selectedCategory, ignoreCase = true) }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(StudioRed)
            ) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "TubeCreator",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
              )
              Text(
                text = "YouTube Video Studiyasi",
                color = TextSecondary,
                fontSize = 11.sp
              )
            }
          }
        },
        actions = {
          // Add Custom Template
          IconButton(
            onClick = { showAddDialog = true },
            modifier = Modifier.testTag("add_template_button")
          ) {
            Icon(Icons.Default.Add, contentDescription = "Shablon qo'shish", tint = AccentGold)
          }

          // Import / Export
          IconButton(
            onClick = { showImportExportDialog = true },
            modifier = Modifier.testTag("import_export_button")
          ) {
            Icon(Icons.Default.FileDownload, contentDescription = "Import/Eksport", tint = AccentCyan)
          }

          // Saved Projects
          IconButton(
            onClick = { viewModel.navigateTo("projects") },
            modifier = Modifier.testTag("projects_button")
          ) {
            BadgedBox(
              badge = {
                if (projects.isNotEmpty()) {
                  Badge(containerColor = StudioRed) {
                    Text("${projects.size}", color = Color.White)
                  }
                }
              }
            ) {
              Icon(Icons.Default.Bookmark, contentDescription = "Loyihalar", tint = TextPrimary)
            }
          }

          // Settings
          IconButton(
            onClick = { viewModel.navigateTo("settings") },
            modifier = Modifier.testTag("settings_button")
          ) {
            Icon(Icons.Default.Settings, contentDescription = "Sozlamalar", tint = TextSecondary)
          }

          // About
          IconButton(
            onClick = { showAboutDialog = true },
            modifier = Modifier.testTag("about_button")
          ) {
            Icon(Icons.Default.Info, contentDescription = "Dastur haqida", tint = TextSecondary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = DarkBackground
        )
      )
    },
    containerColor = DarkBackground,
    modifier = modifier.fillMaxSize()
  ) { padding ->
    LazyColumn(
      contentPadding = PaddingValues(bottom = 32.dp),
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
    ) {
      // Header Banner
      item {
        StudioHeroBanner(
          projectCount = projects.size,
          onNewProjectClick = {
            val first = templates.firstOrNull() ?: Template.DEFAULT_TEMPLATES[0]
            viewModel.startNewCreation(first)
          }
        )
      }

      // Categories Carousel
      item {
        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          items(categories) { category ->
            val isSelected = selectedCategory == category
            FilterChip(
              selected = isSelected,
              onClick = { selectedCategory = category },
              label = {
                Text(
                  text = category,
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = StudioRed,
                selectedLabelColor = Color.White,
                containerColor = DarkSurfaceElevated,
                labelColor = TextSecondary
              ),
              border = FilterChipDefaults.filterChipBorder(
                borderColor = if (isSelected) StudioRed else DarkSurfaceBorder,
                selectedBorderColor = StudioRed,
                enabled = true,
                selected = isSelected
              )
            )
          }
        }
      }

      // Templates Count & Section Title
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Yo'nalish Shablonlari (${filteredTemplates.size})",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
          Text(
            text = "1-bosqich: Tanlang",
            color = AccentCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Templates List
      items(filteredTemplates, key = { it.id }) { template ->
        TemplateCard(
          template = template,
          onStart = { viewModel.startNewCreation(template) }
        )
      }
    }
  }

  // Dialogs
  if (showAddDialog) {
    AddTemplateDialog(
      onDismiss = { showAddDialog = false },
      onSave = { newTemplate ->
        viewModel.addCustomTemplate(newTemplate)
      }
    )
  }

  if (showImportExportDialog) {
    ImportExportDialog(
      exportJson = viewModel.exportTemplatesJson(),
      onImport = { json ->
        viewModel.importTemplatesJson(json) { count ->
          Toast.makeText(context, "$count ta shablon muvaffaqiyatli import qilindi!", Toast.LENGTH_SHORT).show()
        }
      },
      onDismiss = { showImportExportDialog = false }
    )
  }

  if (showAboutDialog) {
    AboutDialog(onDismiss = { showAboutDialog = false })
  }
}

@Composable
fun StudioHeroBanner(
  projectCount: Int,
  onNewProjectClick: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, StudioRed.copy(alpha = 0.35f)),
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 10.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        CategoryBadge(
          text = "YOUTUBE PRODUCTION PIPELINE",
          color = StudioRed
        )
        if (projectCount > 0) {
          InfoPill(text = "$projectCount ta loyiha saqlangan")
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "G'oyadan Tayyor Videogacha",
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Mavzu, senariy, rasm promptlari, avtomatik montaj vaqt paneli, SEO va yuqori CTR thumbnail — hammasi bitta ilovada.",
        color = TextSecondary,
        fontSize = 13.sp,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(14.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          InfoPill("11 ta shablon")
          InfoPill("Google API faktlar")
          InfoPill("SRT subtitr")
        }
      }
    }
  }
}

@Composable
fun TemplateCard(
  template: Template,
  onStart: () -> Unit
) {
  var isExpanded by remember { mutableStateOf(false) }
  val cardColor = try {
    Color(android.graphics.Color.parseColor(template.colorTag))
  } catch (_: Exception) {
    StudioRed
  }

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .testTag("template_card_${template.id}")
      .clickable { isExpanded = !isExpanded }
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Badges Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          CategoryBadge(text = template.category, color = cardColor)
          InfoPill(text = template.aspectRatio)
          InfoPill(text = "~${template.defaultDurationMinutes} daq")
          InfoPill(text = template.language)
        }

        if (template.isSourceRequired) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(AccentEmerald.copy(alpha = 0.15f))
              .padding(horizontal = 6.dp, vertical = 3.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = AccentEmerald,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Manba majburiy",
                color = AccentEmerald,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Title & Description
      Text(
        text = template.title,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = template.description,
        color = TextSecondary,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        maxLines = if (isExpanded) Int.MAX_VALUE else 2,
        overflow = TextOverflow.Ellipsis
      )

      if (isExpanded) {
        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          color = DarkSurfaceElevated,
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "🎨 Rasm Uslubi Bloki:",
              color = AccentGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = template.imageStylePrompt,
              color = TextPrimary,
              fontSize = 11.sp,
              lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "🎙 Senariy Ohangi:",
              color = AccentCyan,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = template.scriptTone,
              color = TextSecondary,
              fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "🎬 Montaj & Effektlar:",
              color = cardColor,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = template.montageEffect,
              color = TextSecondary,
              fontSize = 11.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Action Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isExpanded) "Kamroq ko'rsatish" else "Batafsil ma'lumot",
          color = TextMuted,
          fontSize = 11.sp,
          modifier = Modifier.clickable { isExpanded = !isExpanded }
        )

        Button(
          onClick = onStart,
          colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
          modifier = Modifier.testTag("start_template_${template.id}")
        ) {
          Text(
            text = "Video Yaratish",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }
  }
}
