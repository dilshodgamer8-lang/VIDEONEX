package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioDarkColorScheme = darkColorScheme(
  primary = StudioRed,
  onPrimary = Color.White,
  primaryContainer = StudioRedVariant,
  onPrimaryContainer = Color.White,
  secondary = AccentCyan,
  onSecondary = Color.Black,
  secondaryContainer = DarkSurfaceElevated,
  onSecondaryContainer = AccentCyan,
  tertiary = AccentGold,
  onTertiary = Color.Black,
  background = DarkBackground,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  outline = DarkSurfaceBorder
)

@Composable
fun TubeCreatorTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = StudioDarkColorScheme,
    typography = Typography,
    content = content
  )
}
