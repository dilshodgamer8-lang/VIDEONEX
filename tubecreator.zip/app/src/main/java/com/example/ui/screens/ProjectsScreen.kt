package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Project
import com.example.ui.components.CategoryBadge
import com.example.ui.components.InfoPill
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.StudioRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TubeCreatorViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
  viewModel: TubeCreatorViewModel,
  modifier: Modifier = Modifier
) {
  val projects by viewModel.projects.collectAsState()

  BackHandler {
    viewModel.navigateTo("home")
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Saqlangan Loyihalar (${projects.size})",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
        },
        navigationIcon = {
          IconButton(onClick = { viewModel.navigateTo("home") }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Orqaga", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
      )
    },
    containerColor = DarkBackground,
    modifier = modifier.fillMaxSize()
  ) { padding ->
    if (projects.isEmpty()) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .fillMaxSize()
          .padding(padding)
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.Movie, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(12.dp))
          Text("Hozircha saqlangan loyihalar yo'q", color = TextSecondary, fontSize = 14.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Text("Bosh sahifadan shablon tanlab video yaratishni boshlang", color = TextMuted, fontSize = 12.sp)
        }
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
          .fillMaxSize()
          .padding(padding)
      ) {
        items(projects, key = { it.id }) { project ->
          ProjectCard(
            project = project,
            onResume = { viewModel.resumeProject(project) },
            onDelete = { viewModel.deleteProject(project) }
          )
        }
      }
    }
  }
}

@Composable
fun ProjectCard(
  project: Project,
  onResume: () -> Unit,
  onDelete: () -> Unit
) {
  val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
  val dateString = dateFormat.format(Date(project.updatedAt))

  val stepName = when (project.currentStep) {
    1 -> "1-bosqich: Mavzu"
    2 -> "2-bosqich: Format & Vaqt"
    3 -> "3-bosqich: Senariy"
    4 -> "4-bosqich: Promptlar"
    5 -> "5-bosqich: Montaj & Vaqt paneli"
    else -> "6-bosqich: SEO & Eksport"
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onResume() }
      .testTag("project_item_${project.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          CategoryBadge(text = project.templateCategory, color = StudioRed)
          InfoPill(text = project.aspectRatio)
          InfoPill(text = "${project.durationMinutes} daq")
        }

        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Delete, contentDescription = "O'chirish", tint = TextMuted, modifier = Modifier.size(16.dp))
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = project.title,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
      )

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Shablon: ${project.templateTitle}",
        color = TextSecondary,
        fontSize = 12.sp
      )

      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = stepName, color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Text(text = "Oxirgi o'zgarish: $dateString", color = TextMuted, fontSize = 10.sp)
        }

        Button(
          onClick = onResume,
          colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Davom ettirish", fontSize = 12.sp)
        }
      }
    }
  }
}
