package com.example.ui.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.local.JsonHelper
import com.example.data.local.SettingsPreferences
import com.example.data.model.Project
import com.example.data.model.ScriptScene
import com.example.data.model.Template
import com.example.data.model.ThumbnailConcept
import com.example.data.model.TopicSuggestion
import com.example.data.repository.ProjectRepository
import com.example.data.repository.TemplateRepository
import com.example.data.service.AudioMontageEngine
import com.example.data.service.ContentGenerationService
import com.example.data.service.SubtitleCue
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class TubeCreatorViewModel(application: Application) : AndroidViewModel(application) {

  private val database = AppDatabase.getDatabase(application)
  private val templateRepo = TemplateRepository(database.templateDao())
  private val projectRepo = ProjectRepository(database.projectDao())
  val settings = SettingsPreferences(application)
  val audioMontageEngine = AudioMontageEngine(application)

  private val generationService = ContentGenerationService {
    settings.geminiApiKey.ifBlank {
      try {
        BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String ?: ""
      } catch (_: Exception) {
        ""
      }
    }
  }

  val templates: StateFlow<List<Template>> = templateRepo.allTemplates
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Template.DEFAULT_TEMPLATES)

  val projects: StateFlow<List<Project>> = projectRepo.allProjects
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Navigation State
  // "home", "creation", "projects", "settings"
  private val _currentScreen = MutableStateFlow("home")
  val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

  // Creation Flow State
  private val _currentStep = MutableStateFlow(1) // 1..6
  val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

  private val _activeTemplate = MutableStateFlow<Template?>(null)
  val activeTemplate: StateFlow<Template?> = _activeTemplate.asStateFlow()

  private val _activeProjectId = MutableStateFlow<Long?>(null)
  val activeProjectId: StateFlow<Long?> = _activeProjectId.asStateFlow()

  // Step 1: Topics
  private val _topicSuggestions = MutableStateFlow<List<TopicSuggestion>>(emptyList())
  val topicSuggestions: StateFlow<List<TopicSuggestion>> = _topicSuggestions.asStateFlow()

  private val _selectedTopic = MutableStateFlow("")
  val selectedTopic: StateFlow<String> = _selectedTopic.asStateFlow()

  private val _isLoadingTopics = MutableStateFlow(false)
  val isLoadingTopics: StateFlow<Boolean> = _isLoadingTopics.asStateFlow()

  // Step 2: Format & Time
  private val _selectedAspectRatio = MutableStateFlow("16:9")
  val selectedAspectRatio: StateFlow<String> = _selectedAspectRatio.asStateFlow()

  private val _selectedDurationMinutes = MutableStateFlow(8)
  val selectedDurationMinutes: StateFlow<Int> = _selectedDurationMinutes.asStateFlow()

  private val _selectedLanguage = MutableStateFlow("O'zbekcha")
  val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

  // Step 3 & 4: Script, Facts & Prompts
  private val _scenes = MutableStateFlow<List<ScriptScene>>(emptyList())
  val scenes: StateFlow<List<ScriptScene>> = _scenes.asStateFlow()

  private val _cleanVoiceText = MutableStateFlow("")
  val cleanVoiceText: StateFlow<String> = _cleanVoiceText.asStateFlow()

  private val _isGeneratingScript = MutableStateFlow(false)
  val isGeneratingScript: StateFlow<Boolean> = _isGeneratingScript.asStateFlow()

  // Step 5: Montage & Player
  private val _selectedAudioFile = MutableStateFlow<File?>(null)
  val selectedAudioFile: StateFlow<File?> = _selectedAudioFile.asStateFlow()

  private val _selectedMusicTrack = MutableStateFlow("Dramatik Kino Foni")
  val selectedMusicTrack: StateFlow<String> = _selectedMusicTrack.asStateFlow()

  private val _subtitleCues = MutableStateFlow<List<SubtitleCue>>(emptyList())
  val subtitleCues: StateFlow<List<SubtitleCue>> = _subtitleCues.asStateFlow()

  private val _playbackCurrentTimeMs = MutableStateFlow(0L)
  val playbackCurrentTimeMs: StateFlow<Long> = _playbackCurrentTimeMs.asStateFlow()

  private val _isPlayingPreview = MutableStateFlow(false)
  val isPlayingPreview: StateFlow<Boolean> = _isPlayingPreview.asStateFlow()

  private var playbackJob: Job? = null

  // Step 6: SEO & Thumbnails
  private val _seoTitle = MutableStateFlow("")
  val seoTitle: StateFlow<String> = _seoTitle.asStateFlow()

  private val _seoDescription = MutableStateFlow("")
  val seoDescription: StateFlow<String> = _seoDescription.asStateFlow()

  private val _seoTags = MutableStateFlow("")
  val seoTags: StateFlow<String> = _seoTags.asStateFlow()

  private val _thumbnailConcepts = MutableStateFlow<List<ThumbnailConcept>>(emptyList())
  val thumbnailConcepts: StateFlow<List<ThumbnailConcept>> = _thumbnailConcepts.asStateFlow()

  private val _isGeneratingSeo = MutableStateFlow(false)
  val isGeneratingSeo: StateFlow<Boolean> = _isGeneratingSeo.asStateFlow()

  private val _exportStatusMessage = MutableStateFlow<String?>(null)
  val exportStatusMessage: StateFlow<String?> = _exportStatusMessage.asStateFlow()

  init {
    viewModelScope.launch {
      templateRepo.seedDefaultsIfEmpty()
    }
  }

  fun navigateTo(screen: String) {
    _currentScreen.value = screen
  }

  fun startNewCreation(template: Template) {
    _activeTemplate.value = template
    _activeProjectId.value = null
    _currentStep.value = 1
    _selectedAspectRatio.value = template.aspectRatio
    _selectedDurationMinutes.value = template.defaultDurationMinutes
    _selectedLanguage.value = template.language
    _selectedTopic.value = ""
    _scenes.value = emptyList()
    _cleanVoiceText.value = ""
    _seoTitle.value = ""
    _seoDescription.value = ""
    _seoTags.value = ""
    _thumbnailConcepts.value = emptyList()
    _currentScreen.value = "creation"

    loadTopicsForTemplate(template, template.language)
  }

  fun resumeProject(project: Project) {
    viewModelScope.launch {
      val template = templateRepo.getTemplateById(project.templateId)
        ?: Template.DEFAULT_TEMPLATES.firstOrNull { it.id == project.templateId }
        ?: Template.DEFAULT_TEMPLATES[0]

      _activeTemplate.value = template
      _activeProjectId.value = project.id
      _currentStep.value = project.currentStep
      _selectedAspectRatio.value = project.aspectRatio
      _selectedDurationMinutes.value = project.durationMinutes
      _selectedLanguage.value = project.language
      _selectedTopic.value = project.selectedTopic
      _cleanVoiceText.value = project.cleanVoiceText
      _selectedMusicTrack.value = project.backgroundMusicTrack
      _seoTitle.value = project.seoTitle
      _seoDescription.value = project.seoDescription
      _seoTags.value = project.seoTags

      val deserializedScenes = JsonHelper.deserializeScenes(project.scenesJson)
      _scenes.value = deserializedScenes
      _subtitleCues.value = audioMontageEngine.generateSubtitles(deserializedScenes)

      _thumbnailConcepts.value = JsonHelper.deserializeThumbnails(project.thumbnailConceptsJson)

      _currentScreen.value = "creation"
    }
  }

  fun loadTopicsForTemplate(template: Template, language: String) {
    viewModelScope.launch {
      _isLoadingTopics.value = true
      val list = generationService.generateTopics(template, language)
      _topicSuggestions.value = list
      _isLoadingTopics.value = false
    }
  }

  fun selectTopic(topic: String) {
    _selectedTopic.value = topic
  }

  fun setFormatAndTime(aspectRatio: String, durationMinutes: Int, language: String) {
    _selectedAspectRatio.value = aspectRatio
    _selectedDurationMinutes.value = durationMinutes
    _selectedLanguage.value = language
  }

  fun nextStep() {
    val next = (_currentStep.value + 1).coerceAtMost(6)
    _currentStep.value = next

    // Auto-trigger generators when reaching relevant steps
    if (next == 3 && _scenes.value.isEmpty()) {
      generateScript()
    } else if (next == 5 && _subtitleCues.value.isEmpty()) {
      _subtitleCues.value = audioMontageEngine.generateSubtitles(_scenes.value)
    } else if (next == 6 && _thumbnailConcepts.value.isEmpty()) {
      generateSeoAndThumbnails()
    }

    saveCurrentProjectState()
  }

  fun previousStep() {
    _currentStep.value = (_currentStep.value - 1).coerceAtLeast(1)
  }

  fun goToStep(step: Int) {
    if (step in 1..6) {
      _currentStep.value = step
      if (step == 3 && _scenes.value.isEmpty()) generateScript()
      if (step == 5 && _subtitleCues.value.isEmpty()) {
        _subtitleCues.value = audioMontageEngine.generateSubtitles(_scenes.value)
      }
      if (step == 6 && _thumbnailConcepts.value.isEmpty()) generateSeoAndThumbnails()
    }
  }

  fun generateScript() {
    val template = _activeTemplate.value ?: return
    val topic = _selectedTopic.value.ifBlank { "Noma'lum Mavzu" }

    viewModelScope.launch {
      _isGeneratingScript.value = true
      val (sceneList, voiceText) = generationService.generateScriptAndScenes(
        template = template,
        topic = topic,
        aspectRatio = _selectedAspectRatio.value,
        durationMinutes = _selectedDurationMinutes.value,
        language = _selectedLanguage.value
      )
      val timedScenes = audioMontageEngine.calculateTimecodes(sceneList)
      _scenes.value = timedScenes
      _cleanVoiceText.value = voiceText
      _subtitleCues.value = audioMontageEngine.generateSubtitles(timedScenes)
      _isGeneratingScript.value = false

      saveCurrentProjectState()
    }
  }

  fun toggleFactVerification(sceneNumber: Int) {
    val updated = _scenes.value.map { scene ->
      if (scene.sceneNumber == sceneNumber) {
        scene.copy(isSourceVerified = !scene.isSourceVerified)
      } else scene
    }
    _scenes.value = updated
    saveCurrentProjectState()
  }

  fun updateSceneDuration(sceneNumber: Int, deltaSeconds: Int) {
    val updated = _scenes.value.map { scene ->
      if (scene.sceneNumber == sceneNumber) {
        val newDuration = (scene.durationSeconds + deltaSeconds).coerceIn(3, 120)
        scene.copy(durationSeconds = newDuration)
      } else scene
    }
    val recalculated = audioMontageEngine.calculateTimecodes(updated)
    _scenes.value = recalculated
    _subtitleCues.value = audioMontageEngine.generateSubtitles(recalculated)
    saveCurrentProjectState()
  }

  fun setSceneImageUri(sceneNumber: Int, uri: String) {
    val updated = _scenes.value.map { scene ->
      if (scene.sceneNumber == sceneNumber) {
        scene.copy(imageUri = uri)
      } else scene
    }
    _scenes.value = updated
    saveCurrentProjectState()
  }

  fun setMusicTrack(track: String) {
    _selectedMusicTrack.value = track
    saveCurrentProjectState()
  }

  fun togglePreviewPlayback() {
    if (_isPlayingPreview.value) {
      stopPreviewPlayback()
    } else {
      startPreviewPlayback()
    }
  }

  private fun startPreviewPlayback() {
    val totalSeconds = _scenes.value.sumOf { it.durationSeconds }.coerceAtLeast(10)
    val totalMs = totalSeconds * 1000L
    _isPlayingPreview.value = true

    playbackJob?.cancel()
    playbackJob = viewModelScope.launch {
      val startTime = System.currentTimeMillis() - _playbackCurrentTimeMs.value
      while (_isPlayingPreview.value) {
        val elapsed = System.currentTimeMillis() - startTime
        if (elapsed >= totalMs) {
          _playbackCurrentTimeMs.value = 0L
          _isPlayingPreview.value = false
          break
        }
        _playbackCurrentTimeMs.value = elapsed
        delay(50)
      }
    }
  }

  fun stopPreviewPlayback() {
    _isPlayingPreview.value = false
    playbackJob?.cancel()
  }

  fun seekPreviewTo(positionMs: Long) {
    _playbackCurrentTimeMs.value = positionMs
    if (_isPlayingPreview.value) {
      startPreviewPlayback()
    }
  }

  fun generateSeoAndThumbnails() {
    val template = _activeTemplate.value ?: return
    val topic = _selectedTopic.value.ifBlank { "Video" }

    viewModelScope.launch {
      _isGeneratingSeo.value = true
      val (title, desc, thumbs) = generationService.generateSeoAndThumbnails(
        topic = topic,
        template = template,
        language = _selectedLanguage.value
      )
      _seoTitle.value = title
      _seoDescription.value = desc
      val tags = if (_selectedLanguage.value.startsWith("O'zbek")) {
        "youtube, o'zbekcha, $topic, yangi video, faktlar, montaj, trending"
      } else {
        "youtube, documentary, $topic, true story, viral, explained, deep dive"
      }
      _seoTags.value = tags
      _thumbnailConcepts.value = thumbs
      _isGeneratingSeo.value = false

      saveCurrentProjectState()
    }
  }

  fun exportProject() {
    val title = _selectedTopic.value.ifBlank { _activeTemplate.value?.title ?: "YouTube Video" }
    viewModelScope.launch {
      try {
        val folder = audioMontageEngine.exportProjectPackage(
          projectTitle = title,
          scenes = _scenes.value,
          cleanVoiceText = _cleanVoiceText.value,
          seoTitle = _seoTitle.value,
          seoDesc = _seoDescription.value,
          seoTags = _seoTags.value
        )
        _exportStatusMessage.value = "Muvaffaqiyatli eksport qilindi: ${folder.name}"
        Toast.makeText(getApplication(), "Eksport tayyor: ${folder.absolutePath}", Toast.LENGTH_LONG).show()
      } catch (e: Exception) {
        _exportStatusMessage.value = "Eksportda xatolik: ${e.message}"
      }
    }
  }

  fun clearExportStatus() {
    _exportStatusMessage.value = null
  }

  fun saveCurrentProjectState() {
    val template = _activeTemplate.value ?: return
    val topic = _selectedTopic.value
    if (topic.isBlank() && _scenes.value.isEmpty()) return

    viewModelScope.launch {
      val project = Project(
        id = _activeProjectId.value ?: 0,
        title = topic.ifBlank { template.title },
        templateId = template.id,
        templateTitle = template.title,
        templateCategory = template.category,
        language = _selectedLanguage.value,
        aspectRatio = _selectedAspectRatio.value,
        durationMinutes = _selectedDurationMinutes.value,
        currentStep = _currentStep.value,
        selectedTopic = topic,
        scenesJson = JsonHelper.serializeScenes(_scenes.value),
        cleanVoiceText = _cleanVoiceText.value,
        audioUri = _selectedAudioFile.value?.absolutePath,
        backgroundMusicTrack = _selectedMusicTrack.value,
        seoTitle = _seoTitle.value,
        seoDescription = _seoDescription.value,
        seoTags = _seoTags.value,
        thumbnailConceptsJson = JsonHelper.serializeThumbnails(_thumbnailConcepts.value),
        updatedAt = System.currentTimeMillis()
      )
      val newId = projectRepo.saveProject(project)
      if (_activeProjectId.value == null) {
        _activeProjectId.value = newId
      }
    }
  }

  fun deleteProject(project: Project) {
    viewModelScope.launch {
      projectRepo.deleteProject(project)
    }
  }

  fun addCustomTemplate(template: Template) {
    viewModelScope.launch {
      templateRepo.addTemplate(template)
      Toast.makeText(getApplication(), "Yangi shablon saqlandi!", Toast.LENGTH_SHORT).show()
    }
  }

  fun exportTemplatesJson(): String {
    return templateRepo.exportTemplatesToJson(templates.value)
  }

  fun importTemplatesJson(json: String, onComplete: (Int) -> Unit) {
    viewModelScope.launch {
      val count = templateRepo.importTemplatesFromJson(json)
      onComplete(count)
    }
  }
}
