package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StudioRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TubeCreatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  viewModel: TubeCreatorViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val settings = viewModel.settings

  var googleKey by remember { mutableStateOf(settings.googleApiKey) }
  var geminiKey by remember { mutableStateOf(settings.geminiApiKey) }
  var keyTestResult by remember { mutableStateOf("") }
  var defaultLang by remember { mutableStateOf(settings.defaultLanguage) }
  var videoQuality by remember { mutableStateOf(settings.defaultVideoQuality) }
  var subtitleSize by remember { mutableFloatStateOf(settings.subtitleFontSize.toFloat()) }
  var subtitleStyle by remember { mutableStateOf(settings.subtitleStyle) }

  BackHandler {
    viewModel.navigateTo("home")
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Sozlamalar",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
        },
        navigationIcon = {
          IconButton(onClick = { viewModel.navigateTo("home") }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Orqaga", tint = TextPrimary)
          }
        },
        actions = {
          IconButton(
            onClick = {
              settings.googleApiKey = googleKey.trim()
              settings.geminiApiKey = geminiKey.trim()
              settings.defaultLanguage = defaultLang
              settings.defaultVideoQuality = videoQuality
              settings.subtitleFontSize = subtitleSize.toInt()
              settings.subtitleStyle = subtitleStyle
              Toast.makeText(context, "Sozlamalar saqlandi!", Toast.LENGTH_SHORT).show()
              viewModel.navigateTo("home")
            },
            modifier = Modifier.testTag("save_settings_button")
          ) {
            Icon(Icons.Default.Save, contentDescription = "Saqlash", tint = AccentEmerald)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
      )
    },
    containerColor = DarkBackground,
    modifier = modifier.fillMaxSize()
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(16.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // API Keys Section
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Key, contentDescription = null, tint = AccentGold, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("API Kalitlar", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Google API (qidiruv va to'g'ri faktlar uchun) hamda LLM API (senariy va promptlar uchun):",
            color = TextSecondary,
            fontSize = 12.sp
          )

          Spacer(modifier = Modifier.height(12.dp))
          Text("Google Search API Key:", color = TextSecondary, fontSize = 12.sp)
          OutlinedTextField(
            value = googleKey,
            onValueChange = { googleKey = it },
            placeholder = { Text("AIzaSy...") },
            modifier = Modifier.fillMaxWidth().testTag("google_api_key_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = StudioRed,
              unfocusedBorderColor = DarkSurfaceBorder
            )
          )

          Spacer(modifier = Modifier.height(10.dp))
          Text("Gemini / LLM API Key:", color = TextSecondary, fontSize = 12.sp)
          OutlinedTextField(
            value = geminiKey,
            onValueChange = { geminiKey = it },
            placeholder = { Text("AIzaSy...") },
            modifier = Modifier.fillMaxWidth().testTag("gemini_api_key_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = StudioRed,
              unfocusedBorderColor = DarkSurfaceBorder
            )
          )
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = {
              settings.geminiApiKey = geminiKey.trim()
              keyTestResult = "Tekshirilmoqda..."
              viewModel.testApiKey { result -> keyTestResult = result }
            },
            colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Gemini kalitini tekshirish")
          }
          if (keyTestResult.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(keyTestResult, color = TextPrimary, fontSize = 12.sp)
          }
        }
      }

      // Default Language
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Standart Til", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            listOf("O'zbekcha", "English").forEach { lang ->
              Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                  selected = defaultLang == lang,
                  onClick = { defaultLang = lang },
                  colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(lang, color = TextPrimary, fontSize = 13.sp)
              }
            }
          }
        }
      }

      // Video Quality
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Eksport Sifati", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Spacer(modifier = Modifier.height(8.dp))
          val qualities = listOf("1080p Full HD", "4K Ultra HD", "720p HD")
          qualities.forEach { q ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(vertical = 2.dp)
            ) {
              RadioButton(
                selected = videoQuality == q,
                onClick = { videoQuality = q },
                colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(q, color = TextPrimary, fontSize = 13.sp)
            }
          }
        }
      }

      // Subtitle Settings
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Subtitr Sozlamalari", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text("Shrift o'lchami: ${subtitleSize.toInt()} sp", color = TextSecondary, fontSize = 12.sp)
          Slider(
            value = subtitleSize,
            onValueChange = { subtitleSize = it },
            valueRange = 14f..32f,
            steps = 9,
            colors = SliderDefaults.colors(thumbColor = StudioRed, activeTrackColor = StudioRed)
          )

          Spacer(modifier = Modifier.height(8.dp))
          Text("Subtitr Uslubi:", color = TextSecondary, fontSize = 12.sp)
          val styles = listOf(
            "YouTube Shorts (Yellow Highlight)",
            "Kinematografik Oq & Soya",
            "Neon Ramkali Zamonaviy"
          )
          styles.forEach { style ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(vertical = 2.dp)
            ) {
              RadioButton(
                selected = subtitleStyle == style,
                onClick = { subtitleStyle = style },
                colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(style, color = TextPrimary, fontSize = 12.sp)
            }
          }
        }
      }

      // Save Button
      Button(
        onClick = {
          settings.googleApiKey = googleKey.trim()
          settings.geminiApiKey = geminiKey.trim()
          settings.defaultLanguage = defaultLang
          settings.defaultVideoQuality = videoQuality
          settings.subtitleFontSize = subtitleSize.toInt()
          settings.subtitleStyle = subtitleStyle
          Toast.makeText(context, "Barcha sozlamalar saqlandi!", Toast.LENGTH_SHORT).show()
          viewModel.navigateTo("home")
        },
        colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
        modifier = Modifier.fillMaxWidth().height(48.dp)
      ) {
        Icon(Icons.Default.Save, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Sozlamalarni Saqlash", fontWeight = FontWeight.Bold, fontSize = 15.sp)
      }
    }
  }
}
