package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScriptScene
import com.example.data.model.Template
import com.example.data.model.ThumbnailConcept
import com.example.data.model.TopicSuggestion
import com.example.ui.components.CategoryBadge
import com.example.ui.components.InfoPill
import com.example.ui.components.StepProgressBar
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StudioRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TubeCreatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreationFlowScreen(
  viewModel: TubeCreatorViewModel,
  modifier: Modifier = Modifier
) {
  val currentStep by viewModel.currentStep.collectAsState()
  val activeTemplate by viewModel.activeTemplate.collectAsState()
  val template = activeTemplate ?: Template.DEFAULT_TEMPLATES[0]

  BackHandler {
    if (currentStep > 1) {
      viewModel.previousStep()
    } else {
      viewModel.navigateTo("home")
    }
  }

  val stepTitles = listOf(
    "1. Mavzu Tanlash (Google API / Trend)",
    "2. Format va Vaqt Belgilash",
    "3. Senariy va Faktlar Manbasi",
    "4. Ketma-ket Rasm Promptlari",
    "5. Avtomatik Montaj & Vaqt Paneli",
    "6. SEO, Thumbnail & Eksport"
  )

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = template.title,
              color = TextPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = stepTitles.getOrElse(currentStep - 1) { "Bosqich $currentStep" },
              color = AccentCyan,
              fontSize = 12.sp
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = {
              if (currentStep > 1) viewModel.previousStep() else viewModel.navigateTo("home")
            },
            modifier = Modifier.testTag("flow_back_button")
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Orqaga", tint = TextPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
      )
    },
    bottomBar = {
      CreationFlowBottomBar(
        currentStep = currentStep,
        onPrevious = { viewModel.previousStep() },
        onNext = { viewModel.nextStep() }
      )
    },
    containerColor = DarkBackground,
    modifier = modifier.fillMaxSize()
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
    ) {
      // Interactive Progress Bar
      StepProgressBar(
        currentStep = currentStep,
        onStepClick = { step -> viewModel.goToStep(step) }
      )

      Box(modifier = Modifier.weight(1f)) {
        when (currentStep) {
          1 -> Step1TopicView(viewModel = viewModel, template = template)
          2 -> Step2FormatTimeView(viewModel = viewModel, template = template)
          3 -> Step3ScriptView(viewModel = viewModel, template = template)
          4 -> Step4PromptsView(viewModel = viewModel, template = template)
          5 -> Step5MontageTimelineView(viewModel = viewModel, template = template)
          6 -> Step6SeoExportView(viewModel = viewModel, template = template)
        }
      }
    }
  }
}

@Composable
fun CreationFlowBottomBar(
  currentStep: Int,
  onPrevious: () -> Unit,
  onNext: () -> Unit
) {
  Surface(
    color = DarkSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (currentStep > 1) {
        OutlinedButton(
          onClick = onPrevious,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
          modifier = Modifier.testTag("step_prev_button")
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Oldingi")
        }
      } else {
        Spacer(modifier = Modifier.width(1.dp))
      }

      Button(
        onClick = onNext,
        colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
        modifier = Modifier.testTag("step_next_button")
      ) {
        Text(
          text = if (currentStep == 6) "Tayyor / Saqlash" else "Keyingi Bosqich",
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
      }
    }
  }
}

// -------------------------------------------------------------
// STEP 1: TOPIC SELECTION (Google API / Fact-based topics)
// -------------------------------------------------------------
@Composable
fun Step1TopicView(
  viewModel: TubeCreatorViewModel,
  template: Template
) {
  val suggestions by viewModel.topicSuggestions.collectAsState()
  val selectedTopic by viewModel.selectedTopic.collectAsState()
  val isLoading by viewModel.isLoadingTopics.collectAsState()
  val selectedLanguage by viewModel.selectedLanguage.collectAsState()

  var customTopicInput by remember { mutableStateOf("") }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentGold, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Google API & Trend Mavzular", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            IconButton(
              onClick = { viewModel.loadTopicsForTemplate(template, selectedLanguage) },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.Refresh, contentDescription = "Yangilash", tint = AccentCyan, modifier = Modifier.size(18.dp))
            }
          }
          Text(
            text = "Internetdan yangi va to'g'ri ma'lumotlarga tayanib tavsiya qilingan 5 ta mavzu. Bitta mavzuni tanlang yoki o'zingiz yozing:",
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 16.sp
          )
        }
      }
    }

    if (isLoading) {
      item {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = StudioRed)
            Spacer(modifier = Modifier.height(10.dp))
            Text("Trend mavzular qidirilmoqda...", color = TextSecondary, fontSize = 13.sp)
          }
        }
      }
    } else {
      items(suggestions) { item ->
        val isSelected = selectedTopic == item.title
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DarkSurfaceElevated else DarkSurface
          ),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) StudioRed else DarkSurfaceBorder
          ),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { viewModel.selectTopic(item.title) }
            .testTag("topic_item_${item.id}")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              CategoryBadge(text = "#${item.id} Tavsiya", color = if (isSelected) StudioRed else AccentCyan)
              Text(
                text = "🔥 ${item.viralPotentialScore}% Viral salohiyat",
                color = AccentGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = item.title,
              color = TextPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = item.hook,
              color = TextSecondary,
              fontSize = 12.sp,
              lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(12.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Faktik manba: ${item.factualAngle}",
                color = AccentEmerald,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text("Yoki o'zingizning shaxsiy mavzuingizni kiriting:", color = TextSecondary, fontSize = 12.sp)
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = customTopicInput,
          onValueChange = { customTopicInput = it },
          placeholder = { Text("Mavzu sarlavhasini yozing...") },
          modifier = Modifier.weight(1f).testTag("custom_topic_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )
        Button(
          onClick = {
            if (customTopicInput.isNotBlank()) {
              viewModel.selectTopic(customTopicInput.trim())
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
          modifier = Modifier.testTag("apply_custom_topic_button")
        ) {
          Text("Tanlash")
        }
      }
    }

    if (selectedTopic.isNotBlank()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = StudioRed.copy(alpha = 0.15f)),
          border = androidx.compose.foundation.BorderStroke(1.dp, StudioRed),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StudioRed, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("Tanlangan Mavzu:", color = StudioRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text(selectedTopic, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// STEP 2: FORMAT & TIME SELECTION (16:9 / 9:16, Duration, Lang)
// -------------------------------------------------------------
@Composable
fun Step2FormatTimeView(
  viewModel: TubeCreatorViewModel,
  template: Template
) {
  val selectedRatio by viewModel.selectedAspectRatio.collectAsState()
  val selectedDuration by viewModel.selectedDurationMinutes.collectAsState()
  val selectedLang by viewModel.selectedLanguage.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Aspect Ratio
    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
      shape = RoundedCornerShape(14.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("1. Video Formati", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text("YouTube to'liq video yoki Shorts formati:", color = TextSecondary, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          // 16:9 Long Form
          Surface(
            color = if (selectedRatio == "16:9") StudioRed.copy(alpha = 0.2f) else DarkSurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              if (selectedRatio == "16:9") StudioRed else DarkSurfaceBorder
            ),
            modifier = Modifier
              .weight(1f)
              .clickable { viewModel.setFormatAndTime("16:9", selectedDuration, selectedLang) }
              .padding(8.dp)
              .testTag("ratio_16_9")
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(12.dp)
            ) {
              Box(
                modifier = Modifier
                  .width(64.dp)
                  .height(36.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (selectedRatio == "16:9") StudioRed else DarkSurfaceBorder)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text("16:9 (Long Video)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text("YouTube standart", color = TextSecondary, fontSize = 11.sp)
            }
          }

          // 9:16 Shorts
          Surface(
            color = if (selectedRatio == "9:16") StudioRed.copy(alpha = 0.2f) else DarkSurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              if (selectedRatio == "9:16") StudioRed else DarkSurfaceBorder
            ),
            modifier = Modifier
              .weight(1f)
              .clickable { viewModel.setFormatAndTime("9:16", selectedDuration, selectedLang) }
              .padding(8.dp)
              .testTag("ratio_9_16")
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(12.dp)
            ) {
              Box(
                modifier = Modifier
                  .width(36.dp)
                  .height(64.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (selectedRatio == "9:16") StudioRed else DarkSurfaceBorder)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text("9:16 (Shorts)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text("Vertikal video", color = TextSecondary, fontSize = 11.sp)
            }
          }
        }
      }
    }

    // Duration Presets
    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
      shape = RoundedCornerShape(14.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("2. Standart Davomiylik", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Tavsiya etilgan daqiqa: (Shablon standarti: ~${template.defaultDurationMinutes} daq)", color = TextSecondary, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(5, 8, 10, 15, 20).forEach { minutes ->
            val isSelected = selectedDuration == minutes
            Button(
              onClick = { viewModel.setFormatAndTime(selectedRatio, minutes, selectedLang) },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isSelected) StudioRed else DarkSurfaceElevated
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text(
                text = "${minutes}m",
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            }
          }
        }
      }
    }

    // Language Selection
    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
      shape = RoundedCornerShape(14.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("3. Kontent Tili", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Senariy, promptlar, SEO va thumbnail qaysi tilda yaratilsin:", color = TextSecondary, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          listOf("O'zbekcha", "English").forEach { lang ->
            val isSelected = selectedLang.equals(lang, ignoreCase = true)
            Surface(
              color = if (isSelected) StudioRed.copy(alpha = 0.2f) else DarkSurfaceElevated,
              shape = RoundedCornerShape(10.dp),
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSelected) StudioRed else DarkSurfaceBorder
              ),
              modifier = Modifier
                .weight(1f)
                .clickable { viewModel.setFormatAndTime(selectedRatio, selectedDuration, lang) }
                .padding(4.dp)
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                RadioButton(
                  selected = isSelected,
                  onClick = { viewModel.setFormatAndTime(selectedRatio, selectedDuration, lang) },
                  colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(lang, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              }
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// STEP 3: SCRIPT & FACTS (Scenes, verified sources, clean voice)
// -------------------------------------------------------------
@Composable
fun Step3ScriptView(
  viewModel: TubeCreatorViewModel,
  template: Template
) {
  val scenes by viewModel.scenes.collectAsState()
  val cleanVoiceText by viewModel.cleanVoiceText.collectAsState()
  val isGenerating by viewModel.isGeneratingScript.collectAsState()
  val clipboardManager = LocalClipboardManager.current
  val context = LocalContext.current

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Sahnalar & Manbalar, 1: Toza Ovoz Matni

  Column(modifier = Modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = DarkSurface,
      contentColor = StudioRed,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
          color = StudioRed
        )
      }
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("Sahnalar & Faktlar (${scenes.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("Toza Ovoz Matni", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
      )
    }

    if (isGenerating) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          CircularProgressIndicator(color = StudioRed)
          Spacer(modifier = Modifier.height(12.dp))
          Text("Google faktlari va senariy yozilmoqda...", color = TextSecondary, fontSize = 13.sp)
        }
      }
    } else if (selectedTab == 0) {
      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(10.dp)
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Faktlar tekshirildi. Manbalar yonidagi katakchani belgilab tasdiqlang:",
                color = TextSecondary,
                fontSize = 12.sp
              )
            }
          }
        }

        items(scenes) { scene ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth().testTag("scene_card_${scene.sceneNumber}")
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = scene.title,
                  color = AccentCyan,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
                InfoPill(text = "${scene.durationSeconds} soniya")
              }

              Spacer(modifier = Modifier.height(8.dp))
              Text("🎬 Vizual tavsif:", color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              Text(scene.visualDescription, color = TextPrimary, fontSize = 12.sp)

              Spacer(modifier = Modifier.height(8.dp))
              Text("🎙 Ovoz / Diktat matni:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              Text(
                scene.dialogueText,
                color = TextPrimary,
                fontSize = 13.sp,
                lineHeight = 18.sp
              )

              if (scene.factSource.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                  color = DarkSurfaceElevated,
                  shape = RoundedCornerShape(8.dp),
                  border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Checkbox(
                      checked = scene.isSourceVerified,
                      onCheckedChange = { viewModel.toggleFactVerification(scene.sceneNumber) },
                      colors = CheckboxDefaults.colors(checkedColor = AccentEmerald)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text("Manba havola / arxiv:", color = AccentEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                      Text(scene.factSource, color = TextSecondary, fontSize = 11.sp)
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      // Clean voiceover tab
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Toza Ovoz Matni (O'qish uchun)",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
          Button(
            onClick = {
              clipboardManager.setText(AnnotatedString(cleanVoiceText))
              Toast.makeText(context, "Ovoz matni nusxalandi!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Nusxalash", fontSize = 12.sp)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          color = DarkSurface,
          shape = RoundedCornerShape(12.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
        ) {
          Text(
            text = cleanVoiceText.ifBlank { "Senariy yaratilgach, ovozga o'qish uchun toza matn shu yerda chiqadi." },
            color = TextPrimary,
            fontSize = 14.sp,
            lineHeight = 22.sp
          )
        }

        Spacer(modifier = Modifier.height(12.dp))
        VoiceRecorderControl(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun VoiceRecorderControl(viewModel: TubeCreatorViewModel) {
  val isRecording by viewModel.audioMontageEngine.isRecording.collectAsState()
  val context = LocalContext.current

  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
    border = androidx.compose.foundation.BorderStroke(1.dp, if (isRecording) StudioRed else DarkSurfaceBorder),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isRecording) StudioRed else DarkSurfaceBorder),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Mic, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = if (isRecording) "Ovoz yozilmoqda..." else "Ilova ichida ovoz yozish",
            color = if (isRecording) StudioRed else TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
          Text(
            text = if (isRecording) "Mikrofonga aniq o'qing" else "Tugmani bosib to'g'ridan-to'g'ri yozing",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
      }

      Button(
        onClick = {
          if (isRecording) {
            val file = viewModel.audioMontageEngine.stopRecording()
            if (file != null) {
              Toast.makeText(context, "Ovoz saqlandi: ${file.name}", Toast.LENGTH_SHORT).show()
            }
          } else {
            viewModel.audioMontageEngine.startRecording(
              onSuccess = { Toast.makeText(context, "Ovoz yozish boshlandi!", Toast.LENGTH_SHORT).show() },
              onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
            )
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) Color.Red else StudioRed),
        modifier = Modifier.testTag("record_voice_button")
      ) {
        Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, contentDescription = null)
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (isRecording) "To'xtatish" else "Yozish")
      }
    }
  }
}

// -------------------------------------------------------------
// STEP 4: IMAGE PROMPTS (Sequential 001, 002, 003... in style)
// -------------------------------------------------------------
@Composable
fun Step4PromptsView(
  viewModel: TubeCreatorViewModel,
  template: Template
) {
  val scenes by viewModel.scenes.collectAsState()
  val clipboardManager = LocalClipboardManager.current
  val context = LocalContext.current

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Yagona Uslub Prompt Bloki", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Button(
              onClick = {
                val allPrompts = scenes.joinToString("\n\n") { it.imagePrompt }
                clipboardManager.setText(AnnotatedString(allPrompts))
                Toast.makeText(context, "Barcha promptlar nusxalandi!", Toast.LENGTH_SHORT).show()
              },
              colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
              modifier = Modifier.testTag("copy_all_prompts_button")
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Barchasini Nusxalash", fontSize = 12.sp)
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = template.imageStylePrompt,
            color = TextSecondary,
            fontSize = 11.sp,
            lineHeight = 15.sp
          )
        }
      }
    }

    items(scenes) { scene ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = String.format("%03d rasm", scene.sceneNumber),
              color = AccentCyan,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            IconButton(
              onClick = {
                clipboardManager.setText(AnnotatedString(scene.imagePrompt))
                Toast.makeText(context, "${scene.sceneNumber}-rasm prompti nusxalandi!", Toast.LENGTH_SHORT).show()
              },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "Nusxalash", tint = AccentGold, modifier = Modifier.size(16.dp))
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          Surface(
            color = DarkBackground,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
          ) {
            Text(
              text = scene.imagePrompt,
              color = TextPrimary,
              fontSize = 12.sp,
              modifier = Modifier.padding(10.dp)
            )
          }

          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (scene.imageUri != null) "✓ Rasm biriktirildi" else "Rasm hali yuklanmadi",
              color = if (scene.imageUri != null) AccentEmerald else TextMuted,
              fontSize = 11.sp
            )

            OutlinedButton(
              onClick = {
                // Attach mock / placeholder or picked image
                viewModel.setSceneImageUri(scene.sceneNumber, "mock://image_${scene.sceneNumber}")
                Toast.makeText(context, "${scene.sceneNumber}-rasm biriktirildi!", Toast.LENGTH_SHORT).show()
              },
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
            ) {
              Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Rasmni Tanlash", fontSize = 11.sp)
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// STEP 5: AUTOMATIC MONTAGE & TIMELINE (Zoom/pan, Subtitles, Waveform)
// -------------------------------------------------------------
@Composable
fun Step5MontageTimelineView(
  viewModel: TubeCreatorViewModel,
  template: Template
) {
  val scenes by viewModel.scenes.collectAsState()
  val subtitleCues by viewModel.subtitleCues.collectAsState()
  val currentTimeMs by viewModel.playbackCurrentTimeMs.collectAsState()
  val isPlaying by viewModel.isPlayingPreview.collectAsState()
  val selectedMusic by viewModel.selectedMusicTrack.collectAsState()

  val totalSeconds = remember(scenes) { scenes.sumOf { it.durationSeconds }.coerceAtLeast(1) }
  val totalMs = totalSeconds * 1000L

  // Active scene based on currentTimeMs
  val currentSec = (currentTimeMs / 1000).toInt()
  val activeScene = scenes.firstOrNull {
    currentSec >= it.startTimeSeconds && currentSec < (it.startTimeSeconds + it.durationSeconds)
  } ?: scenes.firstOrNull()

  // Active subtitle cue
  val activeSubtitle = subtitleCues.firstOrNull {
    currentTimeMs >= it.startTimeMs && currentTimeMs <= it.endTimeMs
  }?.text ?: activeScene?.dialogueText?.take(60) ?: ""

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Interactive Video Player Viewport Preview
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color.Black),
      border = androidx.compose.foundation.BorderStroke(2.dp, StudioRed.copy(alpha = 0.5f)),
      modifier = Modifier
        .fillMaxWidth()
        .height(220.dp)
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        // Simulated Ken Burns Camera Viewport
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
          ) {
            Box(
              modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(DarkSurfaceElevated),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.VideoLibrary,
                contentDescription = null,
                tint = StudioRed,
                modifier = Modifier.size(36.dp)
              )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = activeScene?.title ?: "Montaj Prevyusi",
              color = TextPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Text(
              text = "Ken Burns Dynamic Zoom & Pan",
              color = AccentCyan,
              fontSize = 10.sp
            )
          }
        }

        // Subtitle Overlay (YouTube Shorts / Modern dynamic captions)
        Box(
          contentAlignment = Alignment.BottomCenter,
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
        ) {
          if (activeSubtitle.isNotBlank()) {
            Surface(
              color = Color.Black.copy(alpha = 0.75f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.padding(horizontal = 8.dp)
            ) {
              Text(
                text = activeSubtitle,
                color = AccentGold,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }
        }
      }
    }

    // Playback Controls & Progress Bar
    Surface(
      color = DarkSurface,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = { viewModel.togglePreviewPlayback() },
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(StudioRed)
          ) {
            Icon(
              imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = null,
              tint = Color.White
            )
          }

          val currentMinutes = currentSec / 60
          val currentSeconds = currentSec % 60
          val totalMinutes = totalSeconds / 60
          val totalSecs = totalSeconds % 60

          Text(
            text = String.format("%02d:%02d / %02d:%02d", currentMinutes, currentSeconds, totalMinutes, totalSecs),
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }

        Slider(
          value = if (totalMs > 0) (currentTimeMs.toFloat() / totalMs) else 0f,
          onValueChange = { frac -> viewModel.seekPreviewTo((frac * totalMs).toLong()) },
          colors = SliderDefaults.colors(
            thumbColor = StudioRed,
            activeTrackColor = StudioRed,
            inactiveTrackColor = DarkSurfaceBorder
          )
        )
      }
    }

    // Visual Timeline Track Ruler
    Text("Vaqt Paneli va Sahnalar Bloklari (Qo'lda moslash)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      scenes.forEach { scene ->
        val isActive = scene.sceneNumber == activeScene?.sceneNumber
        Card(
          shape = RoundedCornerShape(8.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isActive) StudioRed else DarkSurfaceElevated
          ),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isActive) Color.White else DarkSurfaceBorder
          ),
          modifier = Modifier
            .width((scene.durationSeconds * 7).dp.coerceIn(80.dp, 200.dp))
            .clickable { viewModel.seekPreviewTo(scene.startTimeSeconds * 1000L) }
        ) {
          Column(modifier = Modifier.padding(8.dp)) {
            Text(
              text = String.format("%03d", scene.sceneNumber),
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp
            )
            Text(
              text = "${scene.durationSeconds}s",
              color = Color.White.copy(alpha = 0.8f),
              fontSize = 10.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              IconButton(
                onClick = { viewModel.updateSceneDuration(scene.sceneNumber, -1) },
                modifier = Modifier.size(20.dp)
              ) {
                Text("-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
              IconButton(
                onClick = { viewModel.updateSceneDuration(scene.sceneNumber, 1) },
                modifier = Modifier.size(20.dp)
              ) {
                Text("+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
              }
            }
          }
        }
      }
    }

    // Background Music Track Selector
    Card(
      colors = CardDefaults.cardColors(containerColor = DarkSurface),
      border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
      shape = RoundedCornerShape(12.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.GraphicEq, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Fon Musiqasi va Ambiyans", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        val tracks = listOf("Dramatik Kino Foni", "Qorong'u Horror Ambiyans", "Tarixiy Epik", "Lofi Falsafa", "Biznes Dinamik")
        tracks.forEach { track ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { viewModel.setMusicTrack(track) }
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = selectedMusic == track,
              onClick = { viewModel.setMusicTrack(track) },
              colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(track, color = TextPrimary, fontSize = 13.sp)
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// STEP 6: SEO, THUMBNAIL & EXPORT
// -------------------------------------------------------------
@Composable
fun Step6SeoExportView(
  viewModel: TubeCreatorViewModel,
  template: Template
) {
  val seoTitle by viewModel.seoTitle.collectAsState()
  val seoDesc by viewModel.seoDescription.collectAsState()
  val seoTags by viewModel.seoTags.collectAsState()
  val thumbnails by viewModel.thumbnailConcepts.collectAsState()
  val exportMessage by viewModel.exportStatusMessage.collectAsState()
  val clipboardManager = LocalClipboardManager.current
  val context = LocalContext.current

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    // Export Package Button
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioRed),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("Tayyor Videoni Eksport Qilish", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Text("SRT subtitr, EDL montaj kodi, toza skript va SEO", color = TextSecondary, fontSize = 12.sp)
            }
            Button(
              onClick = { viewModel.exportProject() },
              colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
              modifier = Modifier.testTag("export_project_button")
            ) {
              Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Yuklab Olish", fontWeight = FontWeight.Bold)
            }
          }

          if (exportMessage != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              color = AccentEmerald.copy(alpha = 0.15f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = exportMessage ?: "",
                color = AccentEmerald,
                fontSize = 12.sp,
                modifier = Modifier.padding(8.dp)
              )
            }
          }
        }
      }
    }

    // 3 Distinct Thumbnails
    item {
      Text("3 Xil Uslubdagi Thumbnail Konseptlari", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
      Spacer(modifier = Modifier.height(4.dp))
      Text("Qisqa matn va yuqori kontrast (YouTube CTR +40%):", color = TextSecondary, fontSize = 12.sp)
    }

    items(thumbnails) { concept ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(concept.styleName, color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            InfoPill(text = "Yuqori CTR")
          }

          Spacer(modifier = Modifier.height(10.dp))
          // Thumbnail Visual Preview Mockup
          Surface(
            color = Color.Black,
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(2.dp, StudioRed.copy(alpha = 0.5f)),
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp)
          ) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier.fillMaxSize()
            ) {
              Text(
                text = concept.headline,
                color = AccentGold,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(8.dp)
              )
              // YouTube badge
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .align(Alignment.BottomEnd)
                  .padding(6.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(Color.Black.copy(alpha = 0.8f))
                  .padding(horizontal = 4.dp, vertical = 2.dp)
              ) {
                Text("08:24", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text("🎨 Vizual Prompt:", color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Text(concept.visualPrompt, color = TextPrimary, fontSize = 12.sp)

          Spacer(modifier = Modifier.height(4.dp))
          Text("💡 Sabab: ${concept.rationale}", color = TextSecondary, fontSize = 11.sp)
        }
      }
    }

    // SEO Title
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("YouTube SEO Sarlavha (Title)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(
              onClick = {
                clipboardManager.setText(AnnotatedString(seoTitle))
                Toast.makeText(context, "Sarlavha nusxalandi!", Toast.LENGTH_SHORT).show()
              },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
            }
          }
          Text(seoTitle, color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }
    }

    // SEO Description
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("YouTube Tavsif & Timecode'lar", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(
              onClick = {
                clipboardManager.setText(AnnotatedString(seoDesc))
                Toast.makeText(context, "Tavsif nusxalandi!", Toast.LENGTH_SHORT).show()
              },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
            }
          }
          Text(
            text = seoDesc,
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 16.sp
          )
        }
      }
    }

    // SEO Tags
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("SEO Taglar (Kalit so'zlar)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(
              onClick = {
                clipboardManager.setText(AnnotatedString(seoTags))
                Toast.makeText(context, "Taglar nusxalandi!", Toast.LENGTH_SHORT).show()
              },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
            }
          }
          Text(
            text = seoTags,
            color = TextPrimary,
            fontSize = 12.sp,
            lineHeight = 16.sp
          )
        }
      }
    }
  }
}
