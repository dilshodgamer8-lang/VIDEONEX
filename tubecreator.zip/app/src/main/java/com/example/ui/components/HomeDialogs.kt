package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Template
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StudioRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AddTemplateDialog(
  onDismiss: () -> Unit,
  onSave: (Template) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Tarix") }
  var description by remember { mutableStateOf("") }
  var imageStylePrompt by remember { mutableStateOf("") }
  var scriptTone by remember { mutableStateOf("") }
  var montageEffect by remember { mutableStateOf("") }
  var aspectRatio by remember { mutableStateOf("16:9") }
  var durationMinutes by remember { mutableIntStateOf(8) }
  var language by remember { mutableStateOf("O'zbekcha") }
  var isSourceRequired by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = DarkSurface,
    title = {
      Text(
        text = "Yangi Yo'nalish Shablonini Qo'shish",
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
      ) {
        Text("Shablon Nomi", color = TextSecondary, fontSize = 12.sp)
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          placeholder = { Text("Masalan: Kiberxavfsizlik va Xakerlar") },
          modifier = Modifier.fillMaxWidth().testTag("template_title_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Kategoriya", color = TextSecondary, fontSize = 12.sp)
        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Qisqa Tavsif", color = TextSecondary, fontSize = 12.sp)
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          placeholder = { Text("Yo'nalish haqida qisqacha...") },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Rasm Uslubi Bloki (Promptlarga avtomatik qo'shiladi)", color = AccentGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
          value = imageStylePrompt,
          onValueChange = { imageStylePrompt = it },
          placeholder = { Text("Cyberpunk neon lighting, dark terminal green, matrix code atmosphere, photorealistic 8k render...") },
          modifier = Modifier.fillMaxWidth(),
          maxLines = 3,
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Senariy Ohangi", color = TextSecondary, fontSize = 12.sp)
        OutlinedTextField(
          value = scriptTone,
          onValueChange = { scriptTone = it },
          placeholder = { Text("Dramatik, sirli, tezkor sur'atda...") },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Montaj Uslubi & Effektlar", color = TextSecondary, fontSize = 12.sp)
        OutlinedTextField(
          value = montageEffect,
          onValueChange = { montageEffect = it },
          placeholder = { Text("Glitch o'tishlar, sekin zoom, terminal kodi effekti") },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = StudioRed,
            unfocusedBorderColor = DarkSurfaceBorder
          )
        )

        Spacer(modifier = Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Checkbox(
            checked = isSourceRequired,
            onCheckedChange = { isSourceRequired = it },
            colors = CheckboxDefaults.colors(checkedColor = StudioRed)
          )
          Text(
            text = "Fakt qoidasi (Manba majburiy)",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("Format va Standart Til", color = TextSecondary, fontSize = 12.sp)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(
              selected = aspectRatio == "16:9",
              onClick = { aspectRatio = "16:9" },
              colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
            )
            Text("16:9", color = TextPrimary, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(8.dp))
            RadioButton(
              selected = aspectRatio == "9:16",
              onClick = { aspectRatio = "9:16" },
              colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
            )
            Text("9:16 (Shorts)", color = TextPrimary, fontSize = 13.sp)
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          RadioButton(
            selected = language == "O'zbekcha",
            onClick = { language = "O'zbekcha" },
            colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
          )
          Text("O'zbekcha", color = TextPrimary, fontSize = 13.sp)
          Spacer(modifier = Modifier.width(8.dp))
          RadioButton(
            selected = language == "English",
            onClick = { language = "English" },
            colors = RadioButtonDefaults.colors(selectedColor = StudioRed)
          )
          Text("English", color = TextPrimary, fontSize = 13.sp)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            val template = Template(
              id = "custom_${System.currentTimeMillis()}",
              title = title.trim(),
              description = description.ifBlank { "Foydalanuvchi maxsus shabloni" },
              category = category.ifBlank { "Maxsus" },
              aspectRatio = aspectRatio,
              defaultDurationMinutes = durationMinutes,
              language = language,
              imageStylePrompt = imageStylePrompt.ifBlank { "Cinematic high contrast 8k render" },
              scriptTone = scriptTone.ifBlank { "Dinamik va qiziqarli" },
              montageEffect = montageEffect.ifBlank { "Ken Burns zoom va crossfade" },
              isSourceRequired = isSourceRequired,
              isCustom = true,
              colorTag = "#FF2A42"
            )
            onSave(template)
            onDismiss()
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
        modifier = Modifier.testTag("save_custom_template_button")
      ) {
        Text("Saqlash", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
      ) {
        Text("Bekor qilish")
      }
    }
  )
}

@Composable
fun ImportExportDialog(
  exportJson: String,
  onImport: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var importText by remember { mutableStateOf("") }
  var activeTab by remember { mutableIntStateOf(0) } // 0: Export, 1: Import
  val clipboardManager = LocalClipboardManager.current
  val context = LocalContext.current

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = DarkSurface,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (activeTab == 0) "Shablonlarni Eksport Qilish" else "Shablonlarni Import Qilish",
          color = TextPrimary,
          fontWeight = FontWeight.Bold,
          fontSize = 17.sp
        )
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = { activeTab = 0 },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (activeTab == 0) StudioRed else DarkSurfaceElevated
            ),
            modifier = Modifier.weight(1f)
          ) {
            Text("Eksport (JSON)", fontSize = 12.sp)
          }
          Button(
            onClick = { activeTab = 1 },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (activeTab == 1) StudioRed else DarkSurfaceElevated
            ),
            modifier = Modifier.weight(1f)
          ) {
            Text("Import", fontSize = 12.sp)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (activeTab == 0) {
          Text(
            text = "Quyidagi JSON kod barcha 11 ta boshlang'ich va siz kiritgan shablonlarni o'z ichiga oladi. Boshqa qurilmaga o'tkazish uchun nusxalang:",
            color = TextSecondary,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            color = DarkBackground,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier
              .fillMaxWidth()
              .height(160.dp)
              .verticalScroll(rememberScrollState())
              .padding(8.dp)
          ) {
            Text(
              text = exportJson,
              color = AccentCyan,
              fontSize = 10.sp,
              fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = {
              clipboardManager.setText(AnnotatedString(exportJson))
              Toast.makeText(context, "JSON buferga nusxalandi!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
            Text("Nusxalash")
          }
        } else {
          Text(
            text = "Eksport qilingan JSON shablon kodini bu yerga joylashtiring:",
            color = TextSecondary,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = importText,
            onValueChange = { importText = it },
            placeholder = { Text("[{\"title\": \"...\"}]") },
            modifier = Modifier
              .fillMaxWidth()
              .height(160.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = StudioRed,
              unfocusedBorderColor = DarkSurfaceBorder
            )
          )
          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = {
              if (importText.isNotBlank()) {
                onImport(importText)
                onDismiss()
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = StudioRed),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
            Text("Import Qilish")
          }
        }
      }
    },
    confirmButton = {
      OutlinedButton(
        onClick = onDismiss,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
      ) {
        Text("Yopish")
      }
    }
  )
}

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = DarkSurface,
    icon = {
      Icon(Icons.Default.Info, contentDescription = null, tint = StudioRed)
    },
    title = {
      Text(
        text = "TubeCreator Studio",
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
      ) {
        Text(
          text = "Shaxsiy YouTube Video Yaratish Studiyasi",
          color = AccentGold,
          fontWeight = FontWeight.SemiBold,
          fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Ushbu ilova YouTube video yaratishning to'liq 6 bosqichli konveyerini bitta joyga jamlaydi:\n\n" +
            "1. Yo'nalish va Shablonlar (11 ta professional shablon)\n" +
            "2. Google API & Trend Mavzular (Faktlar va manbalar bilan)\n" +
            "3. Sahnalar Senariysi va Toza Ovoz Matni (Ovoz yozish vositasi)\n" +
            "4. Ketma-ket Rasm Promptlari (001, 002, 003... yagona uslubda)\n" +
            "5. Avtomatik Montaj & Vaqt Paneli (Subtitle, zoom/pan, sinxronizatsiya)\n" +
            "6. YouTube SEO & 3 xil Thumbnail (Yuqori CTR sarlavha, tavsif, teglar, eksport paketi)\n\n" +
            "Texnik ta'minot: Room Database, Gemini LLM AI Logic, Audio Montage Engine, SRT generator, JSON EDL.",
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = StudioRed)
      ) {
        Text("Tushunarli")
      }
    }
  )
}
