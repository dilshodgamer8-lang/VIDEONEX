package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.CreationFlowScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.TubeCreatorTheme
import com.example.ui.viewmodel.TubeCreatorViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      TubeCreatorTheme {
        val viewModel: TubeCreatorViewModel = viewModel()
        val currentScreen by viewModel.currentScreen.collectAsState()

        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .safeDrawingPadding()
        ) {
          when (currentScreen) {
            "home" -> HomeScreen(viewModel = viewModel)
            "creation" -> CreationFlowScreen(viewModel = viewModel)
            "projects" -> ProjectsScreen(viewModel = viewModel)
            "settings" -> SettingsScreen(viewModel = viewModel)
            else -> HomeScreen(viewModel = viewModel)
          }
        }
      }
    }
  }
}
