package com.example.data.repository

import com.example.data.local.ProjectDao
import com.example.data.model.Project
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {

  val allProjects: Flow<List<Project>> = projectDao.getAllProjects()

  suspend fun getProjectById(id: Long): Project? = projectDao.getProjectById(id)

  suspend fun saveProject(project: Project): Long = projectDao.insertProject(project)

  suspend fun updateProject(project: Project) = projectDao.updateProject(project)

  suspend fun deleteProject(project: Project) = projectDao.deleteProject(project)

  suspend fun deleteProjectById(id: Long) = projectDao.deleteProjectById(id)
}
