package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class SettingsPreferences(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("tube_creator_prefs", Context.MODE_PRIVATE)

  var googleApiKey: String
    get() = prefs.getString("google_api_key", "") ?: ""
    set(value) = prefs.edit().putString("google_api_key", value).apply()

  var geminiApiKey: String
    get() = prefs.getString("gemini_api_key", "") ?: ""
    set(value) = prefs.edit().putString("gemini_api_key", value).apply()

  var defaultLanguage: String
    get() = prefs.getString("default_language", "O'zbekcha") ?: "O'zbekcha"
    set(value) = prefs.edit().putString("default_language", value).apply()

  var defaultVideoQuality: String
    get() = prefs.getString("default_video_quality", "1080p Full HD") ?: "1080p Full HD"
    set(value) = prefs.edit().putString("default_video_quality", value).apply()

  var subtitleFontSize: Int
    get() = prefs.getInt("subtitle_font_size", 22)
    set(value) = prefs.edit().putInt("subtitle_font_size", value).apply()

  var subtitleStyle: String
    get() = prefs.getString("subtitle_style", "YouTube Shorts (Yellow Highlight)") ?: "YouTube Shorts (Yellow Highlight)"
    set(value) = prefs.edit().putString("subtitle_style", value).apply()
}
