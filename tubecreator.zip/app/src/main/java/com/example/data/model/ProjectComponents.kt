package com.example.data.model

data class ScriptScene(
  val sceneNumber: Int,
  val title: String,
  val visualDescription: String,
  val dialogueText: String,
  val factSource: String = "",
  val isSourceVerified: Boolean = false,
  var durationSeconds: Int = 15,
  val imagePrompt: String = "",
  var imageUri: String? = null,
  var startTimeSeconds: Int = 0
)

data class ThumbnailConcept(
  val id: Int,
  val styleName: String,
  val headline: String,
  val visualPrompt: String,
  val rationale: String,
  val colorPalette: String = "#FF0033"
)

data class TopicSuggestion(
  val id: Int,
  val title: String,
  val hook: String,
  val factualAngle: String,
  val targetAudience: String,
  val viralPotentialScore: Int = 92
)
