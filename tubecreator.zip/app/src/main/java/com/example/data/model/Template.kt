package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "templates")
data class Template(
  @PrimaryKey
  val id: String,
  val title: String,
  val description: String,
  val category: String,
  val aspectRatio: String, // "16:9" or "9:16"
  val defaultDurationMinutes: Int, // e.g. 8, 10, 15
  val language: String, // "O'zbekcha" or "English"
  val imageStylePrompt: String,
  val scriptTone: String,
  val montageEffect: String,
  val isSourceRequired: Boolean,
  val isCustom: Boolean = false,
  val colorTag: String = "#FF2A42",
  val iconName: String = "history"
) {
  companion object {
    val DEFAULT_TEMPLATES = listOf(
      Template(
        id = "tarixiy_pov",
        title = "Tarixiy POV \"Agar sen...?\"",
        description = "Tarixiy voqealarda oddiy inson o'rnida bo'lish, kuchli dramatizm va immersiv hissiyotlar.",
        category = "Tarix",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "O'zbekcha",
        imageStylePrompt = "Cinematic historical POV perspective, hyper-realistic, dramatic rim lighting, authentic period costume and atmosphere, photorealistic 8k texture, Unreal Engine 5 render style, cinematic depth of field",
        scriptTone = "Dramatik, shaxsiy murojaat, hayajonli, ikkinchi shaxs ('sen') orqali immersiv hikoya",
        montageEffect = "Sekin yaqinlashuv (Slow Ken Burns Zoom), dramatik qorayish (Dark Vignette), yurak urishi va shovqin effektlari",
        isSourceRequired = true,
        colorTag = "#E11D48",
        iconName = "history_edu"
      ),
      Template(
        id = "oversimplified_history",
        title = "Tarix, OverSimplified uslubida",
        description = "Xaritali, sodda chizma personajlar, kinoyali hazil va qiziqarli xalqaro munosabatlar.",
        category = "Tarix",
        aspectRatio = "16:9",
        defaultDurationMinutes = 10,
        language = "English",
        imageStylePrompt = "OverSimplified art style, 2D vector flat animation, vibrant vintage parchment map in background, expressive minimalist cartoon stick characters with round eyes, clean bold black outlines, playful saturated colors",
        scriptTone = "Sarcastic, humorous, witty, fast-paced educational breakdown with funny commentary",
        montageEffect = "Dynamic map pan and zoom, paper unfold effect, cartoon pop-in character transitions",
        isSourceRequired = true,
        colorTag = "#F59E0B",
        iconName = "map"
      ),
      Template(
        id = "horror_hikoyalar",
        title = "Horror hikoyalar (Real voqealar)",
        description = "Haqiqiy voqealarga asoslangan, sirli va qorong'u psixologik qo'rquv.",
        category = "Horror",
        aspectRatio = "16:9",
        defaultDurationMinutes = 15,
        language = "English",
        imageStylePrompt = "Dark eerie true crime noir aesthetic, desaturated moody cold tones, grain, flashlight beam illumination in mist, silhouette shadows, realistic analog 35mm film texture, spine-chilling unsettling atmosphere",
        scriptTone = "Sirli, sekin shivirlash ohangi, keskin burilishlar, psixologik bosim va faktlarga tayangan",
        montageEffect = "Film grain, subtle camera jitter, glitch flash transitions, ominous dark fade",
        isSourceRequired = false,
        colorTag = "#7C3AED",
        iconName = "nights_stay"
      ),
      Template(
        id = "jamiyat_psixologiyasi",
        title = "Jamiyat psixologiyasi",
        description = "Qora fonda oq chizma uslubi, inson xatti-harakati va manipulyatsiyalar tahlili.",
        category = "Psixologiya",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "English",
        imageStylePrompt = "Dark chalkboard background, glowing chalk-white sketch line-art, psychological diagram metaphors, brain neural connections and human silhouette schematics, minimalist neo-noir aesthetic",
        scriptTone = "Intellektual, chuqur tahliliy, faktlarga asoslangan, ko'zni ochuvchi provokatsion savollar",
        montageEffect = "Chalk drawing reveal, neon line wipe, clean smooth slide transition",
        isSourceRequired = false,
        colorTag = "#06B6D4",
        iconName = "psychology"
      ),
      Template(
        id = "biznes_va_finance",
        title = "Biznes va Finance (Haqiqiy raqamlar)",
        description = "Tannarx, marja, investorlar siri, yashirin daromadlar va real korporativ raqamlar.",
        category = "Biznes",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "English",
        imageStylePrompt = "Modern Bloomberg-style financial graphics, 3D floating isometric bar charts, currency symbols, sleek matte dark graphite background with neon green and golden ticker highlights, clean typography",
        scriptTone = "Aniq, tahliliy, hayratlanarli raqamlar, marja va biznes fokusli",
        montageEffect = "Kinetic chart growth animation, fast zoom into numbers, split-screen balance comparison",
        isSourceRequired = true,
        colorTag = "#10B981",
        iconName = "trending_up"
      ),
      Template(
        id = "tibbiyot_salomatlik",
        title = "Tibbiyot va salomatlik (Pixar 3D)",
        description = "Pixar uslubidagi yoqimli 3D anatomiya, inson tanasining ichki sirlari va biologiya.",
        category = "Tibbiyot",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "O'zbekcha",
        imageStylePrompt = "Pixar and Disney animation studio style, cute 3D anthropomorphic red blood cells and microscopic human organs, warm subsurface scattering glow, vibrant friendly colorful lighting, high octane 3D render, glossy cartoon anatomical model",
        scriptTone = "Do'stona, sodda tilda murakkab tushunchalar, qiziqarli metaforalar, ishonchli tibbiy faktlar",
        montageEffect = "Soft bouncy 3D zoom, micro-to-macro camera swoop, playful sound cues",
        isSourceRequired = true,
        colorTag = "#EC4899",
        iconName = "medical_services"
      ),
      Template(
        id = "tarixdagi_galati_ishlar",
        title = "Tarixdagi g'alati ishlar (Qora hazil)",
        description = "Tarixdagi eng bema'ni, kulgili va aql bovar qilmas xatolar, qora hazil bilan.",
        category = "Tarix",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "English",
        imageStylePrompt = "Absurd Monty Python collage style mixed with Victorian woodcut engravings, whimsical surrealism, retro newspaper sepia tones, humorous exaggerated facial expressions, eccentric vintage aesthetic",
        scriptTone = "Bema'ni, istehzoli, qora hazilga boy, dinamik kulgili faktlar",
        montageEffect = "Cutout paper sliding, rapid comedy snap zoom, retro vignette flicker",
        isSourceRequired = true,
        colorTag = "#F97316",
        iconName = "theater_comedy"
      ),
      Template(
        id = "wojak_doomer",
        title = "Wojak Doomer (Hayot, pul, jamiyat)",
        description = "Wojak qahramonlari, lo-fi shahar kayfiyati, zamonaviy avlod muammolari va umid.",
        category = "Madaniyat",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "English",
        imageStylePrompt = "Authentic Wojak / Doomer meme art aesthetic, 2D illustrative linework, melancholic midnight urban cityscape, neon gas station lighting, lo-fi rainy aesthetic, cigarette smoke and deep existential mood",
        scriptTone = "Samimiy, bir oz g'amgin, chuqur falsafiy, zamonaviy jamiyat haqiqatlari",
        montageEffect = "Slow rain overlay, lo-fi color grade, subtle breathing zoom, melancholic crossfade",
        isSourceRequired = false,
        colorTag = "#64748B",
        iconName = "sentiment_very_dissatisfied"
      ),
      Template(
        id = "qadimgi_odamlar",
        title = "Qadimgi odamlar (Kulgili ibtidoiy hayot)",
        description = "Tosh davridagi ajdodlarimizning kulgili, qiyin va xavfli kundalik hayoti.",
        category = "Animatsiya",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "English",
        imageStylePrompt = "Funny prehistoric caveman cartoon style, stylized Flintstones meets Primal aesthetics, exaggerated stone tools and mammoth encounters, warm campfire glow and lush primitive savanna jungle colors",
        scriptTone = "Kulgili, baquvvat, qiziqarli taqqoslashlar (biz va ular), sarguzashtli",
        montageEffect = "Cave wall rock texture transitions, comedic rock thud shakes, energetic zoom",
        isSourceRequired = false,
        colorTag = "#D97706",
        iconName = "terrain"
      ),
      Template(
        id = "brendlar_korporatsiyalar",
        title = "Brendlar va korporatsiyalar (\"Built On You\")",
        description = "Gigant brendlar tarixi, sahna ortidagi janglar, monopoliyalar va dramatik yuksalish.",
        category = "Hujjatli",
        aspectRatio = "16:9",
        defaultDurationMinutes = 18,
        language = "English",
        imageStylePrompt = "High-end corporate documentary aesthetic, glossy dark glass boardroom reflections, dramatic silhouettes of executives, vintage archival corporate logos, premium magazine editorial lighting, 8k resolution",
        scriptTone = "Hujjatli film uslubi, dramatik rivojlanish, intriqa, muvaffaqiyat va inqiroz",
        montageEffect = "Documentary pan and scan (Ken Burns), vintage film scratch, cinematic wide letterbox bars",
        isSourceRequired = true,
        colorTag = "#3B82F6",
        iconName = "corporate_fare"
      ),
      Template(
        id = "inson_ongi_falsafa",
        title = "Inson ongi va falsafa (Minimalizm)",
        description = "Minimalist uslub, ong, vaqt va stoitsizm haqida chuqur xulosalar.",
        category = "Falsafa",
        aspectRatio = "16:9",
        defaultDurationMinutes = 8,
        language = "English",
        imageStylePrompt = "Ultra-minimalist Zen brutalist composition, stark geometric marble monoliths, tranquil water reflections, atmospheric golden hour ambient haze, high contrast negative space, sophisticated monochrome with warm amber accents",
        scriptTone = "Xotirjam, mulohazali, chuqur donishmandlik, meditativ va kuchli xulosalar",
        montageEffect = "Very slow majestic zoom, ethereal dissolve crossfades, subtle light beam drift",
        isSourceRequired = false,
        colorTag = "#A855F7",
        iconName = "self_improvement"
      )
    )
  }
}
