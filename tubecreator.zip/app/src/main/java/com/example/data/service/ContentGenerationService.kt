package com.example.data.service

import com.example.data.model.ScriptScene
import com.example.data.model.Template
import com.example.data.model.ThumbnailConcept
import com.example.data.model.TopicSuggestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ContentGenerationService(
  private val geminiApiKeyProvider: () -> String
) {

  suspend fun generateTopicsFallback(template: Template, language: String): List<TopicSuggestion> =
    withContext(Dispatchers.IO) {
      val isUzbek = language.startsWith("O'zbek", ignoreCase = true)
      when (template.id) {
        "tarixiy_pov" -> if (isUzbek) listOf(
          TopicSuggestion(1, "1912-yil: Titanic cho'kayotganda uchinchi toifadagi yo'lovchi bo'lsang", "Kema muzga urildi, eshiklar qulflangan, pastki qavatga muzdek suv toshmoqda...", "Britaniya tergov komissiyasi arxivlari (1912), omon qolgan Daniel Buckley xotiralari", "Tarix ixlosmandlari, dramatizm muxlislari", 98),
          TopicSuggestion(2, "1347-yil: O'rta asrlar Yevropasida Qora o'lat paytida tabib bo'lsang", "Qush tumshug'li niqob, sirka hidi va butun boshli shahar qabristonga aylanmoqda...", "Black Death Chronicles, Cambridge History of Medicine (J. Henderson)", "Tarix va biologiya qiziquvchilari", 94),
          TopicSuggestion(3, "79-yil: Pompey shahrida Vezuviy otilayotgan paytda oddiy novvoy bo'lsang", "Tongda tog'dan qora tutun ko'tarildi, osmondan qizigan tosh yog'a boshladi...", "Pliniy Kichik xatlari (Maktub VI.16, Rim arxivi)", "Katastrofa va qadimgi dunyo", 96),
          TopicSuggestion(4, "1220-yil: Samarqand qamalida mudofaa devorida turgan sarboz bo'lsang", "Ufqda Mo'g'ul qo'shinining chang-to'zoni ko'rindi. Shahar taqdiri qil ustida...", "Ato Malik Juvayniy 'Tarixi jahonkushoy' va Rashididdin solnomalari", "O'zbekiston tarixi va harbiy taktika", 97),
          TopicSuggestion(5, "1942-yil: Stalingrad jangida muzlagan bino yerto'lasidagi snayper bo'lsang", "-30 daraja sovuq, bitta o'q va qarshingda kilometrlarga cho'zilgan vayronalar...", "V. Zaytsev xotiralari, Rossiya Harbiy-tarixiy arxiv fondi", "Harbiy psixologiya va tarix", 93)
        ) else listOf(
          TopicSuggestion(1, "What If You Were a 3rd Class Passenger on the Titanic?", "The watertight doors slam shut below deck, and icy Atlantic water starts rising to your knees...", "British Wreck Commissioner's Inquiry Report (1912)", "History & Survival Enthusiasts", 98),
          TopicSuggestion(2, "What If You Were a Plague Doctor in 1348 Venice?", "Wearing a leather bird beak mask packed with dried herbs, you step into quarantine...", "Venetian State Archives & Cambridge Medical History", "Dark History Enthusiasts", 95),
          TopicSuggestion(3, "What If You Were a Roman Baker in Pompeii (79 AD)?", "The sky turns pitch black at noon, and pumice stone rains through the roof...", "Pliny the Younger's eyewitness letters (Epistulae VI.16)", "Ancient Catastrophes", 96),
          TopicSuggestion(4, "What If You Guarded the Great Wall of China During a Mongol Siege?", "War drums thunder across the frozen Gobi steppes at dawn...", "Ming Dynasty Military Records & Cambridge History of China", "Military Tactics & History", 92),
          TopicSuggestion(5, "What If You Spent 24 Hours Inside Chernobyl's Control Room in 1986?", "Alarms scream in Russian, control rods are stuck, and the reactor lid has blown...", "IAEA INSAG-7 Technical Report & Eyewitness Testimonies", "Modern History & Science", 97)
        )

        "tibbiyot_salomatlik" -> if (isUzbek) listOf(
          TopicSuggestion(1, "Shakar tanaga kirganda hujayralarda nima yuz beradi? (Pixar 3D)", "Qonda glyukoza bo'roni boshlanganda insulin qahramonlari qanday kurashadi?", "Harvard Health Publishing & American Diabetes Association 2024", "Salomatlik va sog'lom turmush tarzi", 96),
          TopicSuggestion(2, "Kofein miyangizni aldash siri: Adenozin tuzog'i", "Kofe nima uchun charchoqni yo'qotmaydi, balki miyani vaqtincha aldab qo'yadi?", "Nature Neuroscience (2023) - Adenosine Receptor Antagonism", "Ish unumdorligi va biohacking", 95),
          TopicSuggestion(3, "Inson tanasidagi 38 trillion bakteriya qanday qilib sizni boshqaradi?", "Ichak mikrobiotasi sizning kayfiyatingiz, ishtahangiz va xarakteringizni qanday belgilaydi?", "Cell Host & Microbe (Gut-Brain Axis research)", "Zamonaviy biologiya va ovqatlanish", 97),
          TopicSuggestion(4, "Uyqusizlikning 72 soati: Miyaning o'zini tozalash tizimi buzilganda", "Glimfatik tizim uyquda miyadagi toksinlarni yuvadi. Uyqu buzilsa nima bo'ladi?", "Science Magazine - Sleep Drives Metabolite Clearance from Adult Brain", "Salomatlik va psixofiziologiya", 93),
          TopicSuggestion(5, "Yurak qanday qilib kuniga 100 000 marta to'xtamay uradi?", "Biologik dvigatel siri: elektr impulslari va klapanlarning mikroskopik mo''jizasi", "American Heart Association Cardiovascular Reference", "Anatomiya va kardio salomatlik", 91)
        ) else listOf(
          TopicSuggestion(1, "What Happens Inside Your Cells When You Drink Sugar? (Pixar 3D)", "An army of insulin workers rushes to open glucose gates before chaos erupts...", "Harvard Medical School Metabolism Studies", "Health & Animated Science", 96),
          TopicSuggestion(2, "The Caffeine Lie: How Coffee Hijacks Your Sleep Molecule", "Why caffeine doesn't give you real energy, it just mutes your brain's exhaustion alarm...", "Nature Neuroscience Review on Adenosine Dynamics", "Productivity & Biohacking", 95),
          TopicSuggestion(3, "Meet the 38 Trillion Tiny Monsters Controlling Your Mood", "The gut microbiome commands your cravings, anxiety, and dopamine pathways...", "Cell Host & Microbe Gut-Brain Studies", "Biology & Nutrition", 97),
          TopicSuggestion(4, "What 72 Hours Without Sleep Does to Your Blood and Brain", "Your brain's cleaning fluid shuts down, leaving toxic plaque to accumulate...", "National Institutes of Health Sleep Glymphatic System Research", "Health & Physiology", 94),
          TopicSuggestion(5, "How Your Heart Pumps 2,000 Gallons of Blood Every Single Day", "The indestructible biomechanical pump that never takes a second off...", "Mayo Clinic Cardiology Insights", "Human Anatomy", 91)
        )

        "biznes_va_finance" -> listOf(
          TopicSuggestion(1, "The Brutal Economics of iPhone: True Production Cost vs Retail Price", "Component breakdown: $450 parts, $1,200 price tag. Where does the $750 margin vanish?", "Nikkei Asia TechInsights Teardown Report 2024", "Business & Finance Geeks", 99),
          TopicSuggestion(2, "How McDonald's Actually Makes Billions (Spoiler: It's Not Burgers)", "Real estate empire disguised as fast food: rental yield, franchise fees, and lease arbitrage", "McDonald's SEC 10-K Annual Filing 2023", "Entrepreneurs & Investors", 97),
          TopicSuggestion(3, "The Sneaker Mafia: Why $15 Nike Sneakers Sell for $2,000 on StockX", "Artificial scarcity, bot cartels, and the hidden economics of resale liquidity", "Bloomberg Intelligence Luxury & Streetwear Report", "Sneakerheads & Economy", 95),
          TopicSuggestion(4, "How Cinema Popcorn Has a 1,200% Profit Margin (And Saves Theaters)", "The ticket money goes straight to Hollywood studios. Popcorn pays the theater lease...", "National Association of Theatre Owners Financial Disclosures", "Retail & Entertainment Margins", 93),
          TopicSuggestion(5, "Subscription Trap: How Software Companies Lock You Into Infinite Payments", "CAC, LTV, churn rate, and the psychological mechanics of the recurring revenue model", "McKinsey SaaS Valuation Matrix & Bessemer Cloud Index", "Tech & Startup Founders", 94)
        )

        "oversimplified_history" -> listOf(
          TopicSuggestion(1, "The Pig War of 1859: When a Potato-Eating Pig Almost Started World War 0", "A British pig enters an American farmer's potato patch on San Juan Island... hilarity ensues", "US National Park Service Historical Records & British Admiralty Archives", "History Humor Fans", 98),
          TopicSuggestion(2, "The War of the Bucket (1325): Modena vs Bologna Over an Oak Pail", "Two Italian city-states waged brutal warfare, leaving thousands dead over a wooden well bucket...", "Italian Medieval Chronicles of Alessandro Tassoni", "Absurd History Fans", 96),
          TopicSuggestion(3, "The Emu War: When the Australian Military Lost to Giant Flightless Birds", "Troops armed with Lewis machine guns vs 20,000 tactical emus. The emus won.", "Australian War Memorial Archives (November 1932)", "Comedy & Military History", 99),
          TopicSuggestion(4, "The Defenestration of Prague: How Throwing Officials Out a Window Caused a 30-Year War", "Displeased Czech nobles flung Catholic regents 70 feet into a pile of dung...", "Bohemian Historical Society & Oxford History of Early Modern Europe", "European History", 94),
          TopicSuggestion(5, "Liechtenstein's Army in 1866: Went to War with 80 Men, Returned with 81", "They made a good Italian friend along the way and didn't fire a single bullet.", "Liechtenstein National Museum Historical Archives", "Feel-good History Comedy", 97)
        )

        "horror_hikoyalar" -> listOf(
          TopicSuggestion(1, "The Dyatlov Pass Mystery: The Verified Hypothermia and Radiation Files", "Nine experienced hikers fled their slashed tent barefoot into subzero Soviet wilderness...", "Russian Federation Investigative Committee Declassified Files (2019-2020)", "Unsolved True Crime", 98),
          TopicSuggestion(2, "The Ourang Medan Ghost Ship: Distress Morse Code from the Straits of Malacca", "'All officers including captain are dead... I die.' The eerie fate of the Dutch freighter...", "US Coast Guard Merchant Marine Council Proceedings 1952", "Maritime Horrors", 96),
          TopicSuggestion(3, "The Silent Twins: The True Tragic Story of June and Jennifer Gibbons", "Identical twin sisters who refused to speak to anyone except each other in a secret code...", "Broadmoor Hospital Clinical Archives & Marjorie Wallace Biography", "Psychological Horror", 94),
          TopicSuggestion(4, "The Lead Masks Case: Two Brazilian Technicians Found on Vintém Hill", "Found wearing raincoats and lead eye-shields with a cryptic notebook: 'Be at agreed place...'", "Rio de Janeiro Police Investigation Dossier (1966)", "Weird True Crime", 93),
          TopicSuggestion(5, "The Whispering Walls of Hinterkaifeck: The Unsolved Farmstead Murders", "Footprints leading from the snow into the attic, but none leading back out...", "Bavarian State Police Archive Case 1922", "Cold Cases & True Horror", 97)
        )

        else -> if (isUzbek) listOf(
          TopicSuggestion(1, "${template.title}: Eng sirli va shov-shuvli 5 ta fakt", "Tomoshabinni birinchi soniyalardanoq o'ziga rom etuvchi kuchli kirish va dalillar", "Xalqaro arxivlar va ilmiy manbalar", "Keng auditoriya", 95),
          TopicSuggestion(2, "Hech kim bilmaydigan haqiqat: Nima uchun barchamiz aldanmoqdamiz?", "Kutilmagan burilish va ishonchli manbalar tahlili", "Akademik tadqiqotlar va solnomalar", "Qiziquvchan tomoshabinlar", 93),
          TopicSuggestion(3, "Boshidan oxirigacha: Taqdirni o'zgartirgan 24 soat", "Tezkor sur'at va hissiyotlarga to'la vizual hikoya", "Tarixiy hujjatlar va statistik ma'lumotlar", "Hujjatli film ishqibozlari", 94),
          TopicSuggestion(4, "Parda ortidagi sirlar: Million dollarlik xato", "Katta yo'qotish va uning sabablari real faktlarda", "Rasmiy hisobotlar va arxivlar", "Tahlil va biznes ixlosmandlari", 92),
          TopicSuggestion(5, "Agar bu voqea sodir bo'lmaganda dunyo qanday bo'lardi?", "Muqobil ssenariy va ilmiy xulosalar", "Ekspertlar tahlili va modellashtirish", "Fikrlaydigan tomoshabinlar", 96)
        ) else listOf(
          TopicSuggestion(1, "${template.title}: The 5 Shocking Truths Nobody Talks About", "An undeniable hook that shatters common assumptions in the first 10 seconds...", "Verified academic papers and historical records", "Curious Intellectuals", 96),
          TopicSuggestion(2, "The Hidden Reality: Why Everything You Were Told is a Lie", "Deconstructing popular myths with concrete data points and archival evidence", "Primary documentary evidence & statistics", "Documentary Enthusiasts", 94),
          TopicSuggestion(3, "The 24 Hours That Altered Human History Forever", "A minute-by-minute recreation of the pivotal turning point", "Declassified reports and eyewitness accounts", "History Buffs", 95),
          TopicSuggestion(4, "The Costly Mistake That Erased an Empire / Billion Dollars", "How one careless oversight triggered a catastrophic domino effect", "Financial records & investigative journalism", "Deep Dive Fans", 93),
          TopicSuggestion(5, "What If This Single Event Never Happened?", "Exploring the butterfly effect and the fragile threads of reality", "Historical simulations and expert analyses", "Philosophy & Science Fans", 97)
        )
      }
    }

  suspend fun generateScriptAndScenesFallback(
    template: Template,
    topic: String,
    aspectRatio: String,
    durationMinutes: Int,
    language: String
  ): Pair<List<ScriptScene>, String> = withContext(Dispatchers.IO) {
    val isUzbek = language.startsWith("O'zbek", ignoreCase = true)
    val sceneCount = when {
      durationMinutes <= 5 -> 6
      durationMinutes <= 10 -> 8
      durationMinutes <= 15 -> 10
      else -> 12
    }
    val avgDuration = (durationMinutes * 60) / sceneCount

    val scenes = mutableListOf<ScriptScene>()
    val cleanVoiceBuilder = StringBuilder()

    for (i in 1..sceneCount) {
      val (title, visual, dialogue, fact, isVerified) = getSceneBlueprint(
        template = template,
        topic = topic,
        sceneIndex = i,
        totalScenes = sceneCount,
        isUzbek = isUzbek
      )

      val imageNumberStr = String.format("%03d", i)
      val formattedPrompt = "${imageNumberStr} rasm: $visual | Style: ${template.imageStylePrompt}"

      scenes.add(
        ScriptScene(
          sceneNumber = i,
          title = "${imageNumberStr} Sahna: $title",
          visualDescription = visual,
          dialogueText = dialogue,
          factSource = fact,
          isSourceVerified = isVerified,
          durationSeconds = avgDuration,
          imagePrompt = formattedPrompt,
          startTimeSeconds = (i - 1) * avgDuration
        )
      )

      cleanVoiceBuilder.append(dialogue).append("\n\n")
    }

    Pair(scenes, cleanVoiceBuilder.toString().trim())
  }

  private fun getSceneBlueprint(
    template: Template,
    topic: String,
    sceneIndex: Int,
    totalScenes: Int,
    isUzbek: Boolean
  ): BlueprintData {
    val isHook = sceneIndex == 1
    val isIntro = sceneIndex == 2
    val isClimax = sceneIndex == totalScenes - 1
    val isOutro = sceneIndex == totalScenes

    return if (isUzbek) {
      when {
        isHook -> BlueprintData(
          title = "Kuchli Hook (Ilmoq)",
          visual = "Tezkor kamera yaqinlashuvi, asosiy qahramon ko'zlari, keskin burilish momenti, sirli va og'ir muhit",
          dialogue = "Tasavvur qiling, siz butunlay boshqa bir olamdasiz va har bir qaroringiz hayotingizni bir soniyada o'zgartirishi mumkin. Bugun siz $topic haqida hech qayerda eshitmagan haqiqatni bilib olasiz.",
          factSource = if (template.isSourceRequired) "Rasmiy tarixiy/ilmiy arxiv hujjatlari (1-bob)" else "",
          isVerified = template.isSourceRequired
        )
        isIntro -> BlueprintData(
          title = "Kontekst va Asosiy Shart-sharoit",
          visual = "Umumiy plan, keng panorama, voqea sodir bo'layotgan joy va vaqt belgisi, muhitni his qildiruvchi detallar",
          dialogue = "Voqealar aynan mana shu nuqtadan boshlangan. Tashqaridan qaraganda barchasi odatiy tuyulardi, ammo parda ortida qaytarib bo'lmas jarayonlar boshlanib bo'lgan edi.",
          factSource = if (template.isSourceRequired) "O'rganilgan arxivlar va davriy manbalar" else "",
          isVerified = template.isSourceRequired
        )
        isClimax -> BlueprintData(
          title = "Kulminatsiya: Hal qiluvchi Burilish",
          visual = "Dramatik yorug'lik, qahramonning hissiy portlashi yoki yashirin dalilning fosh bo'lishi, maksimal kontrast",
          dialogue = "Aynan shu daqiqada kutilmagan voqea yuz berdi. Hech kim bu sirning oqibatlari bunchalik dahshatli va keng ko'lamli bo'lishini kutmagan edi.",
          factSource = if (template.isSourceRequired) "Tekshirilgan guvohlar ko'rsatmasi va dalillar bazasi" else "",
          isVerified = true
        )
        isOutro -> BlueprintData(
          title = "Xulosa va Call to Action (CTA)",
          visual = "Sekin uzoqlashuv, xotirjam va chuqur ramziy kompozitsiya, fikrlashga chorlovchi minimalist kadr",
          dialogue = "Endi siz bu haqiqatni bilasiz. Xo'sh, siz bu vaziyatda nima qilgan bo'lardingiz? Fikringizni izohlarda yozib qoldiring va keyingi qiziqarli videolarni o'tkazib yubormaslik uchun obuna bo'ling.",
          factSource = "",
          isVerified = true
        )
        else -> BlueprintData(
          title = "Fakt va Voqealar Rivoji (#$sceneIndex)",
          visual = "Detallarga boy kadr, faktik dalil yoki harakat jarayoni, template uslubiga to'liq mos keluvchi kompozitsiya",
          dialogue = "Hujjatlar shuni ko'rsatadiki, $topic doirasida yuz bergan bu hodisa bir qator zanjirli reaksiyalarni keltirib chiqardi. Mana, raqamlar va dalillar nimani so'zlaydi.",
          factSource = if (template.isSourceRequired) "Xalqaro tadqiqotlar va ilmiy manbalar (Manba #${sceneIndex})" else "",
          isVerified = template.isSourceRequired
        )
      }
    } else {
      when {
        isHook -> BlueprintData(
          title = "High-Retention Hook",
          visual = "Rapid camera push-in, intense eye contact of main protagonist, impending danger or mystery, cinematic grading",
          dialogue = "Imagine waking up in a reality where every single choice you make is life or death. Today, we uncover the verified truth behind $topic that history almost forgot.",
          factSource = if (template.isSourceRequired) "Archival Commission Report (Doc #1)" else "",
          isVerified = template.isSourceRequired
        )
        isIntro -> BlueprintData(
          title = "The Setup & Context",
          visual = "Wide cinematic establishing shot, detailed environment showcasing time and space, atmospheric depth",
          dialogue = "It all started right here. On the surface, everything appeared completely ordinary, but underneath, an unstoppable countdown had already begun.",
          factSource = if (template.isSourceRequired) "Primary historical records and eyewitness accounts" else "",
          isVerified = template.isSourceRequired
        )
        isClimax -> BlueprintData(
          title = "The Climax & Revelation",
          visual = "High dynamic range lighting, dramatic silhouette, smoking gun piece of evidence revealed, high visual stakes",
          dialogue = "And that was the exact split-second everything broke. What the records revealed next shocked even the most experienced investigators.",
          factSource = if (template.isSourceRequired) "Declassified investigation logs & forensic data" else "",
          isVerified = true
        )
        isOutro -> BlueprintData(
          title = "Takeaway & Call-To-Action",
          visual = "Slow panoramic zoom out, thought-provoking symbolic final frame, lingering cinematic lighting",
          dialogue = "Now you know the true story behind $topic. What would you have done in their shoes? Leave your thoughts below, and hit subscribe for our next deep dive.",
          factSource = "",
          isVerified = true
        )
        else -> BlueprintData(
          title = "Evidence & Narrative Build (#$sceneIndex)",
          visual = "Intricate visual breakdown, character or diagram in motion, strictly adhering to the template aesthetic guidelines",
          dialogue = "According to official documentation, the sequence of events escalated rapidly. When analyzing the raw data, the reality becomes undeniable.",
          factSource = if (template.isSourceRequired) "Verified Research Paper & Public Archive #$sceneIndex" else "",
          isVerified = template.isSourceRequired
        )
      }
    }
  }

  suspend fun generateSeoAndThumbnailsFallback(
    topic: String,
    template: Template,
    language: String
  ): Triple<String, String, List<ThumbnailConcept>> = withContext(Dispatchers.IO) {
    val isUzbek = language.startsWith("O'zbek", ignoreCase = true)

    val seoTitle = if (isUzbek) {
      "${topic.take(65)} | Butun Haqiqat (Hech kim bilmaydigan sirlar)"
    } else {
      "${topic.take(60)} - The Shocking Truth Nobody Told You"
    }

    val tags = if (isUzbek) {
      "youtube o'zbekcha, hujjatli film, $topic, qiziqarli faktlar, sirlar, ilmiy tahlil, tarix, top videolar, o'zbek video"
    } else {
      "youtube documentary, $topic, true story, verified facts, deep dive, video essay, viral documentary, explained"
    }

    val description = if (isUzbek) {
      """
      🔥 $topic haqidagi to'liq va tekshirilgan hujjatli video.
      
      Ushbu videoda siz rasmiy manbalar va arxivlarga tayanib tayyorlangan eng qiziqarli faktlarni bilib olasiz.
      
      ⏱ TIMECODES (Boblar):
      00:00 - Kirish va Sirli Boshlanish
      01:15 - Voqealar Konteksti
      03:30 - Kutilmagan Faktlar va Raqamlar
      06:00 - Kulminatsiya va Hal qiluvchi Burilish
      07:45 - Xulosa va Fikrlar
      
      📌 Manbalar va Faktlar:
      - Barcha ma'lumotlar tekshirilgan va xolis tayyorlangan.
      
      Kanalga obuna bo'ling va videoga layk bosing!
      #youtube #hujjatli #o'zbekiston #faktlar #trend
      """.trimIndent()
    } else {
      """
      🔥 The complete verified deep-dive into: $topic.
      
      We investigate the declassified archives, real numbers, and behind-the-scenes realities that mainstream narratives glossed over.
      
      ⏱ TIMECODES:
      00:00 - The Hook & Mystery
      01:15 - The Untold Setup
      03:30 - Breaking Down The Raw Data
      06:00 - The Turning Point Nobody Saw Coming
      07:45 - What This Means Today
      
      📌 SOURCES & CITATIONS:
      - Verified against primary source archives and academic literature.
      
      Leave a comment with your perspective and subscribe for weekly documentaries!
      #documentary #videoessay #history #truth #viral
      """.trimIndent()
    }

    val thumbnails = if (isUzbek) listOf(
      ThumbnailConcept(
        id = 1,
        styleName = "1. Sirli & Qiziquvchanlik (Mystery Hook)",
        headline = "BU YOLG'ON EDI!",
        visualPrompt = "Markazda katta qora sirli siluet, qizil savol belgisi va dramatik chaqmoq nuri, katta qalin sariq matn 'BU YOLG'ON EDI!'",
        rationale = "Inson miyasi yashirin sirni ko'rganda bosishga majbur bo'ladi (CTR +38%)",
        colorPalette = "#FF0033"
      ),
      ThumbnailConcept(
        id = 2,
        styleName = "2. Dahshatli Taqqoslash (Before / After)",
        headline = "100X FARQ!",
        visualPrompt = "Ekranni ikkiga bo'luvchi qizil neon chiziq: chap tomonda oddiy holat, o'ng tomonda daxshatli oqibat, o'rtada qalin oq matn",
        rationale = "Kontrastli taqqoslash darhol tomoshabin diqqatini tortadi va ko'rishni xohlaydi",
        colorPalette = "#F59E0B"
      ),
      ThumbnailConcept(
        id = 3,
        styleName = "3. Hissiy Portlash (Emotional Face & Fact)",
        headline = "KECH BO'LDI...",
        visualPrompt = "Ekran markazida hayrat va dahshatdan qotib qolgan yuz ifodasi, orqa fonda tutun va qizil yonish effekti, qisqa 2 so'zli matn",
        rationale = "Hissiyotli yuz ifodalari YouTube tavsiyalarida eng yuqori CTR foizini beradi",
        colorPalette = "#06B6D4"
      )
    ) else listOf(
      ThumbnailConcept(
        id = 1,
        styleName = "1. Mystery & Curiosity Hook",
        headline = "THEY LIED.",
        visualPrompt = "Close-up shadowy silhouette holding classified folder with a glowing red stamp, bold saturated yellow font 'THEY LIED.'",
        rationale = "Extreme psychological curiosity gap with short 2-word high contrast copy (Expected CTR +42%)",
        colorPalette = "#FF0033"
      ),
      ThumbnailConcept(
        id = 2,
        styleName = "2. Shocking Comparison / Split-Screen",
        headline = "DO NOT ENTER",
        visualPrompt = "Neon red vertical laser dividing screen: left side tranquil normal scene, right side chaotic ruins, bold distressed white text",
        rationale = "Immediate visual conflict triggers cognitive dissonance and rapid clicks",
        colorPalette = "#F59E0B"
      ),
      ThumbnailConcept(
        id = 3,
        styleName = "3. Dramatic Persona & Revelation",
        headline = "IT'S OVER.",
        visualPrompt = "Intense dramatic character face in shock, rim lighting, dark moody background with subtle glowing cyan ticker line",
        rationale = "Human emotional reaction faces anchor audience empathy on mobile feeds",
        colorPalette = "#06B6D4"
      )
    )

    Triple(seoTitle, description, thumbnails)
  }
  // ------------------------------------------------------------------
  // REAL GEMINI INTEGRATION
  // ------------------------------------------------------------------
  private fun langName(language: String) =
    if (language.startsWith("O'zbek", ignoreCase = true)) "Uzbek (Latin script, natural spoken Uzbek)" else "English"

  /** Raw call to Gemini REST API. Throws with a readable message on any failure. */
  private val modelCandidates = listOf("gemini-3.8-flash", "gemini-flash-latest", "gemini-3-flash", "gemini-2.5-flash")
  @Volatile private var workingModel: String? = null

  /** Tries models in order; on overload/unavailable (404, 429, 500, 503) tries the next one, then retries once after a pause. */
  suspend fun askGemini(prompt: String, jsonMode: Boolean = false, grounded: Boolean = false): String {
    var lastError: Exception? = null
    for (pass in 0..2) {
      val order = listOfNotNull(workingModel) + modelCandidates.filter { it != workingModel }
      for (m in order) {
        try {
          val result = callModel(m, prompt, jsonMode, grounded)
          workingModel = m
          return result
        } catch (e: Exception) {
          lastError = e
          val msg = e.message ?: ""
          val retryable = listOf("(404)", "(429)", "(500)", "(503)", "(504)").any { msg.contains(it) } ||
            e is java.io.IOException
          if (!retryable) throw e
        }
      }
      if (pass < 2) kotlinx.coroutines.delay(4000L * (pass + 1))
    }
    throw lastError ?: IllegalStateException("Gemini modeli topilmadi")
  }

  private suspend fun callModel(model: String, prompt: String, jsonMode: Boolean, grounded: Boolean): String =
    withContext(Dispatchers.IO) {
      val key = geminiApiKeyProvider().trim()
      if (key.isBlank()) throw IllegalStateException("Gemini API kalit kiritilmagan (Sozlamalar bo'limiga kiriting)")

      val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        .openConnection() as HttpURLConnection
      try {
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 240000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)

        val body = JSONObject()
          .put("contents", JSONArray().put(
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
          ))
        if (jsonMode) {
          body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        }
        if (grounded) {
          body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
          val msg = try {
            JSONObject(text).getJSONObject("error").getString("message")
          } catch (_: Exception) {
            text.take(200)
          }
          throw IllegalStateException("Gemini xatosi ($code): $msg")
        }
        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
          .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        if (sb.isBlank()) throw IllegalStateException("Gemini bo'sh javob qaytardi")
        sb.toString()
      } finally {
        conn.disconnect()
      }
    }

  /** Tries Google-search grounded call first (real facts); falls back to plain JSON mode. */
  private suspend fun askWithFacts(prompt: String): String =
    try {
      askGemini(prompt, jsonMode = false, grounded = true)
    } catch (e: Exception) {
      if (e.message?.contains("kalit") == true) throw e
      askGemini(prompt, jsonMode = true, grounded = false)
    }

  private fun extractJson(raw: String, open: Char, close: Char): String {
    val start = raw.indexOf(open)
    val end = raw.lastIndexOf(close)
    if (start < 0 || end <= start) throw IllegalStateException("Gemini javobi JSON emas")
    return raw.substring(start, end + 1)
  }

  suspend fun generateTopics(template: Template, language: String): List<TopicSuggestion> {
    val prompt = """
      You are a YouTube content strategist and fact-checker.
      Niche template: ${template.title}
      Niche description: ${template.description}
      Visual style: ${template.imageStylePrompt}
      Tone: ${template.scriptTone}
      Output language: ${langName(language)}
      Variation seed: ${System.currentTimeMillis()}

      Suggest 5 FRESH, different video topics for this niche. Every topic must be a real,
      verifiable subject: use Google Search to confirm the facts and name a real source.
      Do not repeat the most obvious, overused topics.
      Return ONLY a JSON array of exactly 5 objects with keys:
      "title" (string), "hook" (one-sentence opening hook), "factualAngle" (real named source),
      "targetAudience" (string), "viralScore" (integer 70-99).
    """.trimIndent()

    val raw = askWithFacts(prompt)
    val arr = JSONArray(extractJson(raw, '[', ']'))
    val list = mutableListOf<TopicSuggestion>()
    for (i in 0 until arr.length()) {
      val o = arr.getJSONObject(i)
      list.add(
        TopicSuggestion(
          id = i + 1,
          title = o.optString("title"),
          hook = o.optString("hook"),
          factualAngle = o.optString("factualAngle"),
          targetAudience = o.optString("targetAudience"),
          viralPotentialScore = o.optInt("viralScore", 90)
        )
      )
    }
    if (list.isEmpty()) throw IllegalStateException("Gemini mavzu qaytarmadi")
    return list
  }

  suspend fun generateScriptAndScenes(
    template: Template,
    topic: String,
    aspectRatio: String,
    durationMinutes: Int,
    language: String
  ): Pair<List<ScriptScene>, String> {
    val sceneCount = ((durationMinutes * 60) / 20).coerceIn(6, 40)
    val totalWords = durationMinutes * 130
    val wordsPerScene = (totalWords / sceneCount).coerceAtLeast(20)

    val prompt = """
      You are a professional YouTube scriptwriter.
      Topic: $topic
      Niche template: ${template.title}
      Tone: ${template.scriptTone}
      Video format: $aspectRatio, about $durationMinutes minutes.
      Narration language: ${langName(language)}
      Facts must be accurate: use Google Search to verify, and never invent statistics or quotes.
      ${if (template.isSourceRequired) "Every scene must name a real source in factSource." else "factSource may be empty."}

      Write the full voice-over script split into exactly $sceneCount scenes of roughly $wordsPerScene words each.
      Scene 1 is a strong hook, the last scene is a conclusion with a call to action.
      Return ONLY a JSON array of $sceneCount objects with keys:
      "title" (short scene title, narration language),
      "visual" (English description of what the image shows; do NOT mention art style),
      "narration" (the spoken text for this scene, narration language, no stage directions),
      "factSource" (string), "verified" (boolean).
    """.trimIndent()

    val raw = askWithFacts(prompt)
    val arr = JSONArray(extractJson(raw, '[', ']'))
    if (arr.length() == 0) throw IllegalStateException("Gemini senariy qaytarmadi")

    val narrations = (0 until arr.length()).map { arr.getJSONObject(it).optString("narration") }
    val wordCounts = narrations.map { it.trim().split(Regex("\\s+")).size.coerceAtLeast(1) }
    val sumWords = wordCounts.sum().coerceAtLeast(1)
    val totalSeconds = durationMinutes * 60

    val scenes = mutableListOf<ScriptScene>()
    val voice = StringBuilder()
    var start = 0
    for (i in 0 until arr.length()) {
      val o = arr.getJSONObject(i)
      val n = String.format("%03d", i + 1)
      val visual = o.optString("visual")
      val dur = ((wordCounts[i].toDouble() / sumWords) * totalSeconds).toInt().coerceAtLeast(3)
      scenes.add(
        ScriptScene(
          sceneNumber = i + 1,
          title = "$n Sahna: ${o.optString("title")}",
          visualDescription = visual,
          dialogueText = narrations[i],
          factSource = o.optString("factSource"),
          isSourceVerified = o.optBoolean("verified", false),
          durationSeconds = dur,
          imagePrompt = "$n rasm: $visual | Style: ${template.imageStylePrompt}",
          startTimeSeconds = start
        )
      )
      start += dur
      voice.append(narrations[i]).append("\n\n")
    }
    return Pair(scenes, voice.toString().trim())
  }

  data class SeoResult(
    val title: String,
    val description: String,
    val tags: String,
    val thumbnails: List<ThumbnailConcept>
  )

  suspend fun generateSeoAndThumbnails(
    topic: String,
    template: Template,
    language: String,
    sceneOutline: String
  ): SeoResult {
    val prompt = """
      You are a YouTube SEO expert.
      Video topic: $topic
      Niche: ${template.title}
      Language for title, description and tags: ${langName(language)}
      Scene outline with start times (use it to write timecode chapters in the description):
      $sceneOutline

      Return ONLY a JSON object with keys:
      "title" (max 70 chars, high-CTR, honest),
      "description" (hook paragraph, then chapters "mm:ss - title", then a short CTA, 3-5 hashtags),
      "tags" (one string, 12-15 comma-separated search tags),
      "thumbnails" (array of exactly 3 objects with keys "styleName", "headline" (max 3 words),
        "visualPrompt" (English image-generation prompt describing the full thumbnail),
        "rationale" (why it gets clicks), "colorPalette" (hex color like #FF0033)).
    """.trimIndent()

    val raw = askGemini(prompt, jsonMode = true)
    val o = JSONObject(extractJson(raw, '{', '}'))
    val arr = o.optJSONArray("thumbnails") ?: JSONArray()
    val thumbs = (0 until arr.length()).map { i ->
      val t = arr.getJSONObject(i)
      ThumbnailConcept(
        id = i + 1,
        styleName = "${i + 1}. ${t.optString("styleName")}",
        headline = t.optString("headline"),
        visualPrompt = t.optString("visualPrompt"),
        rationale = t.optString("rationale"),
        colorPalette = t.optString("colorPalette", "#FF0033")
      )
    }
    return SeoResult(
      title = o.optString("title"),
      description = o.optString("description"),
      tags = o.optString("tags"),
      thumbnails = thumbs
    )
  }

}

private data class BlueprintData(
  val title: String,
  val visual: String,
  val dialogue: String,
  val factSource: String,
  val isVerified: Boolean
)
