package com.example.data.local

import com.example.data.model.ScriptScene
import com.example.data.model.ThumbnailConcept
import org.json.JSONArray
import org.json.JSONObject

object JsonHelper {
  fun serializeScenes(scenes: List<ScriptScene>): String {
    val array = JSONArray()
    for (s in scenes) {
      val obj = JSONObject().apply {
        put("sceneNumber", s.sceneNumber)
        put("title", s.title)
        put("visualDescription", s.visualDescription)
        put("dialogueText", s.dialogueText)
        put("factSource", s.factSource)
        put("isSourceVerified", s.isSourceVerified)
        put("durationSeconds", s.durationSeconds)
        put("imagePrompt", s.imagePrompt)
        put("imageUri", s.imageUri ?: "")
        put("startTimeSeconds", s.startTimeSeconds)
      }
      array.put(obj)
    }
    return array.toString()
  }

  fun deserializeScenes(json: String): List<ScriptScene> {
    if (json.isBlank()) return emptyList()
    val list = mutableListOf<ScriptScene>()
    try {
      val array = JSONArray(json)
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        list.add(
          ScriptScene(
            sceneNumber = obj.optInt("sceneNumber", i + 1),
            title = obj.optString("title", "Sahna ${i + 1}"),
            visualDescription = obj.optString("visualDescription", ""),
            dialogueText = obj.optString("dialogueText", ""),
            factSource = obj.optString("factSource", ""),
            isSourceVerified = obj.optBoolean("isSourceVerified", false),
            durationSeconds = obj.optInt("durationSeconds", 15),
            imagePrompt = obj.optString("imagePrompt", ""),
            imageUri = obj.optString("imageUri", "").takeIf { it.isNotBlank() },
            startTimeSeconds = obj.optInt("startTimeSeconds", 0)
          )
        )
      }
    } catch (_: Exception) {}
    return list
  }

  fun serializeThumbnails(concepts: List<ThumbnailConcept>): String {
    val array = JSONArray()
    for (c in concepts) {
      val obj = JSONObject().apply {
        put("id", c.id)
        put("styleName", c.styleName)
        put("headline", c.headline)
        put("visualPrompt", c.visualPrompt)
        put("rationale", c.rationale)
        put("colorPalette", c.colorPalette)
      }
      array.put(obj)
    }
    return array.toString()
  }

  fun deserializeThumbnails(json: String): List<ThumbnailConcept> {
    if (json.isBlank()) return emptyList()
    val list = mutableListOf<ThumbnailConcept>()
    try {
      val array = JSONArray(json)
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        list.add(
          ThumbnailConcept(
            id = obj.optInt("id", i + 1),
            styleName = obj.optString("styleName", "Uslub ${i + 1}"),
            headline = obj.optString("headline", ""),
            visualPrompt = obj.optString("visualPrompt", ""),
            rationale = obj.optString("rationale", ""),
            colorPalette = obj.optString("colorPalette", "#FF0033")
          )
        )
      }
    } catch (_: Exception) {}
    return list
  }
}
