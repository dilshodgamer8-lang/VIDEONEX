package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Template
import kotlinx.coroutines.flow.Flow

@Dao
interface TemplateDao {
  @Query("SELECT * FROM templates ORDER BY isCustom ASC, id ASC")
  fun getAllTemplates(): Flow<List<Template>>

  @Query("SELECT * FROM templates WHERE id = :id LIMIT 1")
  suspend fun getTemplateById(id: String): Template?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTemplate(template: Template)

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertAll(templates: List<Template>)

  @Update
  suspend fun updateTemplate(template: Template)

  @Delete
  suspend fun deleteTemplate(template: Template)
}
