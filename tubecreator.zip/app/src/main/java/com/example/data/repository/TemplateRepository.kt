package com.example.data.repository

import com.example.data.local.TemplateDao
import com.example.data.model.Template
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class TemplateRepository(private val templateDao: TemplateDao) {

  val allTemplates: Flow<List<Template>> = templateDao.getAllTemplates()

  suspend fun getTemplateById(id: String): Template? = templateDao.getTemplateById(id)

  suspend fun addTemplate(template: Template) = templateDao.insertTemplate(template)

  suspend fun deleteTemplate(template: Template) = templateDao.deleteTemplate(template)

  suspend fun seedDefaultsIfEmpty() {
    templateDao.insertAll(Template.DEFAULT_TEMPLATES)
  }

  fun exportTemplatesToJson(templates: List<Template>): String {
    val array = JSONArray()
    for (t in templates) {
      val obj = JSONObject().apply {
        put("id", t.id)
        put("title", t.title)
        put("description", t.description)
        put("category", t.category)
        put("aspectRatio", t.aspectRatio)
        put("defaultDurationMinutes", t.defaultDurationMinutes)
        put("language", t.language)
        put("imageStylePrompt", t.imageStylePrompt)
        put("scriptTone", t.scriptTone)
        put("montageEffect", t.montageEffect)
        put("isSourceRequired", t.isSourceRequired)
        put("colorTag", t.colorTag)
        put("iconName", t.iconName)
      }
      array.put(obj)
    }
    return array.toString(2)
  }

  suspend fun importTemplatesFromJson(json: String): Int {
    return try {
      val array = JSONArray(json)
      var count = 0
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val template = Template(
          id = obj.optString("id", "custom_${System.currentTimeMillis()}_$i"),
          title = obj.getString("title"),
          description = obj.optString("description", ""),
          category = obj.optString("category", "Maxsus"),
          aspectRatio = obj.optString("aspectRatio", "16:9"),
          defaultDurationMinutes = obj.optInt("defaultDurationMinutes", 8),
          language = obj.optString("language", "O'zbekcha"),
          imageStylePrompt = obj.optString("imageStylePrompt", ""),
          scriptTone = obj.optString("scriptTone", ""),
          montageEffect = obj.optString("montageEffect", ""),
          isSourceRequired = obj.optBoolean("isSourceRequired", false),
          isCustom = true,
          colorTag = obj.optString("colorTag", "#FF2A42"),
          iconName = obj.optString("iconName", "movie")
        )
        templateDao.insertTemplate(template)
        count++
      }
      count
    } catch (_: Exception) {
      0
    }
  }
}
