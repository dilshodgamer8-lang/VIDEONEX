package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class Project(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val templateId: String,
  val templateTitle: String,
  val templateCategory: String,
  val language: String, // "O'zbekcha" or "English"
  val aspectRatio: String, // "16:9" or "9:16"
  val durationMinutes: Int,
  val currentStep: Int = 1, // 1: Topic, 2: Format/Time, 3: Script, 4: Prompts, 5: Montage, 6: SEO/Export
  val selectedTopic: String = "",
  val scenesJson: String = "[]",
  val cleanVoiceText: String = "",
  val audioUri: String? = null,
  val backgroundMusicTrack: String = "ambient_cinematic",
  val seoTitle: String = "",
  val seoDescription: String = "",
  val seoTags: String = "",
  val thumbnailConceptsJson: String = "[]",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis()
)
