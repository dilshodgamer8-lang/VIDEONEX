package com.example.data.service

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import com.example.data.model.ScriptScene
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream

data class SubtitleCue(
  val sceneNumber: Int,
  val startTimeMs: Long,
  val endTimeMs: Long,
  val text: String
)

class AudioMontageEngine(private val context: Context) {

  private var mediaRecorder: MediaRecorder? = null
  private var mediaPlayer: MediaPlayer? = null
  private var currentRecordingFile: File? = null

  private val _isPlaying = MutableStateFlow(false)
  val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

  private val _playbackPositionMs = MutableStateFlow(0L)
  val playbackPositionMs: StateFlow<Long> = _playbackPositionMs.asStateFlow()

  private val _totalDurationMs = MutableStateFlow(0L)
  val totalDurationMs: StateFlow<Long> = _totalDurationMs.asStateFlow()

  private val _isRecording = MutableStateFlow(false)
  val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

  fun calculateTimecodes(scenes: List<ScriptScene>): List<ScriptScene> {
    var accumulatedSec = 0
    return scenes.mapIndexed { index, scene ->
      val updated = scene.copy(
        sceneNumber = index + 1,
        startTimeSeconds = accumulatedSec
      )
      accumulatedSec += scene.durationSeconds
      updated
    }
  }

  fun generateSubtitles(scenes: List<ScriptScene>): List<SubtitleCue> {
    val cues = mutableListOf<SubtitleCue>()
    var accumulatedMs = 0L

    for (scene in scenes) {
      val sceneDurationMs = scene.durationSeconds * 1000L
      val words = scene.dialogueText.split("\\s+".toRegex()).filter { it.isNotBlank() }
      if (words.isEmpty()) {
        accumulatedMs += sceneDurationMs
        continue
      }

      // Chunk into 4-6 words per subtitle line (like modern YouTube captions)
      val chunkSize = 5
      val chunks = words.chunked(chunkSize)
      val timePerChunk = sceneDurationMs / chunks.size.coerceAtLeast(1)

      for ((chunkIdx, chunk) in chunks.withIndex()) {
        val start = accumulatedMs + (chunkIdx * timePerChunk)
        val end = (start + timePerChunk).coerceAtMost(accumulatedMs + sceneDurationMs)
        cues.add(
          SubtitleCue(
            sceneNumber = scene.sceneNumber,
            startTimeMs = start,
            endTimeMs = end,
            text = chunk.joinToString(" ")
          )
        )
      }
      accumulatedMs += sceneDurationMs
    }
    return cues
  }

  fun generateSrtContent(cues: List<SubtitleCue>): String {
    val sb = StringBuilder()
    cues.forEachIndexed { index, cue ->
      sb.append(index + 1).append("\n")
      sb.append(formatSrtTime(cue.startTimeMs))
      sb.append(" --> ")
      sb.append(formatSrtTime(cue.endTimeMs))
      sb.append("\n")
      sb.append(cue.text)
      sb.append("\n\n")
    }
    return sb.toString()
  }

  private fun formatSrtTime(ms: Long): String {
    val hours = ms / 3600000
    val minutes = (ms % 3600000) / 60000
    val seconds = (ms % 60000) / 1000
    val millis = ms % 1000
    return String.format("%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
  }

  fun startRecording(onSuccess: (File) -> Unit, onError: (String) -> Unit) {
    try {
      val audioFile = File(context.cacheDir, "voiceover_${System.currentTimeMillis()}.m4a")
      currentRecordingFile = audioFile

      val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        MediaRecorder(context)
      } else {
        @Suppress("DEPRECATION")
        MediaRecorder()
      }

      recorder.apply {
        setAudioSource(MediaRecorder.AudioSource.MIC)
        setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        setAudioEncodingBitRate(192000)
        setAudioSamplingRate(44100)
        setOutputFile(audioFile.absolutePath)
        prepare()
        start()
      }
      mediaRecorder = recorder
      _isRecording.value = true
      onSuccess(audioFile)
    } catch (e: Exception) {
      _isRecording.value = false
      onError(e.message ?: "Ovoz yozishda xatolik yuz berdi")
    }
  }

  fun stopRecording(): File? {
    return try {
      mediaRecorder?.apply {
        stop()
        release()
      }
      mediaRecorder = null
      _isRecording.value = false
      currentRecordingFile
    } catch (e: Exception) {
      mediaRecorder = null
      _isRecording.value = false
      null
    }
  }

  fun startPlayback(
    totalDurationSeconds: Int,
    onProgress: (Long) -> Unit
  ) {
    _totalDurationMs.value = totalDurationSeconds * 1000L
    _isPlaying.value = true
  }

  fun pausePlayback() {
    _isPlaying.value = false
  }

  fun updatePosition(posMs: Long) {
    _playbackPositionMs.value = posMs
  }

  fun exportProjectPackage(
    projectTitle: String,
    scenes: List<ScriptScene>,
    cleanVoiceText: String,
    seoTitle: String,
    seoDesc: String,
    seoTags: String
  ): File {
    val exportDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "TubeCreatorExports")
    if (!exportDir.exists()) exportDir.mkdirs()

    val safeTitle = projectTitle.replace("[^a-zA-Z0-9_-]".toRegex(), "_").take(30)
    val projectFolder = File(exportDir, "${safeTitle}_${System.currentTimeMillis()}")
    projectFolder.mkdirs()

    // 1. Write SRT Subtitles
    val cues = generateSubtitles(scenes)
    val srtFile = File(projectFolder, "subtitles.srt")
    srtFile.writeText(generateSrtContent(cues))

    // 2. Write Clean Script for Voiceover
    val scriptFile = File(projectFolder, "clean_voiceover_script.txt")
    scriptFile.writeText(cleanVoiceText)

    // 3. Write Image Prompts List
    val promptsFile = File(projectFolder, "image_prompts.txt")
    val promptsText = scenes.joinToString("\n\n") { scene ->
      "${scene.imagePrompt}\n(Vaqt davomiyligi: ${scene.durationSeconds}s, Boshlanish: ${scene.startTimeSeconds}s)"
    }
    promptsFile.writeText(promptsText)

    // 4. Write YouTube SEO Metadata
    val seoFile = File(projectFolder, "youtube_seo_package.txt")
    seoFile.writeText(
      """
      === YOUTUBE VIDEO TITLE ===
      $seoTitle
      
      === YOUTUBE DESCRIPTION & TIMECODES ===
      $seoDesc
      
      === YOUTUBE TAGS ===
      $seoTags
      """.trimIndent()
    )

    // 5. Write FFmpeg / Video Assembly EDL JSON
    val edlFile = File(projectFolder, "montage_timeline_edl.json")
    val edlJson = org.json.JSONObject().apply {
      put("projectTitle", projectTitle)
      put("totalDurationSeconds", scenes.sumOf { it.durationSeconds })
      val sceneArray = org.json.JSONArray()
      for (s in scenes) {
        val sObj = org.json.JSONObject().apply {
          put("sceneNumber", s.sceneNumber)
          put("durationSeconds", s.durationSeconds)
          put("startTimeSeconds", s.startTimeSeconds)
          put("imageFile", String.format("%03d_rasm.png", s.sceneNumber))
          put("subtitle", s.dialogueText)
          put("transition", "crossfade_0.5s")
          put("cameraMotion", "ken_burns_zoom_in_1.15")
        }
        sceneArray.put(sObj)
      }
      put("scenes", sceneArray)
    }
    edlFile.writeText(edlJson.toString(2))

    return projectFolder
  }
}
