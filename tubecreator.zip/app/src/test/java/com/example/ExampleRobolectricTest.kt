package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Template
import com.example.data.service.AudioMontageEngine
import com.example.data.model.ScriptScene
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TubeCreator", appName)
  }

  @Test
  fun `verify default templates count and attributes`() {
    val defaults = Template.DEFAULT_TEMPLATES
    assertEquals(11, defaults.size)

    val tarix = defaults.first { it.id == "tarixiy_pov" }
    assertEquals("O'zbekcha", tarix.language)
    assertEquals(8, tarix.defaultDurationMinutes)
    assertTrue(tarix.isSourceRequired)

    val oversimplified = defaults.first { it.id == "oversimplified_history" }
    assertEquals("English", oversimplified.language)
    assertEquals(10, oversimplified.defaultDurationMinutes)
  }

  @Test
  fun `test audio montage timecode calculation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = AudioMontageEngine(context)

    val scenes = listOf(
      ScriptScene(sceneNumber = 1, title = "Scene 1", visualDescription = "V1", dialogueText = "Hello world here is video", durationSeconds = 10),
      ScriptScene(sceneNumber = 2, title = "Scene 2", visualDescription = "V2", dialogueText = "Second scene continues now", durationSeconds = 15)
    )

    val timed = engine.calculateTimecodes(scenes)
    assertEquals(0, timed[0].startTimeSeconds)
    assertEquals(10, timed[1].startTimeSeconds)

    val subtitles = engine.generateSubtitles(timed)
    assertTrue(subtitles.isNotEmpty())
    assertEquals(0L, subtitles.first().startTimeMs)
  }
}
