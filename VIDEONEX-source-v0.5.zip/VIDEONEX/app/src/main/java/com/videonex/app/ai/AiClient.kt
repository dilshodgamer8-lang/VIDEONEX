package com.videonex.app.ai

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    private const val PREFS = "videonex_ai_settings"
    data class Config(val endpoint: String, val model: String, val hasKey: Boolean)

    fun saveConfig(context: Context, endpoint: String, model: String, apiKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("endpoint", endpoint.trim()).putString("model", model.trim()).apply()
        if (apiKey.isNotBlank()) SecureKeyStore.save(context, apiKey.trim())
    }

    fun config(context: Context): Config {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Config(prefs.getString("endpoint", "") ?: "", prefs.getString("model", "") ?: "", SecureKeyStore.read(context).isNotBlank())
    }

    fun generate(context: Context, prompt: String): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val endpoint = prefs.getString("endpoint", "")?.trim().orEmpty()
        val model = prefs.getString("model", "")?.trim().orEmpty()
        val apiKey = SecureKeyStore.read(context)
        require(endpoint.startsWith("https://")) { "API manzili https:// bilan boshlanishi kerak." }
        require(model.isNotBlank()) { "AI model nomini kiriting." }
        require(apiKey.isNotBlank()) { "API kaliti kiritilmagan. Sozlamalar → AI API bo‘limini tekshiring." }
        val base = endpoint.trimEnd('/')
        val requestUrl = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val connection = (URL(requestUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000; doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val body = JSONObject().put("model", model)
                .put("messages", org.json.JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                .put("temperature", 0.7).put("max_tokens", 5000)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("AI server xatosi ($code): ${response.take(400)}")
            val content = JSONObject(response).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "").trim()
            if (content.isBlank()) throw IllegalStateException("AI bo‘sh javob qaytardi.")
            return content
        } finally { connection.disconnect() }
    }
}
