package com.videonex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.videonex.app.ai.AiClient
import com.videonex.app.ai.SecureKeyStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.videonex.app.data.ProjectDao
import com.videonex.app.data.VideoProject
import com.videonex.app.data.VideonexDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD6AD55)
private val Muted = Color(0xFFAAAAAA)
private val Red = Color(0xFFFF7777)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = VideonexDatabase.get(this).projectDao()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel,
                onPrimary = Black, onBackground = Color.White, onSurface = Color.White)) {
                val vm: HomeViewModel = viewModel(factory = HomeViewModel.factory(dao))
                VideonexApp(vm)
            }
        }
    }
}

class HomeViewModel(private val dao: ProjectDao) : ViewModel() {
    val projects = dao.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun addProject(name: String, direction: String) = viewModelScope.launch { dao.insert(VideoProject(name = name, direction = direction)) }
    fun saveSettings(id: Long, format: String, duration: Int, language: String) = viewModelScope.launch {
        dao.updateSettings(id, format, duration, language)
    }
    fun saveContent(project: VideoProject, topic: String, script: String, title: String, description: String, tags: String) = viewModelScope.launch {
        dao.updateContent(project.id, topic, script, title, description, tags)
    }
    fun deleteProject(id: Long) = viewModelScope.launch { dao.delete(id) }
    companion object {
        fun factory(dao: ProjectDao) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(dao) as T
        }
    }
}

@Composable
private fun VideonexApp(vm: HomeViewModel) {
    val projects by vm.projects.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf("Bosh sahifa") }
    var showCreate by remember { mutableStateOf(false) }
    var selectedProject by remember { mutableStateOf<VideoProject?>(null) }
    Scaffold(containerColor = Black, bottomBar = {
        NavigationBar(containerColor = Panel) {
            val tabs = listOf("Bosh sahifa", "AI Studio", "Loyihalar", "Sozlamalar")
            tabs.forEach { item ->
                NavigationBarItem(selected = tab == item, onClick = { tab = item },
                    icon = { Icon(when (item) { "Bosh sahifa" -> Icons.Default.Home; "AI Studio" -> Icons.Default.AutoAwesome; "Loyihalar" -> Icons.Default.FolderOpen; else -> Icons.Default.Settings }, null) },
                    label = { Text(item, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold,
                        indicatorColor = Color(0xFF342A17), unselectedIconColor = Muted, unselectedTextColor = Muted))
            }
        }
    }) { padding ->
        when (tab) {
            "Bosh sahifa" -> HomePage(projects, Modifier.padding(padding), onCreate = { showCreate = true }, onOpen = { selectedProject = it })
            "AI Studio" -> StudioPage(projects, Modifier.padding(padding), onOpen = { selectedProject = it })
            "Loyihalar" -> ProjectsPage(projects, Modifier.padding(padding), onOpen = { selectedProject = it }, onCreate = { showCreate = true })
            else -> SettingsPage(Modifier.padding(padding))
        }
    }
    if (showCreate) CreateProjectDialog(onDismiss = { showCreate = false }, onCreate = { name, direction -> vm.addProject(name, direction); showCreate = false })
    selectedProject?.let { project ->
        ProjectWorkspace(project = project, onDismiss = { selectedProject = null },
            onSaveSettings = { format, duration, language -> vm.saveSettings(project.id, format, duration, language) },
            onSaveContent = { topic, script, title, description, tags -> vm.saveContent(project, topic, script, title, description, tags) },
            onDelete = { vm.deleteProject(project.id); selectedProject = null })
    }
}

@Composable
private fun PageHeader(subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("VIDEONEX", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(subtitle.uppercase(), color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        }
        Box(Modifier.size(44.dp).background(Panel, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("V", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HomePage(projects: List<VideoProject>, modifier: Modifier, onCreate: () -> Unit, onOpen: (VideoProject) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageHeader("AI Video Creator") }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) {
                Text("Xush kelibsiz!", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("G‘oyangizni video loyihaga aylantiring.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                GoldButton("＋  YANGI VIDEO YARATISH", onCreate)
            }
        }
        item { Text("LOYIHALAR STATISTIKASI", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Loyihalar", projects.size.toString(), Modifier.weight(1f))
                StatCard("Ssenariylar", projects.count { it.script.isNotBlank() }.toString(), Modifier.weight(1f))
                StatCard("SEO tayyor", projects.count { it.seoTitle.isNotBlank() }.toString(), Modifier.weight(1f))
            }
        }
        item { Text("SO‘NGGI LOYIHALAR", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp) }
        if (projects.isEmpty()) item { EmptyPanel() } else items(projects.take(5), key = { it.id }) { ProjectCard(it) { onOpen(it) } }
        item { InfoPanel("ESLATMA", "Hozirgi versiyada loyiha va matnlar telefon xotirasida saqlanadi. Haqiqiy onlayn AI generatsiyasi API ulanishi qo‘shilgandan keyin ishlaydi.") }
    }
}

@Composable
private fun StudioPage(projects: List<VideoProject>, modifier: Modifier, onOpen: (VideoProject) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageHeader("AI Studio") }
        item { InfoPanel("ISH JARAYONI", "Loyihani tanlang. Mavzu va ssenariy matnini yozing yoki ichki oflayn reja shablonidan foydalaning. Bu shablon haqiqiy AI javobi emas.") }
        item { Text("LOYIHANI TANLANG", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        if (projects.isEmpty()) item { EmptyPanel("Avval bosh sahifadan loyiha yarating.") }
        else items(projects, key = { it.id }) { project ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onOpen(project) }.padding(15.dp)) {
                Text(project.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("${project.direction} • ${project.durationMinutes} daqiqa • ${project.language}", color = Muted, fontSize = 11.sp)
                Text(if (project.script.isBlank()) "Ssenariy hali yo‘q — ochish" else "Ssenariy saqlangan — tahrirlash", color = Gold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ProjectsPage(projects: List<VideoProject>, modifier: Modifier, onOpen: (VideoProject) -> Unit, onCreate: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Loyihalar") }
        item { GoldButton("＋  YANGI LOYIHA", onCreate) }
        if (projects.isEmpty()) item { EmptyPanel() } else items(projects, key = { it.id }) { ProjectCard(it) { onOpen(it) } }
    }
}

@Composable
private fun SettingsPage(modifier: Modifier) {
    val context = LocalContext.current
    val config = remember { AiClient.config(context) }
    var endpoint by remember { mutableStateOf(config.endpoint) }
    var model by remember { mutableStateOf(config.model) }
    var apiKey by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(if (config.hasKey) "API kaliti xavfsiz saqlangan." else "API hali ulanmagan.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LazyColumn(Modifier.fillMaxSize().background(Black).then(modifier), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Sozlamalar") }
        item { InfoPanel("ILOVA", "VIDEONEX • Created by Me\nVersiya: 0.5.0-dev\nDizayn: qora va oltin") }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionLabel("AI API ULANISHI")
                Text("OpenAI-compatible API manzili", color = Muted, fontSize = 11.sp)
                OutlinedTextField(endpoint, { endpoint = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://.../v1") })
                Text("Model nomi", color = Muted, fontSize = 11.sp)
                OutlinedTextField(model, { model = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("model-name") })
                Text("API kaliti (telefon ichida shifrlanadi)", color = Muted, fontSize = 11.sp)
                OutlinedTextField(apiKey, { apiKey = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), placeholder = { Text(if (config.hasKey) "Saqlangan kalit bor — yangilash uchun kiriting" else "API key") })
                GoldButton("API SOZLAMALARINI SAQLASH") {
                    AiClient.saveConfig(context, endpoint, model, apiKey)
                    apiKey = ""
                    status = "Sozlamalar saqlandi. Kalit Android Keystore orqali shifrlanadi."
                }
                OutlinedButton(onClick = {
                    AiClient.saveConfig(context, endpoint, model, apiKey)
                    apiKey = ""
                    busy = true
                    status = "Ulanish tekshirilmoqda..."
                    scope.launch {
                        status = try {
                            withContext(Dispatchers.IO) { AiClient.generate(context, "Reply with exactly: VIDEONEX_OK") }
                            "AI javobi olindi. API ulanishi ishlayapti."
                        } catch (e: Exception) { "Ulanish xatosi: ${e.message ?: "Noma’lum xato"}" }
                        busy = false
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "TEKSHIRILMOQDA..." else "AI ULANISHINI TEKSHIRISH", color = Gold) }
                Text(status, color = if (status.contains("xato", true)) Red else Muted, fontSize = 11.sp)
                Text("Eslatma: endpoint, model va API kaliti xizmat ko‘rsatuvchi provayderga mos bo‘lishi kerak. Bepul limitlar provayderga bog‘liq; pullik tarif avtomatik yoqilmaydi.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        item { InfoPanel("MAXFIYLIK", "Loyihalar telefondagi Room bazasida saqlanadi. API kaliti Android Keystore yordamida shifrlanadi. AI so‘rovlari tanlangan provayderga internet orqali yuboriladi.") }
        item { InfoPanel("VIDEO EKSPORT", "Montaj va MP4 eksport modullari keyingi ishlab chiqish bosqichlarida qo‘shiladi. Hozircha ular tayyor deb ko‘rsatilmaydi.") }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(13.dp)).padding(11.dp)) {
        Text(value, color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ProjectCard(project: VideoProject, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(Color(0xFF302719), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Movie, null, tint = Gold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(project.name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(project.direction, color = Muted, fontSize = 11.sp)
            Text("${project.format} • ${project.durationMinutes} daq. • ${project.language}", color = Gold, fontSize = 10.sp)
        }
        Text("›", color = Gold, fontSize = 24.sp)
    }
}

@Composable
private fun EmptyPanel(message: String = "Hozircha loyiha yo‘q. Birinchi loyihangizni yarating.") {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.FolderOpen, null, tint = Gold, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(8.dp)); Text(message, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun InfoPanel(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text(body, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun GoldButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(13.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Text(label, fontWeight = FontWeight.Bold) }
}

@Composable
private fun CreateProjectDialog(onDismiss: () -> Unit, onCreate: (String, String) -> Unit) {
    val directions = listOf("Tarixiy POV", "Tarix", "Biznes va Finance", "Tarixdagi g‘alati ishlar", "Qadimgi odamlar", "Inson ongi va falsafa", "Horror hikoyalar", "Jamiyat psixologiyasi", "Tibbiyot va salomatlik", "Wojak Doomer", "Brendlar va korporatsiyalar tarixi")
    var name by remember { mutableStateOf("") }; var direction by remember { mutableStateOf(directions.first()) }; var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Yangi loyiha", color = Gold) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Loyiha nomi") }, singleLine = true)
            Text("Video yo‘nalishini tanlang", color = Muted, fontSize = 12.sp)
            Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(direction, color = Color.White) }
                DropdownMenu(expanded, { expanded = false }) { directions.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { direction = it; expanded = false }) } }
            }
        } }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim(), direction) }, enabled = name.isNotBlank()) { Text("YARATISH", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BEKOR", color = Muted) } })
}

@Composable
private fun ProjectWorkspace(project: VideoProject, onDismiss: () -> Unit,
    onSaveSettings: (String, Int, String) -> Unit,
    onSaveContent: (String, String, String, String, String) -> Unit,
    onDelete: () -> Unit) {
    var format by remember(project.id) { mutableStateOf(project.format) }
    var duration by remember(project.id) { mutableStateOf(project.durationMinutes.toString()) }
    var language by remember(project.id) { mutableStateOf(project.language) }
    var topic by remember(project.id) { mutableStateOf(project.topic) }
    var script by remember(project.id) { mutableStateOf(project.script) }
    var seoTitle by remember(project.id) { mutableStateOf(project.seoTitle) }
    var seoDescription by remember(project.id) { mutableStateOf(project.seoDescription) }
    var seoTags by remember(project.id) { mutableStateOf(project.seoTags) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var aiBusy by remember { mutableStateOf(false) }
    var aiStatus by remember { mutableStateOf("") }
    var topicIdeas by remember { mutableStateOf(listOf<String>()) }
    var pendingAiTask by remember { mutableStateOf("") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    fun startAi(task: String) {
        if (!aiBusy) pendingAiTask = task
    }
    fun runAi(task: String) {
        if (aiBusy) return
        pendingAiTask = ""
        val prompt = when (task) {
            "topics" -> "You are a professional YouTube research producer. Create exactly 5 distinct, clickable video topic ideas for direction: ${project.direction}. Output language: $language. Video format: $format. Planned duration: $duration minutes. Do not write a script. For each idea give a short title and one-sentence hook. Avoid generic/repeated ideas. Return numbered list only."
            "script" -> "Write a complete, engaging YouTube video script in $language. Topic: $topic. Channel direction: ${project.direction}. Format: $format. Target duration: $duration minutes. Include a powerful opening hook, coherent sections, transitions, and a memorable ending. Adapt length and pacing to the requested duration. Do not invent facts. Mark claims that need verification and include a short list of 2-3 reliable source types or source URLs when known. Return only the script with section headings."
            else -> "Create YouTube SEO in $language for this video. Direction: ${project.direction}. Topic: $topic. Script: ${script.take(9000)}. Return valid JSON only with keys: title (best title), title_variants (array of 5), description, tags (array), hashtags (array), thumbnail_ideas (array of 3). Make it relevant, natural, searchable, and not keyword-stuffed. Never claim guaranteed views."
        }
        aiBusy = true
        aiStatus = "AI javobi kutilmoqda..."
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { AiClient.generate(context, prompt) }
                when (task) {
                    "topics" -> {
                        topicIdeas = result.lines().map { it.trim().replace(Regex("^[-*•0-9.) ]+"), "").trim() }.filter { it.length > 5 }.take(5)
                        aiStatus = if (topicIdeas.isNotEmpty()) "5 ta mavzu tayyor. Tanlash uchun pastdagi variantni bosing." else "AI javobi olindi, lekin mavzularni ajratib bo‘lmadi. Matnni qayta yarating."
                    }
                    "script" -> { script = result; aiStatus = "AI ssenariy yaratdi. Saqlashni unutmang." }
                    else -> {
                        val json = org.json.JSONObject(result)
                        seoTitle = json.optString("title", "")
                        seoDescription = buildString {
                            append(json.optString("description", ""))
                            val variants = json.optJSONArray("title_variants")
                            if (variants != null) { append("\n\nSarlavha variantlari:"); for (i in 0 until variants.length()) append("\n${i + 1}. ${variants.optString(i)}") }
                            val thumbs = json.optJSONArray("thumbnail_ideas")
                            if (thumbs != null) { append("\n\nThumbnail g‘oyalari:"); for (i in 0 until thumbs.length()) append("\n${i + 1}. ${thumbs.optString(i)}") }
                        }
                        val tags = json.optJSONArray("tags")
                        val hashes = json.optJSONArray("hashtags")
                        seoTags = (0 until (tags?.length() ?: 0)).map { tags!!.optString(it) }.plus((0 until (hashes?.length() ?: 0)).map { hashes!!.optString(it) }).joinToString(", ")
                        aiStatus = "AI SEO tayyorladi. Natijani tekshirib, saqlang."
                    }
                }
            } catch (e: Exception) { aiStatus = "AI xatosi: ${e.message ?: "Noma’lum xato"}" }
            aiBusy = false
        }
    }
    val durationNumber = duration.toIntOrNull()
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.94f), shape = RoundedCornerShape(20.dp), color = Panel) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(project.name, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(project.direction, color = Muted, fontSize = 11.sp) }
                    TextButton(onClick = onDismiss) { Text("YOPISH", color = Gold) }
                }
                Divider(color = Color(0xFF3A3325)); Spacer(Modifier.height(10.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    SectionLabel("VIDEO SOZLAMALARI")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("9:16 Shorts", "16:9 Long").forEach { FilterChip(selected = format == it, onClick = { format = it }, label = { Text(it) }) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), label = { Text("Davomiylik (daq.)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        Spacer(Modifier.width(8.dp))
                        Column { listOf("O‘zbek", "English", "Русский").forEach { TextButton(onClick = { language = it }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text(if (language == it) "● $it" else it, color = if (language == it) Gold else Muted, fontSize = 10.sp) } } }
                    }
                    if (durationNumber == null || durationNumber !in 1..240) Text("Davomiylik 1–240 daqiqa oralig‘ida bo‘lsin.", color = Red, fontSize = 11.sp)
                    GoldButton("SOZLAMALARNI SAQLASH") { if (durationNumber != null && durationNumber in 1..240) onSaveSettings(format, durationNumber, language) }
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI MAVZU YARATISH")
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  AI 5 TA MAVZU TAKLIF QILSIN") { startAi("topics") }
                    topicIdeas.forEachIndexed { index, idea ->
                        TextButton(onClick = { topic = idea }, modifier = Modifier.fillMaxWidth()) {
                            Text("${index + 1}. $idea", color = if (topic == idea) Gold else Color.White)
                        }
                    }
                    OutlinedTextField(topic, { topic = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Tanlangan mavzu (AI natijasi)") }, minLines = 2)
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI SSENARIY YARATISH")
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  AI TO‘LIQ SSENARIY YOZSIN") { if (topic.isBlank()) aiStatus = "Avval AI mavzu yaratsin va bittasini tanlang." else startAi("script") }
                    OutlinedTextField(script, { script = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp), label = { Text("AI yaratgan ssenariy — tahrirlash mumkin") }, minLines = 6)
                    OutlinedButton(onClick = { script = offlineOutline(project, topic, language); aiStatus = "Oflayn reja yaratildi. Bu haqiqiy AI javobi emas." }, modifier = Modifier.fillMaxWidth()) { Text("OFLAYN REJA (AI ULANMAGANDA)", color = Gold) }
                    Divider(color = Color(0xFF3A3325)); SectionLabel("AI YOUTUBE SEO")
                    GoldButton(if (aiBusy) "AI ISHLAYAPTI..." else "✦  AI SEO TO‘LIQ YARATSIN") { if (topic.isBlank()) aiStatus = "Avval mavzuni tanlang." else startAi("seo") }
                    OutlinedTextField(seoTitle, { seoTitle = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AI sarlavhasi") }, singleLine = true)
                    OutlinedTextField(seoDescription, { seoDescription = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AI tavsifi va thumbnail g‘oyalari") }, minLines = 3)
                    OutlinedTextField(seoTags, { seoTags = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AI teglar va hashtaglar") }, minLines = 2)
                    if (aiStatus.isNotBlank()) Text(aiStatus, color = if (aiStatus.contains("xato", true)) Red else Gold, fontSize = 11.sp)
                    GoldButton("BARCHA MATNLARNI SAQLASH") { onSaveContent(topic, script, seoTitle, seoDescription, seoTags) }
                    OutlinedButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Text("LOYIHANI O‘CHIRISH") }
                }
            }
        }
    }
    if (showDeleteConfirm) AlertDialog(onDismissRequest = { showDeleteConfirm = false }, containerColor = Panel,
        title = { Text("Loyiha o‘chirilsinmi?", color = Gold) }, text = { Text("Bu loyiha va undagi saqlangan matnlar o‘chadi.", color = Muted) },
        confirmButton = { TextButton(onClick = onDelete) { Text("O‘CHIRISH", color = Red) } }, dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("BEKOR", color = Muted) } })
    if (pendingAiTask.isNotBlank()) AlertDialog(
        onDismissRequest = { pendingAiTask = "" }, containerColor = Panel,
        title = { Text("AI so‘roviga ruxsat", color = Gold) },
        text = { Text("Bu amal internetdan foydalanadi. Loyiha yo‘nalishi, til, format, davomiylik va vazifaga qarab mavzu yoki ssenariy matni tanlangan AI API provayderiga yuboriladi. Taxminiy ma’lumot hajmi: 1–10 KB (ssenariy uzunligiga qarab ko‘proq bo‘lishi mumkin). Davom ettirasizmi?", color = Muted) },
        confirmButton = { TextButton(onClick = { runAi(pendingAiTask) }) { Text("DAVOM ETISH", color = Gold) } },
        dismissButton = { TextButton(onClick = { pendingAiTask = "" }) { Text("BEKOR", color = Muted) } }
    )
}

@Composable
private fun SectionLabel(text: String) { Text(text, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }

private fun offlineOutline(project: VideoProject, topic: String, language: String): String {
    val subject = topic.ifBlank { "[MAVZUNI KIRITING]" }
    return if (language == "English") """INTRO / HOOK\nOpen with a surprising question about $subject.\n\nCONTEXT\nIntroduce the time, place, people, and background.\n\nMAIN STORY\n1. Explain the first important event.\n2. Show the key conflict or discovery.\n3. Explain the consequences with verifiable details.\n\nENDING\nSummarize the central idea and leave one thoughtful question.\n\nRESEARCH NOTES\nAdd at least 2–3 reliable sources and verify dates, names, and numbers before publishing."""
    else """KIRISH / HOOK\n$subject — tomoshabinni qiziqtiradigan kuchli savol yoki fakt bilan boshlang.\n\nKONTEKST\nVoqea, davr, joy va asosiy qahramonlarni qisqacha tanishtiring.\n\nASOSIY QISM\n1. Birinchi muhim voqea yoki dalilni tushuntiring.\n2. Muammo, qarama-qarshilik yoki kashfiyotni ochib bering.\n3. Natijalar va oqibatlarni misollar bilan ko‘rsating.\n\nYAKUN\nAsosiy xulosani ayting va tomoshabinga o‘ylantiruvchi savol qoldiring.\n\nTEKSHIRUV\nKamida 2–3 ishonchli manba toping. Sana, ism va raqamlarni e’lon qilishdan oldin tekshiring.\n\nESLATMA\nBu ${project.durationMinutes} daqiqalik video uchun tahrirlanadigan reja. Bu matn avtomatik AI tadqiqoti emas."""
}
