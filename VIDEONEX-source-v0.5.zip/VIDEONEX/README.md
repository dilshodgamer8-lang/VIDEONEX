# VIDEONEX FULL BUILD — v0.5 development source

Android app source project. The app currently contains the local project dashboard, Room persistence, project settings, AI topic/script/YouTube SEO generation UI, and a configurable OpenAI-compatible chat-completions client.

## AI setup
1. Open Settings → AI API.
2. Enter an HTTPS OpenAI-compatible API base URL, model name, and API key.
3. Save, then use the connection test.
4. Open a project and use the AI topic, script, and SEO buttons. Each generation asks for consent before sending project context to the configured provider.

API keys are encrypted with Android Keystore. The endpoint and model name are stored in app preferences. The app does not embed a provider key and does not automatically switch to paid services. Free quotas depend on the provider and account.

## Current limitations
This is a development source package, not a verified release APK. The AI client currently supports OpenAI-compatible `/chat/completions` endpoints. Research-source verification, image generation, voice generation, timeline editing, media rendering, and MP4 export are not implemented yet. Do not treat placeholder/offline outline text as AI output.

## Build
Open this project in Android Studio or use a compatible Gradle 8.9 + JDK 17 environment and run `gradle assembleDebug`.
